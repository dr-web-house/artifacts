<h1>安租贝(租呀)评估</h1>
<h2>v1.1.1</h2>
<table>
<thead>
<tr>
<th>Feature</th>
<th>working effort</th>
<th> </th>
</tr>
</thead>
<tbody>
<tr>
<td>授信(申请)</td>
<td>5 人天</td>
<td>开发</td>
</tr>
<tr>
<td>使用额度</td>
<td>2.5 人天 (timebox)</td>
<td>原租赁系统相关功能联调部署</td>
</tr>
<tr>
<td>我的账单等</td>
<td> 3 人天</td>
<td>原租赁系统相关功能联调部署</td>
</tr>
<tr>
<td>后台管理</td>
<td>2.5天</td>
<td>联调新增字段</td>
</tr>
</tbody>
</table>
<ul>
<li>Integration/e2e Test: 1.5 人天 仅维护授信(申请)部分
<blockquote>
<p>部分e2e Test集成到CI中的需要对应改动</p>
</blockquote>
</li>
<li>Code review: x 8%
Total:  13 人天 / 2 人 (team capacity) = 大约一周多</li>
</ul>
<h2>v1.2</h2>
<h3>Functional features</h3>
<table>
<thead>
<tr>
<th>Feature</th>
<th>working effort (1 point = 0.5 人天)</th>
<th> </th>
</tr>
</thead>
<tbody>
<tr>
<td>授信(申请)</td>
<td>5 人天</td>
<td>v1.1.1</td>
</tr>
<tr>
<td>使用额度</td>
<td>6.5 人天 (timebox)</td>
<td>开发</td>
</tr>
<tr>
<td>我的账单</td>
<td> 7 人天</td>
<td>开发</td>
</tr>
<tr>
<td>我的全部账单</td>
<td> 5.5 人天</td>
<td>开发</td>
</tr>
<tr>
<td>额度使用记录</td>
<td> 2.5 人天</td>
<td>开发</td>
</tr>
<tr>
<td>后台管理</td>
<td>2.5天</td>
<td>联调新增字段</td>
</tr>
<tr>
<td>Total 业功能开发</td>
<td>29 人天</td>
<td>包含v1.1.1 授信，后台管理 7.5 人天</td>
</tr>
</tbody>
</table>
<ul>
<li>Project architecture, deployment: 5 points</li>
<li>Code review: 29 x 8% = 2.5 人天</li>
<li>API 联调测试: 6 变更API数 x 1.5 = 9人天</li>
<li>Integration/e2e Test: &gt; 1.5 人天 维护授信(申请)部分
<blockquote>
<p>部分e2e Test集成到CI中的需要对应改动</p>
</blockquote>
</li>
</ul>
<p>Total: 47人天 (不包括新增e2e test) / 2.5 人(ideal team capacity) = 18.8天</p>
<h2>具体评估分析</h2>
<ul>
<li>1 complexity point 大约 0.5 人天, 括号内为complexity point值</li>
<li>黄色为待讨论问题</li>
</ul>
<pre><code class="language-mermaid">graph LR
actor((用户))
admin((Admin))
apply(&quot;授信(申请)&quot;)
borrow(&quot;收银台&lt;br&gt;使用额度&quot;)
console(&quot;管理台&quot;)

myBorrow(URL POST访问&lt;br&gt;我的账单)
allBorrow(URL POST访问&lt;br&gt;我的全部账单)
borrowHistory(URL POST访问&lt;br&gt;额度使用记录)

v1-1-1(v1.1.1的case)

actor --&gt; apply
apply -.-&gt; 4factors(四要素&lt;br&gt;验证页面)
4factors -.-&gt; showIdNo(&quot;v1.1.1&lt;br&gt;姓名+身份证&lt;br&gt;展示ke&lt;br&gt;实名数据&lt;br&gt;不可修改(3)&quot;)
showIdNo --- agreementToast(&quot;原来的&lt;br&gt;没有toast&lt;br&gt;提示信息查询&lt;br&gt;授权协议勾选&lt;br&gt;是disable提交按钮&quot;)
4factors -.-&gt; 4factorFail(理房通验&lt;br&gt;证失败提示&lt;br&gt;toast?)
apply -.-&gt; compForm(补充信息)
compForm -.-&gt; compFormChange(&quot;旧字&lt;br&gt;段去除,&lt;br&gt;2必填字段(3)&quot;)
compForm -.-&gt; compFormValid(&quot;紧急联系人&lt;br&gt;+有效验证(3)&quot;)
compForm -.-&gt; reuseCashLoadidForm(&quot;复用部&lt;br&gt;分现金贷?&quot;)
compForm --- apiChange[&quot;API&lt;br&gt;返回数据变化(1)?&quot;]

actor --&gt; borrow
borrow --- borrowApiDebug[&quot;v1.1.1&lt;br&gt;联调API&lt;br&gt;熟悉租赁部署&lt;br&gt;(5 timebox)&quot;]
borrow -.-&gt;|1.| entryValidate(准入验证)
entryValidate --&gt; nodeService[&quot;Node:&lt;br&gt;端POST&lt;br&gt;service+&lt;br&gt;错误提示(3)&quot;]
nodeService --&gt;|server renders&lt;br&gt;ke数据| borrowFormApi[API:&lt;br&gt;KE data]
borrow -.-&gt;|2.| borrowForm(&quot;显示使&lt;br&gt;用额度&lt;br&gt;表单(5)&quot;)
borrowForm -.-&gt; borrowFormPlan(&quot;还款计划,&lt;br&gt;可以复用&quot;)
borrowForm --- nodeService
borrowForm -.-&gt;|include|borrowAgree(&quot;租呀借&lt;br&gt;款协议(1)&quot;)
borrowForm -.-&gt; smsDialog(&quot;短信验&lt;br&gt;证交互(2)&quot;)
borrowForm -.-&gt; borrowResult(&quot;使用额&lt;br&gt;度成功页(2)&quot;)

actor --&gt; myBorrow
myBorrow --&gt; login[&quot;涉及Login API变化?&lt;br&gt;for each&lt;br&gt; request?&lt;br&gt;+ cache? (3)&quot;]
actor --&gt; allBorrow
allBorrow --&gt; login
actor --&gt; borrowHistory
borrowHistory --&gt; login

myBorrow -.-&gt; originAcntCase(&quot;URL&lt;br&gt;access original&lt;br&gt;租赁账单页(3)&quot;)
originAcntCase --&gt; originAcntRoute(熟悉一下&lt;br&gt;租赁代码,&lt;br&gt;可以route到独立页)

myBorrow --&gt; borrowMainComp[&quot;view:&lt;br&gt;我的账单页&lt;br&gt;主视图+下方&lt;br&gt;导航按钮(3)&quot;]

borrowMainComp --&gt; borrowInfoComp[&quot;View:&lt;br&gt;‘x月剩余应还’&lt;br&gt;信息显示&lt;br&gt;+'立即还款'按钮&lt;br&gt;组件(5)&quot;]
borrowInfoComp --&gt; borrowInfoCompEffect[背景和动效]

borrowMainComp --&gt; overdueComp[&quot;View:&lt;br&gt;'逾期+&lt;br&gt;多笔账单待还&lt;br&gt;'提示组件(1)&quot;]

borrowMainComp --&gt; borrowInfoApi[&quot;API:&lt;br&gt;当月应&lt;br&gt;还信息&lt;br&gt;+逾期状态(1)&quot;]

borrowMainComp --&gt;borrowDetails[&quot;View:&lt;br&gt;账单详情表+&lt;br&gt;number&lt;br&gt;format (1)&quot;]

allBorrow --&gt; allBorrowList[&quot;View:&lt;br&gt;分页显示&lt;br&gt;全部账单&lt;br&gt;列表+&lt;br&gt;status&lt;br&gt;navigate&lt;br&gt;to...(5)&quot;]
allBorrowList --&gt;|contain| allBorrowInfo[&quot;View:&lt;br&gt;剩余应还&lt;br&gt;提前还款按钮&lt;br&gt;组件&quot;]

allBorrowList --&gt; allBorrowListApi[&quot;API:&lt;br&gt;全部账单&lt;br&gt;分页列表&quot;]

allBorrowInfo -.-&gt;|extends| borrowInfoComp
allBorrowList --&gt;|navigate|refundPlanComp[&quot;View:&lt;br&gt;还款计划页&lt;br&gt;+banner区(3)&quot;]
refundPlanComp --&gt; refundPlanApi[&quot;API&quot;]
refundPlanComp --&gt; refundPlanListComp[&quot;view:&lt;br&gt;还款计划列表组件(3)&quot;]
admin --&gt; console
console --&gt; consoleDebug[&quot;新增字段&lt;br&gt;相关的&lt;br&gt;部署联调...&lt;br&gt;(5)&quot;]

borrowHistory --&gt; borrowHistoryComp[&quot;View(5)&quot;]
borrowHistory --&gt; refundPlanComp
borrowHistory --&gt; borrowHistoryApi[&quot;API&quot;]

classDef entity fill:cyan;
class borrowFormApi,borrowInfoApi,allBorrowListApi,refundPlanApi,borrowHistoryApi entity;

classDef question fill:yellow;
class agreementToast,4factorFail,reuseCashLoadidForm,apiChange,login,borrowFormPlan question;

classDef v1-1-1 fill:#55c5ff;
class v1-1-1,showIdNo,compForm,borrowApiDebug,consoleDebug,originAcntCase,originAcntRoute v1-1-1;
</code></pre>
