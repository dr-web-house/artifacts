<h1>员工贷前端</h1>
<blockquote>
<p>评估大约120 人天： 功能复杂度 78 + API 联调 27.5 + 设计原型效果 15 , 前端和交互这块team effort capacity最高按2.5人计算</p>
</blockquote>
<h2>功能复杂度 (78 人天)</h2>
<table>
<thead>
<tr>
<th>Name</th>
<th>estimation points</th>
</tr>
</thead>
<tbody>
<tr>
<td>首页</td>
<td>9.5 人天</td>
</tr>
<tr>
<td>申请页和还款</td>
<td>37.5 人天</td>
</tr>
<tr>
<td>我的 + 还款记录</td>
<td>12.5 人天</td>
</tr>
<tr>
<td>借款记录</td>
<td>4.5 人天</td>
</tr>
<tr>
<td>后台管理</td>
<td>7 人天 + Alpha对接 7 人天</td>
</tr>
</tbody>
</table>
<h2>API 联调 (27.5 人天)</h2>
<h3>首页 (张翔)</h3>
<table>
<thead>
<tr>
<th>Name</th>
<th>API</th>
<th>desc</th>
</tr>
</thead>
<tbody>
<tr>
<td></td>
<td>login API</td>
<td></td>
</tr>
<tr>
<td></td>
<td>白名单或风控判断</td>
<td>结果: 可以申请，无额度，已经申请过</td>
</tr>
<tr>
<td></td>
<td>大额员工可见判断API 或 用户信息API</td>
<td>(判断员工职级)</td>
</tr>
</tbody>
</table>
<p><strong>联调: 4.5 人天</strong></p>
<h3>申请页和还款  (余力）</h3>
<table>
<thead>
<tr>
<th>Name</th>
<th>API</th>
<th>desc</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>1.借款金额范围</td>
<td>出错后去错误页面</td>
</tr>
<tr>
<td>2</td>
<td>2.首期还款试算</td>
<td>出错后可重试</td>
</tr>
<tr>
<td>3</td>
<td>3.借款用途</td>
<td>不需要对每个用户都查询，编译时获取，出错后去错误页面</td>
</tr>
<tr>
<td>4</td>
<td>还款计划列表</td>
<td></td>
</tr>
<tr>
<td>5</td>
<td>1.借款人姓名/身份证/所属银行/卡号 2.存管状态, 3.已绑银行卡</td>
<td>借款人信息或许可以在login API时就返回</td>
</tr>
<tr>
<td>6</td>
<td>获取跳转存管URL</td>
<td></td>
</tr>
<tr>
<td>7</td>
<td>获取跳转收银台绑卡URL</td>
<td></td>
</tr>
<tr>
<td>8</td>
<td>借款信息(预览签约页面)</td>
<td></td>
</tr>
<tr>
<td>9</td>
<td>发送短信接口</td>
<td></td>
</tr>
<tr>
<td>10</td>
<td>借款申请</td>
<td></td>
</tr>
<tr>
<td>11</td>
<td>放款接口（可能多余）</td>
<td></td>
</tr>
<tr>
<td>12</td>
<td>1.最近待还列表 + 2.累计待还</td>
<td>最好合并成一个API</td>
</tr>
<tr>
<td>13</td>
<td>还款接口</td>
<td></td>
</tr>
<tr>
<td>14</td>
<td>还款详情列表</td>
<td></td>
</tr>
<tr>
<td>15</td>
<td>提前结清</td>
<td></td>
</tr>
</tbody>
</table>
<p><strong>联调: 15 人天</strong></p>
<h3>我的 + 还款记录 (张翔)</h3>
<table>
<thead>
<tr>
<th>Name</th>
<th>API</th>
<th>desc</th>
</tr>
</thead>
<tbody>
<tr>
<td></td>
<td>显示员工信息，姓名，手机号，绑卡信息</td>
<td>可合并到login API ?</td>
</tr>
<tr>
<td></td>
<td>获取存管账户余额</td>
<td>提现后会更新</td>
</tr>
<tr>
<td></td>
<td>已有(获取跳转收银台绑卡URL)</td>
<td></td>
</tr>
<tr>
<td></td>
<td>已有(获取跳转存管URL)</td>
<td></td>
</tr>
<tr>
<td></td>
<td>获取提现银行页URL</td>
<td></td>
</tr>
<tr>
<td></td>
<td>还款记录列表</td>
<td></td>
</tr>
</tbody>
</table>
<p><strong>联调:  4人天</strong></p>
<h3>借款记录</h3>
<table>
<thead>
<tr>
<th>Name</th>
<th>API</th>
<th>desc</th>
</tr>
</thead>
<tbody>
<tr>
<td></td>
<td>获取借款记录</td>
<td></td>
</tr>
<tr>
<td></td>
<td>获取借款明细</td>
<td></td>
</tr>
<tr>
<td></td>
<td>获取还款计划</td>
<td>是否是和申请页的“还款计划列表” 同一个API？</td>
</tr>
<tr>
<td></td>
<td>获取合同中动态信息</td>
<td>有多份合同，数据量不大的话，公用一个API？</td>
</tr>
</tbody>
</table>
<h3>后台管理</h3>
<table>
<thead>
<tr>
<th>Name</th>
<th>API</th>
<th>desc</th>
</tr>
</thead>
<tbody>
<tr>
<td></td>
<td>获取订单列表 + 查询</td>
<td></td>
</tr>
<tr>
<td></td>
<td>新增</td>
<td></td>
</tr>
<tr>
<td></td>
<td>操作</td>
<td></td>
</tr>
<tr>
<td></td>
<td>最简的认证，授权(邮箱验证码等)</td>
<td>TBD</td>
</tr>
</tbody>
</table>
<p><strong>联调:  4人天</strong></p>
<h2>技术或接口问题</h2>
<ul>
<li>钱包到首页的入口，需要带什么样的数据到首页？ 如果是很多加密的数据，需要POST HTTP服务</li>
<li>大额员工可见判断API or 用户信息API?</li>
</ul>
<h2>业务问题</h2>
<blockquote>
<p>PM 已经回答</p>
</blockquote>
<ol>
<li>
<p>已经有一笔贷款的员工是否还能进入首页？</p>
<blockquote>
<p>可以</p>
</blockquote>
</li>
<li>
<p>已经申请过的员工能否看到首页“立即申请”按钮？</p>
<blockquote>
<p>可以，弹出提示&quot;已有一笔借款，请还清后再申请！&quot;</p>
</blockquote>
</li>
<li>
<p>没有申请过贷款的员工进入首页，是否能看到 右上角的借款记录 和 下方tabs里面的还款？</p>
<blockquote>
<p>右上角的借款记录  去掉，下方tabs里面的还款&amp;&amp;我的 可见</p>
</blockquote>
</li>
<li>
<p>首页原型稿，右上角“借款记录”是否多余，“我的”里面也可以看到“借款记录“</p>
<blockquote>
<p>右上角的借款记录  去掉</p>
</blockquote>
</li>
<li>
<p>申请页面，借款金额拖拉的最小金额数？500? 1000?</p>
<blockquote>
<p>500</p>
</blockquote>
</li>
<li>
<p>确认银行卡页， “添加/更换银行卡” 应该放在 “开通存管”控件的上面，当没有银行卡时，隐藏“开通存管”控件。</p>
<blockquote>
<p>没有银行卡，点击开通存管，提示“请先绑定银行卡！”</p>
</blockquote>
</li>
<li>
<p>申请成功后， &quot;审核中&quot;按钮是否多余。如果需要点击“审核中”后才能放款, 能否合并，那么如果用户没有点，下次进入“首页“, 再次        点击申请，应该重新走完整申请交互流程？还是直接显示上次申请成功的页面？</p>
<blockquote>
<p>审核中不需要点击，等后台状态直接到审核拒绝页面或者放款中页面
点击申请按钮
a. 未走完流程的订单直接跳到对应的节点
b. 还款中订单，提示&quot;已有一笔借款，请还清后再申请！&quot;
c. 非准入或拒绝的客户跳转无额度页面</p>
</blockquote>
</li>
<li>
<p>&quot;我的&quot;页面里，无存管账户的 员工 click“提现”， 应该提示 用户“存管 未开通” 还是带他 去“申请”?</p>
<blockquote>
<p>无存管账户， 展示 “暂无数据”  &amp;&amp;  “去开户”
去开户 跳转确认银行卡页面，开户完成返回</p>
</blockquote>
</li>
<li>
<p>&quot;我的&quot;页面里, &quot;银行卡&quot; 是否可以更换: &quot;申请&quot;时候可以更换，申请之后，在&quot;我的&quot;页面是否可以更换?</p>
<blockquote>
<p>申请成功之后不可更换，新申请流程中可更换</p>
</blockquote>
</li>
<li>
<p>还款记录页右上角“日历”图标暂时是不需要的？</p>
<blockquote>
<p>“日历”图标去掉</p>
</blockquote>
</li>
<li>
<p>后台“操作“的业务功能有哪些？</p>
<blockquote>
<p>业务功能只有线下审核功能</p>
</blockquote>
</li>
</ol>
<h3>Nonfunctional</h3>
<ul>
<li>
<p>首页登录失败(包括未实名或其他网络错误)， 需要跳转到 一个错误页面，组织用户继续操作</p>
<blockquote>
<p>原型增加错误页</p>
</blockquote>
</li>
<li>
<p>可配置的 “员工大额“可见度全局开关</p>
<blockquote>
<p>后端系统实现</p>
</blockquote>
<blockquote>
<p>刘晶： 前端需要配置静态发布，最好不是每个用户访问时动态查询开关</p>
</blockquote>
</li>
</ul>
<h2>需要先出原型效果或视觉设计的部分</h2>
<ul>
<li>首页员工大额, 员工小额, 员工贷助手 banner区域</li>
<li>员工贷助手页</li>
<li>首页tabs组件包括图标选型等</li>
<li>申请页面，借款金额拖拉的最小金额数的控件</li>
<li>确认银行卡页面的银行卡片显示控件</li>
<li>无需还款页面留白很多，设计背景和banner</li>
<li>“我的&quot;页面，“提现”按钮和背景banner区需要设计，设计主要强调“提现”按钮的call of action效果</li>
</ul>
<p><strong>原型效果复杂度：15 人天</strong>
</p>
<h2>具体案例分析评估</h2>
<h3>首页 use case (19 points) (张翔)</h3>
<p><em>黄色虚线框表示待定</em></p>
<pre><code class="language-mermaid">graph LR

user((员工))
user1((职级L4以下员工))
user2((职级L4以上员工))
small-loan(&quot;点击: &lt;br&gt;申请员工贷&lt;br&gt;小额借款&lt;br&gt;入口(1)&quot;)
large-loan(&quot;申请员工贷大额借款入口(2)&lt;br/&gt;1.暂时显示'敬请期待'&lt;br/&gt;2.对职级L4以下员工隐藏？&quot;)
helper(&quot;员工贷助手页面(3)&quot;)
risk(&quot;白名单或风控判断(2)&quot;)
quota(&quot;无额度页面(2)&quot;)
record(跳转到借款记录页面)
repay(跳转到还款页面)
my(&quot;跳转到'我的'页面&quot;)

classDef pending fill:#FFFF00,stroke:#f66,stroke-width:2px,stroke-dasharray: 5, 5
class record,repay pending

subgraph user
  user---judge[&quot;大额&lt;br&gt;员工可见&lt;br&gt;判断API&lt;br&gt;(判断员工职级)(1)&quot;]
  user---login(&quot;登录员工贷(3)&lt;br/&gt;1.涉及到node&quot;)
end

subgraph 分类
  user-.Include.-&gt;user1
  user-.Include.-&gt;user2
end

subgraph 首页
  user1---small-loan
  user1---helper
  user1---record

  user2---small-loan
  user2---large-loan
  user2---helper
  user2---record

  small-loan-.Include.-&gt;risk
  large-loan-.Include.-&gt;risk
  risk-.-&gt;quota
end

subgraph 下方tabs
  frame(&quot;看到&lt;br&gt;tabs组件&lt;br&gt;相应状态(5)&quot;)
  user1---repay
  user1---my
  user2---repay
  user2---my
end
</code></pre>
<h3>借款申请 + 还款 use cases (75 points) (余力）</h3>
<pre><code class="language-mermaid">graph LR
user((用户))
loan(借款申请)
repay(还款)

user --&gt; loan
loan --&gt; loan-page
user --&gt; repay
repay --&gt;|有未还| repay-page
repay --&gt;|无未还| repay-empty-page

loan-page(借款申&lt;br&gt;请页面&lt;br&gt;申请按钮&lt;br&gt;有效验证5p)
repay-plan(还款计划页面&lt;br&gt;2p)
agreement-list(员工贷相关&lt;br&gt;协议列&lt;br&gt;表页面&lt;br&gt;5p)
agreement-detail(员工贷相&lt;br&gt;关协议详情页面&lt;br&gt;3p)
confirm-bank(确认银行卡页面&lt;br&gt;5p)
contract(签约页面&lt;br&gt;2p)
apply-success(申请成功页&lt;br&gt;1p)
apply-fail(申请失败页&lt;br&gt;1p)
loan-success(放款中页面&lt;br&gt;1p)

repay-page(正常还款页面&lt;br&gt;5p)
repay-empty-page(无需还款页面&lt;br&gt;1p)

loan-page --&gt;loan-api
loan-page --&gt; loan-static
loan-api(API&lt;br&gt;3p&lt;BR&gt;1.借款金额范围&lt;/br&gt;2.首期还款试算&lt;br&gt;3.借款用途)
loan-static(固定值&lt;br&gt;1.小额固定 3 个月&lt;br&gt;2.还款日固定 每月15日)
loan-page--&gt;|错误|error
error(错误&lt;br&gt;异常处理&lt;br&gt;5p)

loan-page --&gt;|员工贷相关协议| agreement-list
agreement-list --&gt;agreement-detail
agreement-list  --&gt; agreement-static
agreement-static(固定值&lt;br&gt;列表内容固定)

loan-page--&gt; |每期还款|repay-plan
repay-plan --&gt; repay-plan-api 
repay-plan-api(API&lt;br&gt;1p&lt;BR&gt;1.还款计划列表)

loan-page --&gt; |申请借款|confirm-bank
confirm-bank --&gt; confirm-bank-api(API&lt;br&gt;3p&lt;/br&gt;1.借款人姓名/身份证/所属银行/卡号 &lt;br&gt;2.存管状态&lt;/br&gt;3.已绑银行卡列表 )
confirm-bank --&gt;confirm-bank-callback(回调&lt;br&gt;5p&lt;br&gt;1.收银台回调&lt;br&gt;2.存管回调)
confirm-bank --&gt;|开通存管|check-status(if 未绑卡未开户&lt;br&gt;提示先去绑卡&lt;br&gt;if 已绑卡未开户&lt;br&gt;跳转存管&lt;br&gt;if 已开户&lt;br&gt;显示已开户) 
check-status --&gt; check-status-api(API&lt;br&gt;2p&lt;BR&gt;1.跳转存管)
confirm-bank --&gt;|添加银行卡/更换银行卡|card-system-api(API&lt;br&gt;2p&lt;br&gt;1.跳转收银台)
confirm-bank --&gt;|错误|error

confirm-bank --&gt;|确定并继续| contract


contract --&gt; contract-api(API&lt;br&gt;2p&lt;br&gt;1.借款信息)
contract --&gt;|确认借款| contract-sms(确认借款短信验证提示框&lt;br&gt;2p)
contract --&gt;|错误|error
contract --&gt;|点击协议|agreement-detail
contract-sms --&gt;contract-sms-api(API&lt;br&gt;3p&lt;BR&gt;1.短信接口&lt;br&gt;2. 借款申请)
contract-sms -.-&gt;|取消|contract
contract-sms --&gt;|申请成功| apply-success
contract-sms --&gt;|申请失败| apply-fail
apply-success --&gt; apply-success-api(API&lt;br&gt;2p&lt;br&gt;1.放款接口)
apply-success --&gt;|放款成功| loan-success

repay-page --&gt; repay-page-api(API&lt;br&gt;3p&lt;BR&gt;1.最近待还列表&lt;br&gt;2.累计待还)
repay-page --&gt; |去还款|repay-confirm(确认还款提示框&lt;br&gt;2p)
repay-page --&gt;|错误|error


repay-confirm --&gt;|确认|repay-confirm-api(API&lt;br&gt;2p&lt;br&gt;1.还款接口)
repay-confirm -.-&gt;|取消|repay-page
repay-page --&gt;|提前结清| pre-pay(提前结清页面 3p)

pre-pay--&gt;pre-pay-api(API&lt;br&gt;2p&lt;br&gt;1.还款详情列表)
pre-pay --&gt;|提前结清|pre-pay-confirm-api(API&lt;br&gt;2p&lt;br&gt;1.提前结清)
pre-pay --&gt;error


style loan-api fill:#ffeb3b
style repay-plan-api fill:#ffeb3b
style confirm-bank-api fill:#ffeb3b
style check-status-api fill:#ffeb3b
style contract-api fill:#ffeb3b
style repay-page-api fill:#ffeb3b
style card-system-api fill:#ffeb3b
style contract-sms-api fill:#ffeb3b
style apply-success-api fill:#ffeb3b
style repay-confirm-api fill:#ffeb3b
style pre-pay-api fill:#ffeb3b
style pre-pay-confirm-api fill:#ffeb3b

style loan-static fill:#03a9f4
style agreement-static fill:#03a9f4


style error fill:#ff5722

style confirm-bank-callback fill:#4caf50

</code></pre>
<h3>“我的” (张翔)</h3>
<pre><code class="language-mermaid">graph LR
  my-discount
  bind

  subgraph user
  userNoAct((无存管&lt;br&gt;账户的&lt;br&gt;员工)) 
  userNoCard((&quot;没绑卡&lt;br&gt;(&amp;无存管)&quot;))
  user((员工))

  end

  subgraph '我的'页面
  userNoAct --&gt; seeCreateActBtn(&quot;click“提现”，&lt;br&gt;应该提示&lt;br&gt;用户“存管&lt;br&gt;未开通”&lt;br&gt;还是带他&lt;br&gt;去“申请”?&quot;)
userNoCard --&gt; seeCreateActBtn
  	user---info(&quot;显示员工信息，姓名，手机号，绑卡信息(2)&lt;br/&gt;1.api查询&lt;br/&gt;2.显示&quot;)
    user---amount(&quot;查看存管账户余额(2)&lt;br/&gt;1.未开通存管显示开通入口&lt;br/&gt;2.确定开通后查询余额&quot;)
    user---bind(&quot;银行卡(2)&lt;br/&gt;1.显示已绑定卡的信息&lt;br/&gt;2.未绑卡，点击跳转到添加银行卡页面&quot;)
    bind-.Include.-&gt;addCard(&quot;添加银行卡页面(3)&lt;br/&gt;1.增加添加银行卡提示，按钮&lt;br/&gt;2.获取绑卡地址&lt;br/&gt;3.跳转到钱包绑卡&quot;)
    
    user---create(&quot;存管开户(3)&lt;br/&gt;1.确定已经绑卡&lt;br/&gt;2.获取存管开户地址&lt;br/&gt;3.跳转到新网开户&quot;)
    create-.Include.-&gt;alertCreate(&quot;提示需要先绑卡(1)&quot;)
    user---withdraw(&quot;提现(3)&lt;br/&gt;1.判断能否提现&lt;br/&gt;1.获取提现地址&lt;br/&gt;2.跳转到银行页面提现&quot;)
    withdraw-.Include.-&gt;alertWithdraw(&quot;无法提现提示(1)&quot;)
    user---loan-record(&quot;查看借款记录&quot;)
    user---repayment-record(&quot;查看还款记录(3)&lt;br/&gt;1.api查询还款记录&lt;br/&gt;2.显示还款列表&lt;br/&gt;3.若无记录，显示暂无记录&lt;br/&gt;4.分页？&quot;)
    user---my-discount(&quot;查看我的优惠(2)&quot;)
    user---helper(&quot;查看贷款助手页面&quot;)
    user---about(&quot;关于我们页面(2)&quot;)

 classDef pending fill:#FFFF00,stroke:#f66,stroke-width:2px,stroke-dasharray: 5, 5
  class my-discount,bind,seeCreateActBtn pending
  end
</code></pre>
<h3>借款记录 use cases(9 points) (张翔)</h3>
<pre><code class="language-mermaid">graph LR
  contract

  classDef pending fill:#FFFF00,stroke:#f66,stroke-width:2px,stroke-dasharray: 5, 5
  class contract pending

  subgraph user
    user((员工))
  end

  subgraph '我的'页面中的借款记录
    user---list(&quot;查看借款记录列表(3)&lt;br/&gt;1.api查询&lt;br/&gt;2.显示列表&lt;br/&gt;3.显示无借款记录&lt;br/&gt;4.分页？&quot;)
    user---detail(&quot;查看借款明细(2)&lt;br/&gt;1.api查询&quot;)
    user---plan(&quot;查看还款计划(2)&lt;br/&gt;1.api查询&quot;)
    plan --&gt;|extend|repay-plan(&quot;申请页的&lt;br&gt;还款计划&quot;)
    user---contract(&quot;查看合同(余力)(2)&quot;)
    contract --&gt;|extend|protocals(&quot;员工贷&lt;br&gt;相关协&lt;br&gt;议列表&quot;)
    contract --&gt; contractAPI[&quot;合同动态&lt;br&gt;信息API&quot;]
  end
</code></pre>
<h3>员工贷后台（14 - 28+ points）(张翔)</h3>
<p><em>黄色虚线框表示待定</em></p>
<pre><code class="language-mermaid">graph LR
  auth
  alpha

  classDef pending fill:#FFFF00,stroke:#f66,stroke-width:2px,stroke-dasharray: 5, 5
  class auth,alpha pending

  subgraph user
    user((user))
  end

  subgraph 后台
    design(&quot;设计和部署(2)&quot;)
    user---login(&quot;登录（2）&quot;)
    user---auth(&quot;权限管理&lt;br/&gt;需要和后端讨论&quot;)
    user---approve(&quot;线下审批&quot;)
    approve-.Include.-&gt;search(&quot;根据工号姓名查询员工(2)&lt;br/&gt;1.精准查询&lt;br/&gt;2.模糊查询&quot;)
    approve-.Include.-&gt;list(&quot;显示员工列表(5)&lt;br/&gt;1.排序&lt;br/&gt;2.分页&lt;br/&gt;3.将生效记录置为失效&quot;)
    approve-.Include.-&gt;add(&quot;新增一笔员工额度(3)&lt;br/&gt;1.弹框显示表单&lt;br/&gt;2.新增后调用HR系统检查数据准确性&lt;br/&gt;3.如有误提示错误&quot;)
    alpha(&quot;接入alpha系统(预计14+)&lt;br/&gt;1.熟悉alpha系统&lt;br/&gt;2.如何接入alpha系统？&lt;br&gt;技术栈适配(Web component)&lt;br/&gt;4.如何部署，测试，联调？&lt;br/&gt;5.上线或者修改是否要按照对方的版本周期？&lt;br/&gt;6.技术栈不同导致的学习成本&lt;br/&gt;&quot;)
  end
</code></pre>
