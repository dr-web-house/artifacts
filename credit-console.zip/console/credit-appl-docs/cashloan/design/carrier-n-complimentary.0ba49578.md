<h3>认证运营商: 5 points</h3>
<pre><code class="language-mermaid">graph LR
actor((用户))
actor --&gt; |1.| submitForm(&quot;录入认证&lt;br&gt;输入表单&lt;br&gt;‘服务密码’&quot;)
actor --&gt; |2.| clickSubmit(&quot;点击&lt;br&gt;提交认证&quot;)
clickSubmit -.-&gt; |1.| apiGetToken[&quot;API:&lt;br&gt;get token&lt;br&gt; + send SMS&quot;]
actor --&gt; |3.| smsInputDialog(&quot;(再次)看到&lt;br&gt;验证码&lt;br&gt;输入框&quot;)
smsInputDialog -.-&gt;|2. include| clickSubmitSms(&quot;输入+&lt;br&gt;点击确&lt;br&gt;认验证码&quot;)
clickSubmitSms -.-&gt; |1. include| apiGetToken
clickSubmitSms -.-&gt; |2. 跳转|in-progress
smsInputDialog -.-&gt;|1. include| smsCoundDown(&quot;看到发送验&lt;br&gt;证码按钮&lt;br&gt;disabled +&lt;br&gt;倒计时开始&quot;)
wait-submit -.-&gt; |跳转|smsInputDialog
smsInputDialog -.-&gt; |2. include| clickGetSms(&quot;点击&lt;br&gt;重新发&lt;br&gt;送短信&quot;)
clickGetSms -.-&gt; apiSendSms[&quot;API: send SMS&quot;]

clickSubmit -.-&gt; |2. 跳转| in-progress
actor --&gt; |4.| in-progress(&quot;看到&lt;br&gt;'处理中...'&quot;)
in-progress -.-&gt; apiGetStatus{API: poll &lt;br&gt;获取状态}
apiGetStatus --- wait-submit[wait-submit&lt;br&gt;要短信&lt;br&gt;验证码]
apiGetStatus --- get-token[wait-to-&lt;br&gt;get-token&lt;br&gt;计数+1]
get-token -.-&gt; |无需用户点击|clickSubmit

actor --&gt; |5.| inlineMsg(&quot;看到提示&lt;br&gt;认证不成功&lt;br&gt;可以稍后重试&quot;)
get-token -.-&gt;|超过n次数|inlineMsg

submitForm -.-&gt;|include| inlineHelper(&quot;看到&lt;br&gt;inline提示:&lt;br&gt;用户可能会&lt;br&gt;需要多次&lt;br&gt;输入短信&lt;br&gt;验证码&quot;)
submitForm -.-&gt;|include| forgetPass(&quot;Forget&lt;br&gt;service&lt;br&gt;password&lt;br&gt;...???(1)&quot;)
submitForm -.-&gt; |include| agreement(&quot;查看&amp;勾选&lt;br&gt;获取运营商&lt;br&gt;信息协议&lt;br&gt;...&quot;)

classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;
class apiGetToken,apiSendSms,apiGetStatus api
class forgetPass module
class get-token,wait-submit question

</code></pre>
<h3>录入补充信息表单 3 points</h3>
<pre><code class="language-mermaid">graph LR
user2((User))

user2 --&gt; complimentaryForm(&quot;录入补充信息表单(3)&quot;)
complimentaryForm -.-&gt; selectFields(&quot;Show 3 selectable&lt;br&gt;fields&quot;)
complimentaryForm -.-&gt; getLocation(&quot;get device&lt;br&gt;location+&lt;br&gt;show in field...&quot;)
complimentaryForm -.-&gt; contacts(&quot;input contacts&quot;)
contacts --- question(&quot;How many&lt;br&gt;contacts do we need?&quot;)
complimentaryForm -.-&gt; validateComp(&quot;validation&quot;)
complimentaryForm -.-&gt; submitComp(&quot;submit&lt;br&gt;form +&lt;br&gt;call API&quot;)

classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;
class sms,submit,submitComp api
class forgetPass module
class question,forgetPass question
</code></pre>
