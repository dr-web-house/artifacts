<h3>激活额度场景 14 points</h3>
<pre><code class="language-mermaid">graph LR
classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;

activateSteps(&quot;access:&lt;br&gt;'激活额度'&lt;br&gt;123步骤列表&quot;)
getActivateStatus[&quot;查询显示&lt;br&gt;1.上传身份证、&lt;br&gt;2.运营商'已认证'&lt;br&gt;状态 + &lt;br&gt;1，2&lt;br&gt;enablement(2)&quot;]
submitActivate(&quot;click提交&lt;br&gt;激活额度(3)&quot;)
activateBacks(&quot;点击各个&lt;br&gt;页面的&lt;br&gt;返回按钮(1)&quot;)
checkCarrier(&quot;运营商&lt;br&gt;认证...(5)&quot;)
complementaryInfo(&quot;录入补&lt;br&gt;充信息&lt;br&gt;...(3)&quot;)
activateApi[&quot;申请额&lt;br&gt;度API&quot;]
wait4result(显示等待)
resultFail(显示申请失败)
resultSuccess(结果成功&lt;br&gt;显示&lt;br&gt;'我的额度'&lt;br&gt;...)


subgraph 引导页 场景
	activateCredit(&quot;click&lt;br&gt;立即申请&lt;br&gt;显示:&lt;br&gt;激活额度...&quot;)
end

class ocrApi,activateApi,uploadIdCard,getActivateStatus,confirmIdCardApi api
class checkCarrier,identification,complementaryInfo,resultSuccess module

actor((&quot;User&quot;))
actor --&gt; activateCredit

activateCredit -.-&gt;|include| activateSteps
activateSteps -.-&gt; getActivateStatus
activateSteps -.-&gt; submitActivate
submitActivate -.-&gt; activateApi
submitActivate -.-&gt; wait4result
submitActivate -.-&gt; resultFail
submitActivate -.-&gt; resultSuccess
activateSteps -.-&gt;|include &lt;br&gt;没有认证过| checkCarrier


activateSteps -.-&gt; activateBacks
activateSteps -.-&gt; complementaryInfo
</code></pre>
