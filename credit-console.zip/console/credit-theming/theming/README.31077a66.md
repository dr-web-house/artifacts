<h1>Customized theme base on Angular Material</h1>
<p>Doc<br>
<a href="https://material.angular.io/guide/theming-your-components">https://material.angular.io/guide/theming-your-components</a></p>
<p>Above offical is incorrect, the only way to define a new theme is to follow<br>
<a href="https://github.com/angular/material2/issues/5152">https://github.com/angular/material2/issues/5152</a></p>
<h2>Color</h2>
<p><a href="https://material.io/tools/color/#!/?view.left=0&amp;view.right=0&amp;primary.color=407bd7&amp;secondary.color=536DFE&amp;primary.text.color=fafafa&amp;secondary.text.color=FAFAFA">Color definition and tool</a></p>
<h3>How to get css color for component</h3>
<p>Material Theme data structure</p>
<pre><code class="language-yaml">	<span class="hljs-attr">primary:</span> <span class="hljs-string">$primary,</span>
		<span class="hljs-attr">default:</span> <span class="hljs-string">map-get($base-palette,</span> <span class="hljs-string">$default),</span>
		<span class="hljs-attr">lighter:</span> <span class="hljs-string">map-get($base-palette,</span> <span class="hljs-string">$lighter),</span>
		<span class="hljs-attr">darker:</span> <span class="hljs-string">map-get($base-palette,</span> <span class="hljs-string">$darker),</span>

		<span class="hljs-attr">default-contrast:</span> <span class="hljs-string">mat-contrast($base-palette,</span> <span class="hljs-string">$default),</span>
		<span class="hljs-attr">lighter-contrast:</span> <span class="hljs-string">mat-contrast($base-palette,</span> <span class="hljs-string">$lighter),</span>
		<span class="hljs-attr">darker-contrast:</span> <span class="hljs-string">mat-contrast($base-palette,</span> <span class="hljs-string">$darker)</span>
		<span class="hljs-number">50.</span><span class="hljs-string">..900,A100,A200,A400,A700</span>
	<span class="hljs-attr">accent:</span> <span class="hljs-string">$accent,</span>
	<span class="hljs-attr">warn:</span> <span class="hljs-string">$warn,</span>
	<span class="hljs-attr">is-dark:</span> <span class="hljs-literal">false</span><span class="hljs-string">,</span>
	<span class="hljs-attr">foreground:</span> <span class="hljs-string">$mat-light-theme-foreground,</span>
		<span class="hljs-attr">base:</span>              <span class="hljs-string">black,</span>
		<span class="hljs-attr">divider:</span>           <span class="hljs-string">$dark-dividers,</span>
		<span class="hljs-attr">dividers:</span>          <span class="hljs-string">$dark-dividers,</span>
		<span class="hljs-attr">disabled:</span>          <span class="hljs-string">$dark-disabled-text,</span>
		<span class="hljs-attr">disabled-button:</span>   <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.26</span><span class="hljs-string">),</span>
		<span class="hljs-attr">disabled-text:</span>     <span class="hljs-string">$dark-disabled-text,</span>
		<span class="hljs-attr">hint-text:</span>         <span class="hljs-string">$dark-disabled-text,</span>
		<span class="hljs-attr">secondary-text:</span>    <span class="hljs-string">$dark-secondary-text,</span>
		<span class="hljs-attr">icon:</span>              <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.54</span><span class="hljs-string">),</span>
		<span class="hljs-attr">icons:</span>             <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.54</span><span class="hljs-string">),</span>
		<span class="hljs-attr">text:</span>              <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.87</span><span class="hljs-string">),</span>
		<span class="hljs-attr">slider-min:</span>        <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.87</span><span class="hljs-string">),</span>
		<span class="hljs-attr">slider-off:</span>        <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.26</span><span class="hljs-string">),</span>
		<span class="hljs-attr">slider-off-active:</span> <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.38</span><span class="hljs-string">),</span>
	<span class="hljs-attr">background:</span> <span class="hljs-string">$mat-light-theme-background,</span>
		<span class="hljs-attr">status-bar:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">300</span><span class="hljs-string">),</span>
		<span class="hljs-attr">app-bar:</span>    <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">100</span><span class="hljs-string">),</span>
		<span class="hljs-attr">background:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">50</span><span class="hljs-string">),</span>
		<span class="hljs-attr">hover:</span>      <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.04</span><span class="hljs-string">),</span> <span class="hljs-string">//</span> <span class="hljs-string">TODO(kara):</span> <span class="hljs-string">check</span> <span class="hljs-string">style</span> <span class="hljs-string">with</span> <span class="hljs-string">Material</span> <span class="hljs-string">Design</span> <span class="hljs-string">UX</span>
		<span class="hljs-attr">card:</span>       <span class="hljs-string">white,</span>
		<span class="hljs-attr">dialog:</span>     <span class="hljs-string">white,</span>
		<span class="hljs-attr">disabled-button:</span> <span class="hljs-string">rgba(black,</span> <span class="hljs-number">0.12</span><span class="hljs-string">),</span>
		<span class="hljs-attr">raised-button:</span> <span class="hljs-string">white,</span>
		<span class="hljs-attr">focused-button:</span> <span class="hljs-string">$dark-focused,</span>
		<span class="hljs-attr">selected-button:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">300</span><span class="hljs-string">),</span>
		<span class="hljs-attr">selected-disabled-button:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">400</span><span class="hljs-string">),</span>
		<span class="hljs-attr">disabled-button-toggle:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">200</span><span class="hljs-string">),</span>
		<span class="hljs-attr">unselected-chip:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">300</span><span class="hljs-string">),</span>
		<span class="hljs-attr">disabled-list-option:</span> <span class="hljs-string">map_get($mat-grey,</span> <span class="hljs-number">200</span><span class="hljs-string">),</span>
</code></pre>
<p>Use <strong>app-color()</strong> and <strong>app-color-contrast()</strong></p>
<pre><code class="language-scss">app-<span class="hljs-attribute">color</span>(primary|accent|warn)
app-<span class="hljs-attribute">color</span>(primary|accent|warn|foreground|<span class="hljs-attribute">background</span>, lighter|darker|text|card, <span class="hljs-attribute">opacity</span>)
app-<span class="hljs-attribute">color</span>-contrast(primary|accent|warn)
app-<span class="hljs-attribute">color</span>-contrast(primary|accent|warn, lighter|darker, <span class="hljs-attribute">opacity</span>)
</code></pre>
<p><code>@function mat-color($palette, $hue|$opacity)</code></p>
<pre><code class="language-css">@<span class="hljs-keyword">import</span> <span class="hljs-string">"~@bk/credit-theming/theming/variables"</span>;

<span class="hljs-selector-class">.submit</span> {
	<span class="hljs-attribute">color</span>: <span class="hljs-built_in">app-color-contrast</span>(primary);
	<span class="hljs-attribute">background-color</span>: <span class="hljs-built_in">app-color</span>(primary);
}
<span class="hljs-selector-class">.help</span> {
	<span class="hljs-attribute">color</span>: <span class="hljs-built_in">app-color-contrast</span>(accent);
	<span class="hljs-attribute">background-color</span>: <span class="hljs-built_in">app-color</span>(accent);
}
</code></pre>
<h3>Concept</h3>
<pre><code class="language-mermaid">graph LR
Theme

$primary -.-&gt; Palette
$accent -.-&gt; Palette
$warn -.-&gt; Palette

mat-light-theme[function&lt;br&gt;mat-light-theme]

$primary --&gt; |input |mat-light-theme
$accent --&gt; |input |mat-light-theme
$warn --&gt; |input |mat-light-theme

$mat-blue(Color Map&lt;br&gt;$mat-blue)

mat-light-theme --&gt; Theme
Palette --&gt; |part of | Theme
mat-palette[function&lt;br&gt;mat-palette]

defaultCol(&quot;$default&quot;) --&gt;|input|mat-palette
$light --&gt;|input| mat-palette
$dark --&gt;|input| mat-palette

$mat-blue --&gt; |input| mat-palette

Color --&gt; |* - 1| Palette

mat-palette --&gt; |create| $primary

classDef type fill:#a0b0a0,stroke:white;
classDef func fill:cyan;
class mat-light-theme,mat-palette func
class Theme,Palette,Color type
</code></pre>
