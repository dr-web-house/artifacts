<h1>Web Frontend/Fullstack 开发/高级开发</h1>
<p>我们正在寻找出色的，对用户体验有深刻理解的，或具备全栈能力的web开发工程师，你会成为一个核心金融业务产品团队的成员，你的工作成果将会直接影我们的用户体验，并且被复用在不同的产品中. 我们不仅致力实现有竞争力的产品和业务方案，更希望借助高复用性和平台化的技术方案持续的推进产品创新和行业影响力。</p>
<p>我们希望你对高可用性和可测试性的前端技术有热情，对不断演进的框架技术都又乐于学习，有团队精神。</p>
<h2>What you will be doing</h2>
<ul>
<li>参与业务逻辑，交互实现的评估和设计</li>
<li>实现注重细节、性能、体验出色的跨平台兼容性UI，基于Angular 6等技术</li>
<li>和team一起讨论和头脑风暴解决方案，PoC 及原型实现</li>
<li>peer-reviewed，End-to-end test covered 高质量代码实现</li>
<li>复用组件贡献，开发体验优化工具的开发，showcase开发和文档站</li>
<li>参与CI流程改进和产品发布管理</li>
<li>服务端中间层基于 Node.js Express等技术实现</li>
</ul>
<h2>About you</h2>
<h4>学历及专业要求</h4>
<p>计算机软件及相关专业本科</p>
<h4>相关行业及技术的工作年限</h4>
<p>大于2年</p>
<h3>能力</h3>
<ul>
<li>有面向对象高级计算机语言基础，英语阅读能力。</li>
<li>主流Web前端框架, Angular, React等精通至少1种</li>
<li>掌握跨设备的HTML5, CSS3 (LESS/SASS), DOM, HTTP的相关知识</li>
<li>Javascript 基础扎实, 有Typescript开发经验优先.</li>
<li>对lodash, rxjs等第三方库熟悉, 使用过Webpack或Browserify等工具。</li>
<li>掌握Node.js，有npm, yarn等技术和工具的经验。</li>
<li>了解BDD/TDD，了解Jasmine2等测试框架。</li>
<li>能编写有可维护性高，复用性高的代码。</li>
<li>有需求分析经验，用例或流程图和测试案例设计有经验。</li>
<li>不畏惧便携服务端Node.js代码。</li>
</ul>
<h3>除此之外，如果你具备以下能力，我们优先期待你的加入：</h3>
<ul>
<li>有可showcase的代码展示个人对技术的理解。</li>
<li>有Mobile hybrid App经验，Cordava等开发经验。</li>
<li>参与过server端API开发, 理解RESTful API的设计</li>
<li>使用过server端渲染技术, 掌握Web服务端框架技术Express.js/Koa</li>
<li>了解同构isomorphic技术, 有优化SEO的经验</li>
<li>理解Webpack, 开发过Webpack的插件</li>
</ul>
<p>对客户端动效有热情：</p>
<ul>
<li>使用过SVG, Canvas等技术</li>
<li>熟悉CSS/JS based transition, animation技术，相关第三方framework和库。</li>
<li>有简单的响应式UI设计的经验，使用过Photoshop或Sketch等工具。</li>
</ul>
<h2>Culture &amp; Perks</h2>
<ul>
<li>Show off yourself, 有机会直接参与打造开源的团队平台，贡献作品库。</li>
<li>分享, 面对一家大型互联网金融公司中各种职能的团队，你会直接面对各种设计，业务需求团队，接触到到来自金融、工程、设计领域的知识分享。</li>
<li>弹性, 我们相信必要的弹性和灵活的工作制度, 适当的工作压力，有利于团队的持续产出高质量且有品位产品.</li>
<li>位于新天地中心交通便捷的办公地点</li>
</ul>
