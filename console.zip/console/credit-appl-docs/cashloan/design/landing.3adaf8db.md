<h3>引导页 场景 4 points</h3>
<pre><code class="language-mermaid">graph LR
classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;

landing[&quot;access&lt;br&gt;引导页&quot;]
banner[&quot;引导页banner...(2)&quot;]
seeAgreement(&quot;申请及授&lt;br&gt;权协议(1)&quot;)
clickAgreement(&quot;点击‘申请及&lt;br&gt;授权协议’,&lt;br&gt;能看见协议内容&quot;)
urlAgreement(&quot;访问/cach-loan/&lt;br&gt;agreement/02,&lt;br&gt;能看见协议内容&quot;)
closeAgreement(&quot;关闭‘申请&lt;br&gt;及授权协议’&lt;br&gt;能看到引导页&quot;)
consentAgree(&quot;点击同意&lt;br&gt;协议radio button,&lt;br&gt;立即同意&lt;br&gt;button enabled(1)&quot;)
activateCredit(&quot;click立即申请&lt;br&gt;显示: &lt;br&gt;激活额度...&quot;)

landing -.-&gt;|include 1.| banner
landing --&gt; |2.|seeAgreement
seeAgreement -.-&gt; |include 1.|clickAgreement
seeAgreement -.-&gt; |include 1.|urlAgreement
seeAgreement -.-&gt; |include 2.| closeAgreement
landing --&gt;|3.| consentAgree
landing --&gt; |4.|activateCredit

class banner,activateCredit,wallet,inProgress,cashOut,signDeal,inReview module
</code></pre>
