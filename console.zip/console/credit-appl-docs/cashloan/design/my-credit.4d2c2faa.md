<h3>我的额度 23 points</h3>
<pre><code class="language-mermaid">graph LR

actor((User&lt;br&gt;已激活)) --&gt; navigateTo(&quot;打开钱包&lt;br&gt;点击我的额度&lt;br&gt;判断&quot;)
navigateTo -.-&gt; myCredit(&quot;access:&lt;br&gt; 我的&lt;br&gt;额度首页(2)&quot;)
actor --&gt; backFromWalletPay(&quot;back from&lt;br&gt;从收银台&lt;br&gt;还款(1)&quot;)
actor --&gt; backFromSelectCard(&quot;back from&lt;br&gt;收银台选收款账户&quot;)
actor --&gt; backFromIdent(&quot;从活体&lt;br&gt;识别返回&lt;br&gt;...TBD (1)&quot;)
backFromWalletPay -.-&gt; repaymentList(&quot;还款详情(3)&quot;)

myCredit -.-&gt; borrow(&quot;我要提&lt;br&gt;现...&quot;)
backFromIdent -.-&gt; borrow

borrow -.-&gt; clickRealName(&quot;实名认证...&quot;)
borrow -.-&gt; disallow(&quot;提示不能提现的2中情况...&quot;)

borrow -.-&gt; borrowHistory(&quot;取现记录&lt;br&gt;就是&lt;br&gt;借款记录?&quot;)
borrow -.-&gt; borrowForm(&quot;fill in&lt;br&gt;form...(3)&quot;)
borrowForm --&gt; amountRangeApi
borrowForm -.-&gt; selectCard(&quot;收银台&lt;br&gt;选收款账户(1)&quot;)
backFromSelectCard -.-&gt; borrowForm
borrow -.-&gt; repaymentPlan(&quot;还款&lt;br&gt;计划(1)&quot;)
repaymentPlan -.-&gt; |extend| repaymentList

myCredit -.-&gt; loanHistory(&quot;借款记录&lt;br&gt;...(3)&quot;)
myCredit -.-&gt; myCreditProb(&quot;不再需要&lt;br&gt;确认卡和&lt;br&gt;审核流程&quot;)
myCredit -.-&gt; repayment(&quot;Normal&lt;br&gt;Repayment&lt;br&gt;...(3)&quot;)
loanHistory -.-&gt; repaymentPlan
loanHistory -.-&gt; repaymentList
loanHistory -.-&gt; |extend| loanPagination(&quot;Pagination(2)&quot;)
repaymentPlan -.-&gt; |extend| loanPagination
repaymentList -.-&gt; |extend| loanPagination
loanHistory -.-&gt; loanDetails(&quot;借款详情(1)&quot;)
loanHistory -.-&gt; loanContract(&quot;合同(2)&quot;)

classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;

class loanHistory,questions,repayment,borrowForm,clickRealName module

class apiLogin,apiIsActivated,apiHasCard,apiIsWIP,ocrApi,activateApi,uploadIdCard,getActivateStatus,confirmIdCardApi,amountRangeApi api

class cache,searchQuestion,myCreditProb,borrowHistory,loanPagination question
</code></pre>
<h3>实名 15 points</h3>
<pre><code class="language-mermaid">graph LR
subgraph 引导页 场景
	seeAgreement(&quot;申请及授&lt;br&gt;权协议&quot;)
end

clickRealName(&quot;实名认证&quot;) -.-&gt; showUploadIdCard(&quot;显示新上&lt;br&gt;传身份证&lt;br&gt;界面(13)&quot;)
showUploadIdCard -.-&gt; |include&lt;br&gt;点击&lt;br&gt;sample照片|openCamera
showUploadIdCard -.-&gt; |include| showConfirmUpload(&quot;显示确&lt;br&gt;认上传&quot;)
showUploadIdCard -.-&gt; hasIdCard[&quot;API has&lt;br&gt;ID card&quot;]
showConfirmUpload -.-&gt; |点击照片&lt;br&gt;重新|openCamera(&quot;打开摄像头&lt;br&gt;+上传&quot;)
clickRealName -.-&gt; identification(&quot;跳转活&lt;br&gt;体识别...(2)&quot;)
clickRealName -.-&gt; showUploadError(&quot;显示dialog&lt;br&gt;图片上传&lt;br&gt;1. 错误(尺寸限制)&lt;br&gt;2. 用户拒绝授权&lt;br&gt;使用摄像头???&quot;)
showUploadIdCard -.-&gt; |include|showConfirmIdCard(&quot;显示身&lt;br&gt;份证信息,&lt;br&gt; 点camera&lt;br&gt;按钮重&lt;br&gt;新上传???&quot;)
openCamera -.- uploadIdCard[&quot;上传API&quot;]
showConfirmIdCard -.-&gt; agreenment03(&quot;access:&lt;br&gt;个人信用&lt;br&gt;授权协议&quot;)
agreenment03 -.-&gt; |extend|seeAgreement
showConfirmIdCard -.- ocrApi[&quot;获取OCR&lt;br&gt;API结果,&lt;br&gt;失败提示重新上传 (+2)&quot;]
showConfirmIdCard -.-&gt; consentAgree03(&quot;勾选同意&lt;br&gt;授权协议&quot;)
showConfirmIdCard -.-&gt;|click确认| confirmIdCardApi[&quot;确认身&lt;br&gt;份证API&quot;]

classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;

class backFromIdent,loanHistory,questions,repayment,borrowForm module

class apiLogin,apiIsActivated,apiHasCard,apiIsWIP,ocrApi,activateApi,uploadIdCard,getActivateStatus,confirmIdCardApi,hasIdCard api
class cache,searchQuestion,myCreditProb,borrowHistory,loanPagination,identification question

</code></pre>
<h3>选择收款账户 7 + (8 time box) points</h3>
<pre><code class="language-mermaid">graph LR
    actor((&quot;User&quot;)) --&gt; |1.| selectCard(&quot;用户选择&lt;br&gt;收款账户&quot;)
    selectCard -.-&gt;|include 1.|bankList(&quot;看到银行&lt;br&gt;卡列表(2)&quot;)
 selectCard -.-&gt; |include 2.| selectBank(&quot;选中银行卡&quot;)
    bankList-.-&gt;getBankCardListApi[&quot;API:&lt;br&gt;调取已绑定&lt;br&gt;银行卡列表(1)&quot;]
    bankList-.-&gt;colorAndIconOfBank[&quot;API or config:&lt;br&gt;不同银行卡&lt;br&gt;背景色和logo(2)&quot;]
    selectCard-.-&gt;|include 3.|otherCards(&quot;点击&lt;br&gt;使用其他&lt;br&gt;银行卡&quot;)
    otherCards-.-&gt;|include 2. 跳转| cashier[&quot;收银台&lt;br&gt;绑卡流程&lt;br&gt;(涉及到跨&lt;br&gt;组联调测试&lt;br&gt;(time box 8)&quot;]
otherCards -.-&gt; |include 1.|getCashierConfig[&quot;API&lt;br&gt;获取收银&lt;br&gt;台跳转信息 (1)&quot;]
getCashierConfig -.-&gt; httpMethod(&quot;POST&lt;br&gt;or GET?&quot;)
actor --&gt;|2. 测试&lt;br&gt;跳转收银台&lt;br&gt;直接访问| cashier
    cashier -.-&gt; |include| contract(&quot;是否还需要签约???&lt;br&gt;需要额外的&lt;br&gt;签约信息?&quot;)
actor --&gt; |3.| backFromCashier(从收银台&lt;br&gt;选其他卡&lt;br&gt;返回)
backFromCashier -.-&gt; |include 1.| getNewCard[&quot;API: 获取&lt;br&gt;新添加的卡(1)&quot;]
actor --&gt; |4.| backFromFailedCashier(从收银台&lt;br&gt;选其他卡&lt;br&gt;失败返回)
backFromFailedCashier -.-&gt; |include 1.| isFailed(&quot;如何判断&lt;br&gt;是添加其&lt;br&gt;他卡失败&lt;br&gt;收银台&lt;br&gt;需要添加利用返回&lt;br&gt;URL上的参数&lt;br&gt;通知结果&lt;br&gt;是失败的?&quot;)
backFromCashier -.-&gt; |include 2.| loanForm(&quot;看到&lt;br&gt;提现表单中&lt;br&gt;已选中的&lt;br&gt;收款账户&quot;)
backFromFailedCashier -.-&gt;|include 2.| bankList
actor --&gt; |5.| loanForm
    cashier-.-&gt;|include |cashierFailure(&quot;绑卡失败&lt;br&gt;跳转哪里?&lt;br&gt;需要提供两个&lt;br&gt;两个返回&lt;br&gt;地址给&lt;br&gt;收银台&lt;br&gt;or API&lt;br&gt;查询结果&quot;)

classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;

class getBankCardListApi,colorAndIconOfBank,getCashierConfig,getNewCard api
class cashier module
class contract,httpMethod,cashierFailure,isFailed question
</code></pre>
