<h2>Estimation points</h2>
<p>Daily capacity: 5 points: 2 * 2.5 points<br>
Weekly capacity: 25 points</p>
<h3>Questions:</h3>
<p>提前还清?
A: 只能全部还清</p>
<p>借款记录点进去后看到的“还款计划” 应该是带每期状态“还款详情”</p>
<p>合同只能看，不能下载？
A: 不能</p>
<p>实名中，身份证已经上传API, 只接去活体识别，不用在上传？
A: 重新上传，简单点</p>
<h3>Phase 1</h3>
<h4>Functional points</h4>
<p><code>72</code> points</p>
<h4>Non-functionals (Blocking) points: <code>28.76</code></h4>
<p>Blocking:</p>
<ul>
<li>Project architecture, deployment: 5 points</li>
<li>code review: 72 * 8% = 5.76</li>
<li>Backend intergration / tesing : 18</li>
</ul>
<h4>Phase 1: <code>100.76</code> points, Total <code>4</code> weeks</h4>
<table>
<thead>
<tr>
<th>Week</th>
<th>Story</th>
</tr>
</thead>
<tbody>
<tr>
<td>Week 1</td>
<td></td>
</tr>
<tr>
<td></td>
<td>入口场景 &amp; 跳转收银台等(6)</td>
</tr>
<tr>
<td></td>
<td>提现3个状态 (6)</td>
</tr>
<tr>
<td></td>
<td>Project architecture, deployment (5)</td>
</tr>
<tr>
<td></td>
<td>引导页(4)</td>
</tr>
<tr>
<td></td>
<td>实名(15) - 上传身份证, 活体</td>
</tr>
<tr>
<td>Week 2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>激活额度(14) - 运营商, 补充信息，等待审核</td>
</tr>
<tr>
<td></td>
<td>我的额度(23) - 借款记录，还款详情，还款计划</td>
</tr>
<tr>
<td>Week 3</td>
<td></td>
</tr>
<tr>
<td></td>
<td>我的额度(23) - 还款，提现</td>
</tr>
<tr>
<td>Week 4</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Backend intergration / tesing</td>
</tr>
<tr>
<td></td>
<td>常见问题/帮助中心 (3)</td>
</tr>
</tbody>
</table>
<h3>Phase 2</h3>
<h4>Non-functionals (Non-blocking) points: 70</h4>
<ul>
<li>End-to-end/smoke automation test code: 72 x 50%: <code>31</code></li>
<li>Refactoring, cache, performance ... optimization: 72 x 33% <code>24</code></li>
<li>Track &amp; measuring: 72 x 25% = <code>15</code></li>
</ul>
<h4>Nice-to-have, CMS for 帮助/问题中心 ?</h4>
<p>TBD</p>
<h3>入口场景, total 72 points</h3>
<pre><code class="language-mermaid">graph LR
classDef api fill:#f9f,stroke:#333;
classDef module fill:#79e17f,stroke:#333;
classDef question fill:#f1f143,stroke:#333;

actor((&quot;user: &lt;br&gt;未激活&lt;br&gt;未绑卡&quot;))
actor2((&quot;user: &lt;br&gt;未激活&lt;br&gt;已绑卡&lt;br&gt;绑卡&quot;))
actor3((&quot;user: &lt;br&gt;已激活&lt;br&gt;已绑没&lt;br&gt;有提现&quot;))
actor4((&quot;user: &lt;br&gt;已激活&lt;br&gt;已绑卡&lt;br&gt;提现中&quot;))
actor5((&quot;user:&lt;br&gt;上次审核&lt;br&gt;被拒的???&quot;))

login(&quot;打开钱包&lt;br&gt;点击我的额度&lt;br&gt;,&lt;br&gt;从收银台&lt;br&gt;绑卡返回&lt;br&gt;/cash-loan&quot;)
jwtPost[&quot;处理POST请求，&lt;br&gt;获取JWT&lt;br&gt;header(1)&quot;]
checkStatus(&quot;check&lt;br&gt;status (2)&quot;)
apiLogin[&quot;Login API&quot;]
apiIsActivated[&quot;是否已&lt;br&gt;激活API&quot;]
apiHasCard[&quot;是否绑&lt;br&gt;卡API&quot;]
apiIsWIP[&quot;是否在&lt;br&gt;申请流程&lt;br&gt;中API&quot;]
navigateTo(&quot;跳转或&lt;br&gt;显示(1)&quot;)

loginError(&quot;看到登录、&lt;br&gt;额度激活、&lt;br&gt;网络错误,&lt;br&gt;能点击返回&lt;br&gt;钱包???(1)&quot;)

landing(&quot;access&lt;br&gt;引导页(4),&lt;br&gt;激活额度(14)&quot;)


wallet(&quot;外部模块:&lt;br&gt;收银台&lt;br&gt;钱包绑卡&lt;br&gt;+实名模块...(1)&quot;)

myCredit(&quot;access:&lt;br&gt;我的额度(23),&lt;br&gt;实名(15)...&quot;)
inProgress(&quot;access:&lt;br&gt; 提现状&lt;br&gt;态信息&lt;br&gt;(6)&quot;)
inReview(&quot;显示&lt;br&gt;审核中&quot;)
signDeal(&quot;签约...&quot;)
inCashOut(&quot;显示放款&lt;br&gt;中信息&quot;)

actor --&gt; login
login --- jwtPost
login --- checkStatus
checkStatus --- cache[&quot;cache,&lt;br&gt;clean cache&lt;br&gt;result?&quot;]
checkStatus --- apiLogin
checkStatus --- apiIsActivated
checkStatus --- apiHasCard
checkStatus --- apiIsWIP
login -.-&gt; |include| navigateTo
login -.-&gt; |include| loginError

navigateTo --- |显示| landing
navigateTo --- |跳转| wallet



navigateTo --&gt; |显示|myCredit
navigateTo --&gt; |显示|inProgress
questions(&quot;常见问题&lt;br&gt;帮助...(4)&quot;) --&gt; searchQuestion(&quot;search???&quot;)
inProgress -.-&gt; |include| inReview
inProgress -.-&gt; |include| signDeal
inProgress -.-&gt; |include| inCashOut



class myCredit,loanHistory,wallet,inProgress,inCashOut,signDeal,inReview,landing,questions module
class apiLogin,apiIsActivated,apiHasCard,apiIsWIP api
class cache,searchQuestion,myCreditProb,borrowHistory question
</code></pre>
