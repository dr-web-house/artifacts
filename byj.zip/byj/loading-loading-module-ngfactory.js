(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loading-loading-module-ngfactory"],{

/***/ "../../node_modules/@bk/animation/common-anim.directive.ts":
/*!*****************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/animation/common-anim.directive.ts ***!
  \*****************************************************************************************/
/*! exports provided: CommonAnimBase, CommonAnimDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonAnimBase", function() { return CommonAnimBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonAnimDirective", function() { return CommonAnimDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");


var CommonAnimBase = (function () {
    function CommonAnimBase(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        this._stagState = 'hide';
        this._listStagState = 'hide';
        renderer.addClass(element.nativeElement, 'bk-common-anim');
    }
    CommonAnimBase.prototype.playStag = function (stagTime, animDuration, limit) {
        if (stagTime === void 0) { stagTime = 80; }
        if (animDuration === void 0) { animDuration = 300; }
        if (limit === void 0) { limit = 20; }
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var dom, children, l, i;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        dom = this.element.nativeElement;
                        children = dom.querySelectorAll('.stag-item');
                        l = children.length;
                        i = 0;
                        if (l < limit) {
                            limit = l;
                        }
                        return [4, new Promise(function (resolve) {
                                var _loop_1 = function () {
                                    var item = children.item(i);
                                    _this.renderer.removeClass(item, 'stag-done');
                                    _this.renderer.addClass(item, 'stag');
                                    var idx = i;
                                    setTimeout(function () {
                                        var child = item;
                                        _this.renderer.addClass(child, 'stag-active');
                                        setTimeout(function () {
                                            _this.renderer.removeClass(item, 'stag');
                                            _this.renderer.removeClass(child, 'stag-active');
                                            _this.renderer.addClass(child, 'stag-done');
                                            if (idx + 1 === limit) {
                                                resolve();
                                            }
                                        }, animDuration);
                                    }, stagTime * i);
                                };
                                for (i = 0; i < limit; i++) {
                                    _loop_1();
                                }
                            })];
                    case 1:
                        _a.sent();
                        for (; i < l; i++) {
                            this.renderer.addClass(children.item(i), 'stag-done');
                        }
                        return [2];
                }
            });
        });
    };
    CommonAnimBase.prototype.playSlide = function () {
        setTimeout(function () {
        }, 0);
    };
    return CommonAnimBase;
}());

var CommonAnimDirective = (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](CommonAnimDirective, _super);
    function CommonAnimDirective(el, cd, renderer) {
        return _super.call(this, el, renderer) || this;
    }
    return CommonAnimDirective;
}(CommonAnimBase));



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/bills.service.ts":
/*!******************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/bills.service.ts ***!
  \******************************************************************************************/
/*! exports provided: CashierType, RepayPeriodType, RepaymentResultStatus, BillsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashierType", function() { return CashierType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepayPeriodType", function() { return RepayPeriodType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepaymentResultStatus", function() { return RepaymentResultStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillsService", function() { return BillsService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _bk_employee_loan_app_el_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bk/employee-loan/app/el-core */ "../../node_modules/@bk/employee-loan/app/el-core/index.ts");
/* harmony import */ var _bk_employee_loan_app_repay_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bk/employee-loan/app/repay/types */ "../../node_modules/@bk/employee-loan/app/repay/types.ts");
/* harmony import */ var _bk_employee_loan_app_repay_index_repay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bk/employee-loan/app/repay/index/repay.service */ "../../node_modules/@bk/employee-loan/app/repay/index/repay.service.ts");
/* harmony import */ var _core_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/user.service */ "../../node_modules/@bk/byj-loan/app/core/user.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _bk_employee_loan_app_el_core_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bk/employee-loan/app/el-core/config */ "../../node_modules/@bk/employee-loan/app/el-core/config.ts");










var CashierType;
(function (CashierType) {
    CashierType["SDK"] = "SDK";
    CashierType["H5"] = "H5";
    CashierType["SCAN_CODE"] = "SCAN_CODE";
    CashierType["WECHAT_MINI_PROGRAM"] = "WECHAT_MINI_PROGRAM";
    CashierType["CHANNEL"] = "CHANNEL";
})(CashierType || (CashierType = {}));
var RepayPeriodType;
(function (RepayPeriodType) {
    RepayPeriodType["ALL_PERIOD"] = "ALL_PERIOD";
    RepayPeriodType["CURRENT_PERIOD"] = "CURRENT_PERIOD";
    RepayPeriodType["PART_OF_CURRENT_PERIOD"] = "PART_OF_CURRENT_PERIOD";
})(RepayPeriodType || (RepayPeriodType = {}));
var RepaymentResultStatus;
(function (RepaymentResultStatus) {
    RepaymentResultStatus["SUCCESS"] = "SUCCESS";
    RepaymentResultStatus["PROCESSING"] = "PROCESSING";
    RepaymentResultStatus["FAILED"] = "FAILED";
})(RepaymentResultStatus || (RepaymentResultStatus = {}));
var BillsService = (function () {
    function BillsService(httpClient, config, repayService, userService) {
        this.httpClient = httpClient;
        this.config = config;
        this.repayService = repayService;
        this.userService = userService;
    }
    Object.defineProperty(BillsService.prototype, "approvedRecords", {
        get: function () {
            return this.approvedRecordsCache;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BillsService.prototype, "productId", {
        get: function () {
            return this.config.productId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BillsService.prototype, "token", {
        get: function () {
            return this.userService.token;
        },
        enumerable: true,
        configurable: true
    });
    BillsService.prototype.getApprovedRecords = function () {
        return this.httpClient.get("el-api-loan://loan/" + this.config.productId + "/approved-records?page=1");
    };
    BillsService.prototype.cacheApprovedRecords = function (data) {
        this.approvedRecordsCache = data;
    };
    BillsService.prototype.clearApprovedRecords = function () {
        this.approvedRecordsCache = null;
    };
    BillsService.prototype.isPending = function (record) {
        return !this.isDone(record);
    };
    BillsService.prototype.isDone = function (record) {
        return record.loanStatus === _bk_employee_loan_app_repay_types__WEBPACK_IMPORTED_MODULE_2__["LoanStatus"].EARLY_SETTLE || record.loanStatus === _bk_employee_loan_app_repay_types__WEBPACK_IMPORTED_MODULE_2__["LoanStatus"].NORMAL_SETTLE;
    };
    BillsService.prototype.repay = function (body) {
        var _a;
        return this.httpClient.post('el-api-loan://loan/repay', body, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]((_a = {},
                _a[this.userService.tokenHeaderName] = this.userService.token,
                _a))
        });
    };
    BillsService.prototype.getPrepaymentPlan = function (loanNo) {
        return this.httpClient.get('el-api-loan://loan/prepayment-plan', {
            params: {
                loanNo: loanNo
            }
        });
    };
    BillsService.prototype.getPrepaymentResult = function (loanNo, repayNo) {
        return this.httpClient.get('el-api-loan://loan/repayment/result', {
            params: {
                loanNo: loanNo,
                repayNo: repayNo
            }
        });
    };
    BillsService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ factory: function BillsService_Factory() { return new BillsService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_bk_employee_loan_app_el_core_config__WEBPACK_IMPORTED_MODULE_6__["EL_CONFIG"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_bk_employee_loan_app_repay_index_repay_service__WEBPACK_IMPORTED_MODULE_3__["RepayService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_core_user_service__WEBPACK_IMPORTED_MODULE_4__["ByjUserService"])); }, token: BillsService, providedIn: "root" });
    return BillsService;
}());



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ngfactory.js":
/*!****************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/loading/loading.component.ngfactory.js ***!
  \****************************************************************************************************************/
/*! exports provided: RenderType_LoadingComponent, View_LoadingComponent_0, View_LoadingComponent_Host_0, LoadingComponentNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RenderType_LoadingComponent", function() { return RenderType_LoadingComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_LoadingComponent_0", function() { return View_LoadingComponent_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_LoadingComponent_Host_0", function() { return View_LoadingComponent_Host_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingComponentNgFactory", function() { return LoadingComponentNgFactory; });
/* harmony import */ var _loading_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loading.component.scss.shim.ngstyle */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.scss.shim.ngstyle.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_progress_spinner_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../@angular/material/progress-spinner/typings/index.ngfactory */ "../../node_modules/@angular/material/progress-spinner/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/progress-spinner */ "../../node_modules/@angular/material/esm5/progress-spinner.es5.js");
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/platform */ "../../node_modules/@angular/cdk/esm5/platform.es5.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "../../node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _employee_loan_app_el_shared_count_down_count_down_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../employee-loan/app/el-shared/count-down/count-down.component.ngfactory */ "../../node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ngfactory.js");
/* harmony import */ var _bk_employee_loan_app_el_shared_count_down_count_down_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bk/employee-loan/app/el-shared/count-down/count-down.component */ "../../node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ts");
/* harmony import */ var _loading_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./loading.component */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _bills_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../bills.service */ "../../node_modules/@bk/byj-loan/app/bills/bills.service.ts");
/* harmony import */ var _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bk/employee-loan/app/apply/apply.service */ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts");
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../result/result.service */ "../../node_modules/@bk/byj-loan/app/bills/result/result.service.ts");














var styles_LoadingComponent = [_loading_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];
var RenderType_LoadingComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({ encapsulation: 0, styles: styles_LoadingComponent, data: {} });

function View_LoadingComponent_1(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "mat-spinner", [["class", "spinner mat-spinner mat-progress-spinner"], ["mode", "indeterminate"], ["role", "progressbar"]], [[2, "_mat-animation-noopable", null], [4, "width", "px"], [4, "height", "px"]], null, null, _angular_material_progress_spinner_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["View_MatSpinner_0"], _angular_material_progress_spinner_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["RenderType_MatSpinner"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 49152, null, 0, _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_3__["MatSpinner"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]], [2, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["ANIMATION_MODULE_TYPE"]], _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_3__["MAT_PROGRESS_SPINNER_DEFAULT_OPTIONS"]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "div", [["class", "text"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["\u652F\u4ED8\u4E2D\uFF0C\u8BF7\u8010\u5FC3\u7B49\u5F85", ""]))], null, function (_ck, _v) { var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2)._noopAnimations; var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).diameter; var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).diameter; _ck(_v, 1, 0, currVal_0, currVal_1, currVal_2); var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v.parent, 6).curSecond; _ck(_v, 4, 0, currVal_3); }); }
function View_LoadingComponent_3(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["\u652F\u4ED8\u6210\u529F"]))], null, null); }
function View_LoadingComponent_2(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 11, "div", [["class", "success"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "img", [["class", "ico-loading"], ["src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQCklEQVR4Xu2dDZBU1ZXHf+f1MNPTDYQszoygZLRUEjTomoC7G1yDGhRE0HXFr6SMS4wFMxKMbkxijEUZC7+iuGoPI1kJZTa6iJtKJAoyCJiASZQ1lbDChokRgpGFYVYW6J7uYfrdrft6Bob56ve63+t+PfNeFVXU9L3nnnv+//t17r3nCoPuU8K8ZC0h82zgdJScBtSizCpERgP6XwSkHFRFpvqSAtUOJIBWlGpFjBZgN6J2Ae+TNrbTGN4NogaTyaTkK3NbfAxlMgVlTgFjMqImAiM9qtchlGwD823E2EKH2sKy6F6PyiqI2NIjwBxVTnXq86iOGSDTgQkFsVT/hewAtRYpW8P+ijdYJbonKZmvNAiwSJWxLzEN4TrgamCUTy18EPgpihepiTSxSDp8qucxtfxNgAXJMzDTX0FxCzDG78bsod9ehBUYoWd5KvyeX3X3JwFub5uKUnehuAKU4Vfj2dNLTIRXEXmMpys32ctTuFT+IkBdfBbCfSgmFc4EBSxJ2IrifhqiqwtY6oBF+YMA9UemgTyA4gK/GMZTPYS3QN1LbHiTp+XYEF5cAtQnx4P5GEpdaUPXwZdE5Odg3EUsvLNYlSsOAebsqaRq9H0odSdCebEq74tyFe2IPE5L6/2sGtdWaJ0KTwA9wTPVMlBnFbqy/i5PmjHktkJPFAtHAL2W39/2PeDu0p/Ze0UlMYFHqK78bqF8CIUhwILEqXSof0eY4pXpBpVcxRbK5Aaeinzgdb28J8D8+EzLIQIneV2ZQSb/gOUAWxp9xct6eUeARcqgpW0xprobwbtyvLROsWUrFIY8QlXlPSyyhgfXP2+A0Rs2VfHnQK53XeMhKVCtpCV6sxcbTe4TYG7LCMKRnwBfGJJYeVfp9SQT17C86rCbRbhLgHmHqwmFXkGpwenKddPyucgS2Uo6PZPGEftzyd5XHvcIUN9Wi1JNwfreLWj6kyPNiEwjVrnbjZLcIYBu+UZocwC+G5DYkSHNmOkL3egJ8ieAHvMroxuCbt8OcC6m0cNBW/ySfOcE+RHAmu0n9Do1mPC5iK0DUetpiczMZ3WQOwH0On9//PlgqecALk+SqpVUR2/K1U+QOwHqEg+DutuTOgVCnVlA5GFikW85y5RJnRsBtHsXVgcevlxM7kEe7TGEWbm4jZ0ToC4xDtQ7gW/fAyDzE3mAkJzvdAPJGQEyx7M3Bbt6+SHlWW69i1gTmepkK9kZAeYnHkLUNz2rQCDYBQvIQzREvm1XkH0C1B2+GELrg8Mcdk1brHRiYsildk8W2SNA5gzf7wJPX7FAdVquNNPSep6dM4b2CFCXeBBUTssMp6oH6d2ygL2hIDsB9NFtM71tyJ/edQuXQsnRp42N0MRsR85tECCxesie2y8UWF6Vo+8dxCKzBhI/MAH0jR0l67zSL5BbAAuIumygG0hZCBD/zZC5rlUALIpShL6GFov+TX9l908AfVETXi6K0kGhbltgdn8XUvsnQH3i7WCP320ciiRP30qORSf3VXrfBLCub5kbi6RuUKwXFjCMi/tyDvVNgPpg5u8FBkWV2c+KoDcBdFiWtLkzcPkWFS4PCheTkDG+Z7ia3gSojy9GYXszwQNNA5FeWUB4kFj0nu7iTyRA5gbvn0GVWkAmr0w22OTupTryie7bxScSYH58hhXQKPhcsUBIYHKtQfUIeHev4r0DPggyqgNvLY2u6argiQSoa/shmDokW/DlaYHzTxVemFvBJ2syQc6UUrz4Tppbf9zOkVSewvPKbqygofKfehMgc8R7n4+DMOZV7UJmvqBWeG1BmFGVvadYK/+zgxuWFzWY6EFaIjVdR8mPa1ifnIZKB37/PJkyuVZYd3uYUZG+V9i6JzhrUbK4w4GELiMWtiKUHdey7sjjIF/Ps/5DOvukTwhNuuX3A36Xca5qTPLyNk+u+9u0v1pCw/A7exAgvt0HgZdtVsB/yTT46xaE+XgW8LXmf/dokl/vKiYB2EFDVIfT7+wBrJDrfOg/s5aGRp8dJzR9zR74f9hncs73kqSLvSDoYKwOdZ8ZAuoS14JaVRrm9peWnxknrLcJ/v+1KS5+IslvPyg2+lbbn0ND5KUMAeYfWYLIHf4yrf+10eDrMf+votkPVmnwL386yW92+QF8a136BEuHf72TAInNiApCuDngnF7n65ZvB/xDneD/2i/gW44J2cLSyIWi/0ddQj904NUzKw7MWhpJnYI/PZbkV+/7pOUfN/EhGiKjhHltp2GY75eG6Yuv5V93tvzRNrr9Q0nF9Kd9CX7GkKZxulAfvwKFp8EIiw+bOxqcd4rw+sIwdsA/3An+m/5r+ceNIczUBKhH8bQ7Jhq8UjT4esw/aXj2CZ8FfizJm3/yXbd/IkDC7Xr8fxTUPw9e6PKv2bljMy3fLvgzYim2/Kmojh6blZbvawK8CGqOzRwFSXZmlXDOGIP9hxVv7TKL6jRxCv4VsRSbSwJ8yxewSph/ZCMiUwuCbJZChlfAs18sZ85nQohkutqd+0xuWJ4qivPECfhHkooZDSk2v1cKLb8TCKU2CXXx3wP6tc2ifyvnlnPdZ8t66XEwobjkXwrrQfv0GGHDHWGqbIz5R1IK3fJ/WUrgZ6y8TRPgL8DYYqN/xklC86LwsZbfU5+WI4qpS5Js/x/vJ1YW+AvDVI3IPuHT4M9sSPGLP5ZQyz9u3A81AT7ywyGQ2RMNfjYvPCAPPzxoctGSlKd76ed0gl9tA/x4J/hvlCb42tYH9SQwDipS7B7gb08z+NU3BiaA1nFXa4YEez5yvyc45+RMtz9EwNeTwITuAfT7tqFiE0AfoHz3u+FjZ+gG0kdPDC9akmSfi4HTNfh6qVczMnu3r1v+lUtTbGouyW6/u2nTviGA1kr72DfdEWZkH2fpehJi21/STH0ixf8m8qfu2brl2wQ/0a64siHFxtIHXxtOE8AfQ0AXjH9/hsHa2yuIlGdviVt3p7n0yRSHkrmTYMLJwkYn4C9NsXFnybf8ToNlhgBfTAK7Q3jZpwxenl9BRVl2Evzyj2mmx1IkcjhoO6EmM+afbKPb1y1/1tIUGwYN+JbF9STQH8vAnm34qnMNVt1awTA9OcjyNe1IM6sxRUrPZmx+n6rJtPyTP5ZdvgZ/dmOK1/8wWFr+MSNZy0DfOIJ6YnfjpBA/+nI5ISM7SD/7fQfX/qCdDhsYfbJa2HhHmDE2wG/TLX9wgt/pCPKRK7ivxnvr50Isu6m8XwdR9zwvbO3gSyvaMQdYIToFX7f89YOv5WfMlnEF+28zqCcRFk4N8cScClud+7NvHuWrPz5qhc/u+Y3vbPlj7bT8o4qrGlM0/beNLsWWZn5MpDeDSmQ7+DuXl/HAbHsPjT+58SgLXzp6gsUt8BdWMHZU5q7eQF/bUcXVjSnWDWrwtQX0dnAJHQhZPHsY3758WDb8rN8Xrz3Kd1ZnSDC+So/59sBP6pb/TIp1OwZzy+80oXUgpMSOhD05ZxgLptojwT0vt/PSO2kL/FNstHwN/tXPpHhtKIBvdQD6SFiJHQrV64F//WI5cz/Xe9u4Z9egL2IebMPWdS0N/j88k2LtUAFfG8s6FFqCx8L1qvD5W8q5flJ2EtgZLzT41yxLsWb7EOj2jxuk81i4/sP80rsYUmbAf3y1nNnn5keClG75Qw/87hdDSvdqWEUZrJ5XwbQJuW1mpjoyLf/Vd4dUy+/yAXS7GlbCl0Mj5fBafQUXnumMBBr8f1yW4pWhCL5Fge6XQ0v8evjIMLz+tQom1dojgQb/2h+k+Pl/DcGW3zUHOOF6uP5jXWkHiBgdhQ0LKzj3lIFJEIBvMaBHgAiLAKUfIuZjlfDczf1PDPd8ZHLj8vYSubRhZ/2Sa5q+QsQMoiBRF51poHcSJ441CA+D3a2KNdvT/NtbaZIOtoxzNa/v8/UZJCoIE+d73FxSsJ8wcZl5wA+BIFCkS5b2qZgVNET7CBRpOYSCULE+Bc09tQYMFWsFi078GQiCRbtncj9JyhIsWqsahIv3E2Du6pI1XLwuLngwwl2j+0aa3QcjrF4geDLGN7i5pYjtJ2N0gcGjUW6Z3T9yHD0alZkLvI1ikn9qEGiShwW20uDk2biMTyB4ODIPi/ssaw4PR2Z6geDpWJ8h6VidnJ+OtQgQPB7t2OB+y5DX49HBisBvcDrTJ+/n4y0CJMdjprch2LuV4UzFILVXFlC0Y4QmEgvvHKiI7LcurQlh4kFQ3/JK10CuFxaQh2iIZH0A1B4B5uyppGr070Cd5YWqgUy3LSDNtLSex6pxbdkk2yPAMeeQej14UzibSYv9u5gYcmlfL4X3pZl9AgRDQbGRtVm+va6/S5gzAujt4n2JTQjB6yI24ShoMsUWaiJTu78NnK18ZwTQ0hYkTiWtfguclE148HtBLXCAkJzPU5EPnJTqnABa+vz4TGA10u3hSSelBmndtYCy4mHMYmnU8cMfuRFAq1+feAilvuluTQJpOVlA5GFikZyW6bkTYJEy2B9/HuT6nJQOMrlkAbWS6uhNLJKcrjnlTgCtfuYoue52vuBSbQIxziywnpbIzK6XwJ1lzaTOjwBawtyWEVRGN6BUcHYgFwRyzSOylbb4JSyvyiticv4E0BWYd7gaI7Q58BTmiqbTfNKMmb6QxhH7nebsmd4dAliTwrZalGoKSJAvJNnySzMi04hV7s6W0s7v7hGgqycIhV4JhgM7ps8hje720+mZbrT8rtLdJUDXnCAc+UkwMcwB4IGzrCeZuCbfMd+7IaC7ZGt1EH8uWCK6RQK1kpbozfnM9vvTxP0eoKsk7SdoaVuMqe4OPIY5EkF7+Ax5hKrKe3Jd52cr2TsCdJWs3cbCimDvIBsUvX4/gOKWXNy7TkryngBam7rEOJR6IdhFtAmN3tUTuZGGyB6bOXJOVhgCaPWsreS2BxC+ERwq6XdENlE8Sk3lvU62dHNG3xVPoNPSrWtnalngL+g1H2/GkNvsnuRxavbCTwIH0jBzxvA+lLpzyJ821qd3RR6npfV+O2f43ALeOz+AEw31kXPMx1DqSifZBk1afW4f465sR7e9rG/h5gAD1ULfQEIeQHGBl5X1jWx9XQt1L7HhTcXWyR8E6LKCvpAqooeGwbmzqF25St1PQ3R1sYH3xxDQnxX0RFGpu9ABjVDZ33jxizX71ENMhFcReazQEzw7ZvFXD9BTYx2uxkx/BSW3gCqxwFWyF1ErMELP8lT4PTtgFCONvwnQZZHMcfRpiHEdmFf74bn7fsA6CMZPUeaL1ESaCrWWz4c4pUGA7jXUG03Vqc+jzBmgpgMT8jGAC3l3gFqLlK1hf8UbXmzYuKBjvyJKjwA9q2KFupcpKHMKGJMRNREY6ZHRDqFkG5hvI8YWOtQWlkX3elRWQcSWPgF6mUkJ85K1hMyzgdNRchpQizKrEBkN6H8RkHJQna9RSgqUfn5aP0bfilKtiNEC7EbULuB90sZ2GsO7QQZ4l7QgmLlayP8DZLppvDRHH1EAAAAASUVORK5CYII="]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](512, null, _angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassImpl"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassR2Impl"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](3, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgClass"], [_angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassImpl"]], { klass: [0, "klass"], ngClass: [1, "ngClass"] }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](4, { show: 0 }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_LoadingComponent_3)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 4, "div", [["class", "out-mask"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 3, "div", [["class", "mask"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](512, null, _angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassImpl"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassR2Impl"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgClass"], [_angular_common__WEBPACK_IMPORTED_MODULE_5__["ɵNgClassImpl"]], { klass: [0, "klass"], ngClass: [1, "ngClass"] }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](11, { "uncover": 0, "right": 1, "show": 2 })], function (_ck, _v) { var _co = _v.component; var currVal_0 = "ico-loading"; var currVal_1 = _ck(_v, 4, 0, _co.showImg); _ck(_v, 3, 0, currVal_0, currVal_1); var currVal_2 = !_co.masking; _ck(_v, 6, 0, currVal_2); var currVal_3 = "mask"; var currVal_4 = _ck(_v, 11, 0, (_co.state === "uncover"), (_co.state === "right"), _co.showMask); _ck(_v, 10, 0, currVal_3, currVal_4); }, null); }
function View_LoadingComponent_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 1, { count: 0 }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_LoadingComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_LoadingComponent_2)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "el-count-down", [["class", "el-count-down"]], [[8, "className", 0]], [[null, "stop"]], function (_v, en, $event) { var ad = true; var _co = _v.component; if (("stop" === en)) {
        var pd_0 = (_co.onStopCount() !== false);
        ad = (pd_0 && ad);
    } return ad; }, _employee_loan_app_el_shared_count_down_count_down_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["View_CountDownComponent_0"], _employee_loan_app_el_shared_count_down_count_down_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["RenderType_CountDownComponent"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 49152, [[1, 4], ["count", 4]], 0, _bk_employee_loan_app_el_shared_count_down_count_down_component__WEBPACK_IMPORTED_MODULE_8__["CountDownComponent"], [], { target: [0, "target"], format: [1, "format"] }, { stop: "stop" })], function (_ck, _v) { var _co = _v.component; var currVal_0 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 6).counting && !_co.isSuccess); _ck(_v, 2, 0, currVal_0); var currVal_1 = _co.isSuccess; _ck(_v, 4, 0, currVal_1); var currVal_3 = _co.countDownTarget; var currVal_4 = _co.curSecond; _ck(_v, 6, 0, currVal_3, currVal_4); }, function (_ck, _v) { var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 6).className; _ck(_v, 5, 0, currVal_2); }); }
function View_LoadingComponent_Host_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "byj-loading", [], [[2, "masking", null]], null, null, View_LoadingComponent_0, RenderType_LoadingComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 4440064, null, 0, _loading_component__WEBPACK_IMPORTED_MODULE_9__["LoadingComponent"], [_angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"], _bills_service__WEBPACK_IMPORTED_MODULE_11__["BillsService"], _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_12__["ApplyService"], _result_result_service__WEBPACK_IMPORTED_MODULE_13__["ResultService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], null, null)], function (_ck, _v) { _ck(_v, 1, 0); }, function (_ck, _v) { var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 1).masking; _ck(_v, 0, 0, currVal_0); }); }
var LoadingComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("byj-loading", _loading_component__WEBPACK_IMPORTED_MODULE_9__["LoadingComponent"], View_LoadingComponent_Host_0, {}, {}, []);



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.scss.shim.ngstyle.js":
/*!************************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/loading/loading.component.scss.shim.ngstyle.js ***!
  \************************************************************************************************************************/
/*! exports provided: styles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
var styles = ["[_nghost-%COMP%] {\n  padding: 90px 104px;\n  background: #fff;\n  transition-duration: 0.7s;\n}\n\n.masking[_nghost-%COMP%] {\n  background: #006af5;\n}\n\n[_nghost-%COMP%]     svg {\n  width: 64px !important;\n  height: 64px !important;\n}\n\n[_nghost-%COMP%]     svg circle {\n  stroke-width: 6% !important;\n}\n\n.spinner[_ngcontent-%COMP%] {\n  width: 64px !important;\n  height: 64px !important;\n  left: 50%;\n  margin-left: -32px;\n}\n\n.el-count-down[_ngcontent-%COMP%] {\n  display: none;\n}\n\n.success[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.text[_ngcontent-%COMP%] {\n  margin-top: 26px;\n  text-align: center;\n  font-size: 16px;\n  font-weight: 400;\n  color: #101d37;\n}\n\n.ico-loading[_ngcontent-%COMP%] {\n  position: relative;\n  width: 64px;\n  left: 50%;\n  margin-left: -32px;\n}\n\nimg[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 100;\n  opacity: 0;\n  transition-duration: 0.3s;\n}\n\nimg.show[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n\n.mask[_ngcontent-%COMP%] {\n  opacity: 1;\n  background: #006af5;\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  z-index: 200;\n  top: 11px;\n  left: 50%;\n  margin-left: -20px;\n  transition-duration: 0.5s;\n  transition-timing-function: ease-in-out;\n  border-radius: 10%;\n}\n\n.mask.show[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n\n.mask.uncover[_ngcontent-%COMP%] {\n  transition-duration: 0.5s;\n  opacity: 1;\n  left: 148%;\n}\n\n.mask.right[_ngcontent-%COMP%] {\n  transition-duration: 0.7s;\n  left: 80%;\n  border-radius: 10%;\n}\n\n.out-mask[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  top: 10px;\n  left: 50%;\n  margin-left: -20px;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9saXVqaW5nL2JrL2NyZWRpdC1hcHBsL25vZGVfbW9kdWxlcy9AYmsvYnlqLWxvYW4vYXBwL2JpbGxzL2xvYWRpbmcvbG9hZGluZy5jb21wb25lbnQuc2NzcyIsIm5vZGVfbW9kdWxlcy9AYmsvYnlqLWxvYW4vYXBwL2JpbGxzL2xvYWRpbmcvbG9hZGluZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFJQSx5QkFBQTtBQ0ZGOztBRERFO0VBQ0UsbUJBQUE7QUNJSjs7QURBSTtFQUNFLHNCQUFBO0VBQ0EsdUJBQUE7QUNHTjs7QURGTTtFQUNFLDJCQUFBO0FDS1I7O0FEQ0E7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FDRUY7O0FEQ0E7RUFDRSxhQUFBO0FDRUY7O0FEQ0E7RUFDRSxrQkFBQTtBQ0VGOztBRENBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNFRjs7QURDQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQ0VGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0FDRUY7O0FEREU7RUFDRSxVQUFBO0FDSUo7O0FEQUE7RUFDRSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHVDQUFBO0VBQ0Esa0JBQUE7QUNHRjs7QURGRTtFQUNFLFVBQUE7QUNLSjs7QURIRTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7QUNNSjs7QURKRTtFQUNFLHlCQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FDT0o7O0FEWUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDVEYiLCJmaWxlIjoibm9kZV9tb2R1bGVzL0Biay9ieWotbG9hbi9hcHAvYmlsbHMvbG9hZGluZy9sb2FkaW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBwYWRkaW5nOiA5MHB4IDEwNHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAmLm1hc2tpbmcge1xuICAgIGJhY2tncm91bmQ6ICMwMDZhZjU7XG4gIH1cbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMC43cztcbiAgOjpuZy1kZWVwIHtcbiAgICBzdmcge1xuICAgICAgd2lkdGg6IDY0cHggIWltcG9ydGFudDtcbiAgICAgIGhlaWdodDogNjRweCAhaW1wb3J0YW50O1xuICAgICAgY2lyY2xlIHtcbiAgICAgICAgc3Ryb2tlLXdpZHRoOiA2JSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4uc3Bpbm5lciB7XG4gIHdpZHRoOiA2NHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNjRweCAhaW1wb3J0YW50O1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMzJweDtcbn1cblxuLmVsLWNvdW50LWRvd24ge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uc3VjY2VzcyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnRleHQge1xuICBtYXJnaW4tdG9wOiAyNnB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgY29sb3I6IHJnYmEoMTYsIDI5LCA1NSwgMSk7XG59XG5cbi5pY28tbG9hZGluZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDY0cHg7XG4gIGxlZnQ6IDUwJTtcbiAgbWFyZ2luLWxlZnQ6IC0zMnB4O1xufVxuXG5pbWcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDEwMDtcbiAgb3BhY2l0eTogMDtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMC4zcztcbiAgJi5zaG93IHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG59XG5cbi5tYXNrIHtcbiAgb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZDogIzAwNmFmNTtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAyMDA7XG4gIHRvcDogMTFweDtcbiAgbGVmdDogNTAlO1xuICBtYXJnaW4tbGVmdDogLTIwcHg7XG4gIHRyYW5zaXRpb24tZHVyYXRpb246IDAuNXM7XG4gIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDtcbiAgYm9yZGVyLXJhZGl1czogMTAlO1xuICAmLnNob3cge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgJi51bmNvdmVyIHtcbiAgICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjVzO1xuICAgIG9wYWNpdHk6IDE7XG4gICAgbGVmdDogMTQ4JTtcbiAgfVxuICAmLnJpZ2h0IHtcbiAgICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjdzO1xuICAgIGxlZnQ6IDgwJTtcbiAgICBib3JkZXItcmFkaXVzOiAxMCU7XG4gIH1cbn1cblxuLy8gLmJsdWUge1xuLy8gICBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgIGxlZnQ6IC0xMDAlO1xuLy8gICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAxcztcbi8vICAgYmFja2dyb3VuZDogIzAwNmFmNTtcbi8vICAgei1pbmRleDogMDtcbi8vICAgd2lkdGg6IDEwMCU7XG4vLyAgIGhlaWdodDogMTAwdmg7XG4vLyAgIHRvcDogMDtcbi8vICAgdHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjksIC0wLjA5LCAwLjUxLCAxLjA3KTtcbi8vICAgJi5sZWZ0IHtcbi8vICAgICBsZWZ0OiAwO1xuLy8gICB9XG4vLyB9XG5cbi5vdXQtbWFzayB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMjBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbiIsIjpob3N0IHtcbiAgcGFkZGluZzogOTBweCAxMDRweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMC43cztcbn1cblxuOmhvc3QubWFza2luZyB7XG4gIGJhY2tncm91bmQ6ICMwMDZhZjU7XG59XG5cbjpob3N0IDo6bmctZGVlcCBzdmcge1xuICB3aWR0aDogNjRweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDY0cHggIWltcG9ydGFudDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIHN2ZyBjaXJjbGUge1xuICBzdHJva2Utd2lkdGg6IDYlICFpbXBvcnRhbnQ7XG59XG5cbi5zcGlubmVyIHtcbiAgd2lkdGg6IDY0cHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA2NHB4ICFpbXBvcnRhbnQ7XG4gIGxlZnQ6IDUwJTtcbiAgbWFyZ2luLWxlZnQ6IC0zMnB4O1xufVxuXG4uZWwtY291bnQtZG93biB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5zdWNjZXNzIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udGV4dCB7XG4gIG1hcmdpbi10b3A6IDI2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNDAwO1xuICBjb2xvcjogIzEwMWQzNztcbn1cblxuLmljby1sb2FkaW5nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogNjRweDtcbiAgbGVmdDogNTAlO1xuICBtYXJnaW4tbGVmdDogLTMycHg7XG59XG5cbmltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTAwO1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjNzO1xufVxuXG5pbWcuc2hvdyB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbi5tYXNrIHtcbiAgb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZDogIzAwNmFmNTtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAyMDA7XG4gIHRvcDogMTFweDtcbiAgbGVmdDogNTAlO1xuICBtYXJnaW4tbGVmdDogLTIwcHg7XG4gIHRyYW5zaXRpb24tZHVyYXRpb246IDAuNXM7XG4gIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDtcbiAgYm9yZGVyLXJhZGl1czogMTAlO1xufVxuXG4ubWFzay5zaG93IHtcbiAgb3BhY2l0eTogMTtcbn1cblxuLm1hc2sudW5jb3ZlciB7XG4gIHRyYW5zaXRpb24tZHVyYXRpb246IDAuNXM7XG4gIG9wYWNpdHk6IDE7XG4gIGxlZnQ6IDE0OCU7XG59XG5cbi5tYXNrLnJpZ2h0IHtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMC43cztcbiAgbGVmdDogODAlO1xuICBib3JkZXItcmFkaXVzOiAxMCU7XG59XG5cbi5vdXQtbWFzayB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMjBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuIl19 */"];



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ts":
/*!******************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/loading/loading.component.ts ***!
  \******************************************************************************************************/
/*! exports provided: LoadingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingComponent", function() { return LoadingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _bk_animation_common_anim_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bk/animation/common-anim.directive */ "../../node_modules/@bk/animation/common-anim.directive.ts");
/* harmony import */ var _bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bk/module-core/base-route-component/base-route.component */ "../../node_modules/@bk/module-core/base-route-component/base-route.component.ts");
/* harmony import */ var _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bk/employee-loan/app/apply/apply.service */ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts");
/* harmony import */ var _bills_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../bills.service */ "../../node_modules/@bk/byj-loan/app/bills/bills.service.ts");
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../result/result.service */ "../../node_modules/@bk/byj-loan/app/bills/result/result.service.ts");










var LoadingComponent = (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](LoadingComponent, _super);
    function LoadingComponent(activeRoute, billsService, epApplyService, resultService, el, renderer) {
        var _this = _super.call(this, '贝用金') || this;
        _this.activeRoute = activeRoute;
        _this.billsService = billsService;
        _this.epApplyService = epApplyService;
        _this.resultService = resultService;
        _this.RECOUNT_SECEND = 11;
        _this.state = 'cover';
        _this.showImg = false;
        _this.showMask = false;
        _this.isSuccess = false;
        _this._onDestroy = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"](1);
        _this.commonAnim = new _bk_animation_common_anim_directive__WEBPACK_IMPORTED_MODULE_5__["CommonAnimBase"](el, renderer);
        return _this;
    }
    LoadingComponent.prototype.curSecond = function (seconds) {
        if (seconds) {
            var s = seconds < 10 ? "0" + seconds : "" + seconds;
            return s + "s";
        }
        else {
            return '';
        }
    };
    LoadingComponent.prototype.onStopCount = function () {
        this._onDestroy.next();
        this._onDestroy.complete();
        this.resultService.next(this.result);
    };
    LoadingComponent.prototype.whenSuccessOrFailed = function (data) {
        var _this = this;
        this._onDestroy.next();
        this._onDestroy.complete();
        if (data && data.status === 'SUCCESS') {
            this.isSuccess = true;
            this.showImg = true;
            setTimeout(function () {
                _this.showMask = true;
            }, 1);
            setTimeout(function () {
                _this.state = 'right';
            }, 200);
            setTimeout(function () {
                _this.state = 'uncover';
            }, 500);
            setTimeout(function () {
                _this.resultService.next(data);
            }, 1500);
        }
        else {
            setTimeout(function () {
                _this.resultService.next(data);
            }, 1000);
        }
    };
    LoadingComponent.prototype.repeatGetResult = function () {
        var _this = this;
        if (!this.repayNo || !this.loanNo) {
            this.epApplyService.handleError('参数错误');
            return false;
        }
        this.countDownTarget = new Date(Date.now() + this.RECOUNT_SECEND * 1000);
        return this.billsService
            .getPrepaymentResult(this.loanNo, this.repayNo)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this._onDestroy), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["mergeMap"])(function (res) {
            _this.result = res.data;
            if (!_this.count.counting) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(res);
            }
            if (res.data.status === 'SUCCESS' || res.data.status === 'FAILED') {
                _this.whenSuccessOrFailed(res.data);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(res);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])('not-pass');
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["retryWhen"])(function (errors) {
            return errors.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["delay"])(1000));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1))
            .subscribe();
    };
    LoadingComponent.prototype.ngOnInit = function () {
        var _this = this;
        _super.prototype.changeTitle.call(this, '贝用金');
        setTimeout(function () { return _this.commonAnim.playStag(); }, 0);
        this.loanNo = this.activeRoute.snapshot.queryParamMap.get('loanNo');
        this.repayNo = this.activeRoute.snapshot.queryParamMap.get('repayNo');
        this.repeatGetResult();
    };
    LoadingComponent.prototype.ngOnDestroy = function () {
        this._onDestroy.next();
        this._onDestroy.complete();
    };
    return LoadingComponent;
}(_bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_6__["BaseRouteComponent"]));

_bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_6__["BaseRouteComponent"].extendLifecycleHooks(LoadingComponent);


/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.module.ngfactory.js":
/*!*************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/loading/loading.module.ngfactory.js ***!
  \*************************************************************************************************************/
/*! exports provided: LoadingModuleNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingModuleNgFactory", function() { return LoadingModuleNgFactory; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _loading_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loading.module */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.module.ts");
/* harmony import */ var _angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../@angular/router/router.ngfactory */ "../../node_modules/@angular/router/router.ngfactory.js");
/* harmony import */ var _angular_material_dialog_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../@angular/material/dialog/typings/index.ngfactory */ "../../node_modules/@angular/material/dialog/typings/index.ngfactory.js");
/* harmony import */ var _employee_loan_app_el_shared_jump_jump_component_ngfactory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../employee-loan/app/el-shared/jump/jump.component.ngfactory */ "../../node_modules/@bk/employee-loan/app/el-shared/jump/jump.component.ngfactory.js");
/* harmony import */ var _loading_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./loading.component.ngfactory */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ngfactory.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/overlay */ "../../node_modules/@angular/cdk/esm5/overlay.es5.js");
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/bidi */ "../../node_modules/@angular/cdk/esm5/bidi.es5.js");
/* harmony import */ var _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/observers */ "../../node_modules/@angular/cdk/esm5/observers.es5.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/select */ "../../node_modules/@angular/material/esm5/select.es5.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/dialog */ "../../node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "../../node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/core */ "../../node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/progress-spinner */ "../../node_modules/@angular/material/esm5/progress-spinner.es5.js");
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/cdk/platform */ "../../node_modules/@angular/cdk/esm5/platform.es5.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/button */ "../../node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/icon */ "../../node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/cdk/table */ "../../node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/table */ "../../node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/divider */ "../../node_modules/@angular/material/esm5/divider.es5.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/list */ "../../node_modules/@angular/material/esm5/list.es5.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/cdk/portal */ "../../node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/cdk/scrolling */ "../../node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/form-field */ "../../node_modules/@angular/material/esm5/form-field.es5.js");
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/progress-bar */ "../../node_modules/@angular/material/esm5/progress-bar.es5.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/checkbox */ "../../node_modules/@angular/material/esm5/checkbox.es5.js");
/* harmony import */ var _bk_employee_loan_app_el_shared_el_shared_module__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @bk/employee-loan/app/el-shared/el-shared.module */ "../../node_modules/@bk/employee-loan/app/el-shared/el-shared.module.ts");
/* harmony import */ var _loading_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./loading.component */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ts");































var LoadingModuleNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵcmf"](_loading_module__WEBPACK_IMPORTED_MODULE_1__["LoadingModule"], [], function (_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmod"]([_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵCodegenComponentFactoryResolver"], [[8, [_angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_router_router_lNgFactory"], _angular_material_dialog_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_3__["MatDialogContainerNgFactory"], _employee_loan_app_el_shared_jump_jump_component_ngfactory__WEBPACK_IMPORTED_MODULE_4__["JumpComponentNgFactory"], _loading_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__["LoadingComponentNgFactory"]]], [3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"]], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleRef"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgLocalization"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgLocaleLocalization"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_6__["ɵangular_packages_common_common_a"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["ScrollStrategyOptions"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayContainer"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayPositionBuilder"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayKeyboardDispatcher"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["DOCUMENT"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_8__["Directionality"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_6__["Location"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["ɵc"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["ɵd"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["MutationObserverFactory"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["MutationObserverFactory"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MAT_SELECT_SCROLL_STRATEGY"], _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MAT_DIALOG_SCROLL_STRATEGY"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MAT_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](135680, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MatDialog"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MatDialog"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["Overlay"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_6__["Location"]], [2, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MAT_DIALOG_DEFAULT_OPTIONS"]], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MAT_DIALOG_SCROLL_STRATEGY"], [3, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MatDialog"]], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayContainer"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵangular_packages_forms_forms_o"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵangular_packages_forms_forms_o"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormBuilder"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormBuilder"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_router__WEBPACK_IMPORTED_MODULE_13__["RouterModule"], _angular_router__WEBPACK_IMPORTED_MODULE_13__["RouterModule"], [[2, _angular_router__WEBPACK_IMPORTED_MODULE_13__["ɵangular_packages_router_router_a"]], [2, _angular_router__WEBPACK_IMPORTED_MODULE_13__["Router"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_8__["BidiModule"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_8__["BidiModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatCommonModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatCommonModule"], [[2, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MATERIAL_SANITY_CHECKS"]], [2, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__["HAMMER_LOADER"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_16__["MatProgressSpinnerModule"], _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_16__["MatProgressSpinnerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_17__["PlatformModule"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_17__["PlatformModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatRippleModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatRippleModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_button__WEBPACK_IMPORTED_MODULE_18__["MatButtonModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_18__["MatButtonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__["MatIconModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__["MatIconModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_table__WEBPACK_IMPORTED_MODULE_20__["CdkTableModule"], _angular_cdk_table__WEBPACK_IMPORTED_MODULE_20__["CdkTableModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_table__WEBPACK_IMPORTED_MODULE_21__["MatTableModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_21__["MatTableModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatLineModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatLineModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatPseudoCheckboxModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatPseudoCheckboxModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__["MatDividerModule"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__["MatDividerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_list__WEBPACK_IMPORTED_MODULE_23__["MatListModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_23__["MatListModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_24__["PortalModule"], _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_24__["PortalModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_25__["ScrollingModule"], _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_25__["ScrollingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayModule"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatOptionModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatOptionModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["ObserversModule"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["ObserversModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_26__["MatFormFieldModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_26__["MatFormFieldModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MatSelectModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MatSelectModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MatDialogModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_11__["MatDialogModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵangular_packages_forms_forms_d"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵangular_packages_forms_forms_d"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__["MatProgressBarModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__["MatProgressBarModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_28__["_MatCheckboxRequiredValidatorModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_28__["_MatCheckboxRequiredValidatorModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_28__["MatCheckboxModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_28__["MatCheckboxModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _bk_employee_loan_app_el_shared_el_shared_module__WEBPACK_IMPORTED_MODULE_29__["ElSharedModule"], _bk_employee_loan_app_el_shared_el_shared_module__WEBPACK_IMPORTED_MODULE_29__["ElSharedModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _loading_module__WEBPACK_IMPORTED_MODULE_1__["LoadingModule"], _loading_module__WEBPACK_IMPORTED_MODULE_1__["LoadingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_router__WEBPACK_IMPORTED_MODULE_13__["ROUTES"], function () { return [[{ path: "", pathMatch: "full", component: _loading_component__WEBPACK_IMPORTED_MODULE_30__["LoadingComponent"] }]]; }, [])]); });



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.module.ts":
/*!***************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/loading/loading.module.ts ***!
  \***************************************************************************************************/
/*! exports provided: LoadingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingModule", function() { return LoadingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _loading_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loading.component */ "../../node_modules/@bk/byj-loan/app/bills/loading/loading.component.ts");


var routes = [
    {
        path: '',
        pathMatch: 'full',
        component: _loading_component__WEBPACK_IMPORTED_MODULE_1__["LoadingComponent"]
    }
];
var LoadingModule = (function () {
    function LoadingModule() {
    }
    return LoadingModule;
}());



/***/ }),

/***/ "../../node_modules/@bk/byj-loan/app/bills/result/result.service.ts":
/*!**************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/byj-loan/app/bills/result/result.service.ts ***!
  \**************************************************************************************************/
/*! exports provided: ResultService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultService", function() { return ResultService; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _bills_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../bills.service */ "../../node_modules/@bk/byj-loan/app/bills/bills.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");




var ResultService = (function () {
    function ResultService(router) {
        this.router = router;
        this._repayMentRes = null;
    }
    Object.defineProperty(ResultService.prototype, "repayMentRes", {
        get: function () {
            return this._repayMentRes;
        },
        enumerable: true,
        configurable: true
    });
    ResultService.prototype.next = function (result) {
        this._repayMentRes = result;
        switch (result.status) {
            case _bills_service__WEBPACK_IMPORTED_MODULE_1__["RepaymentResultStatus"].SUCCESS:
                this.router.navigate(["byj-loan/bills/result/success"], {
                    replaceUrl: true
                });
                break;
            case _bills_service__WEBPACK_IMPORTED_MODULE_1__["RepaymentResultStatus"].PROCESSING:
                this.router.navigate(["byj-loan/bills/result/process"], {
                    replaceUrl: true
                });
                break;
            case _bills_service__WEBPACK_IMPORTED_MODULE_1__["RepaymentResultStatus"].FAILED:
                this.router.navigate(["byj-loan/bills/result/failure"], {
                    replaceUrl: true
                });
                break;
            default:
                this.router.navigate(["byj-loan/bills/result/failure"], {
                    replaceUrl: true
                });
        }
    };
    ResultService.prototype.clear = function () {
        this._repayMentRes = null;
    };
    ResultService.prototype.gotoPending = function () {
        history.back();
    };
    ResultService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ factory: function ResultService_Factory() { return new ResultService(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_0__["Router"])); }, token: ResultService, providedIn: "root" });
    return ResultService;
}());



/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts":
/*!***********************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/apply/apply.service.ts ***!
  \***********************************************************************************************/
/*! exports provided: LoanPurpose, LoanMaturity, NetSalary, AccountType, EducationLevel, DepositoryStatus, ApplyStatus, RecordStatus, Result, RepaymentMethod, ApplyService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanPurpose", function() { return LoanPurpose; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanMaturity", function() { return LoanMaturity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NetSalary", function() { return NetSalary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountType", function() { return AccountType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EducationLevel", function() { return EducationLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepositoryStatus", function() { return DepositoryStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplyStatus", function() { return ApplyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecordStatus", function() { return RecordStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Result", function() { return Result; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepaymentMethod", function() { return RepaymentMethod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplyService", function() { return ApplyService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/snack-bar */ "../../node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _el_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../el-core */ "../../node_modules/@bk/employee-loan/app/el-core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _el_core_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../el-core/config */ "../../node_modules/@bk/employee-loan/app/el-core/config.ts");









var LoanPurpose;
(function (LoanPurpose) {
    LoanPurpose["PERSONAL"] = "PERSONAL";
    LoanPurpose["DAILY_CONSUMPTION"] = "DAILY_CONSUMPTION";
    LoanPurpose["SIGHTSEEING"] = "SIGHTSEEING";
    LoanPurpose["RENOVATION"] = "RENOVATION";
    LoanPurpose["EDUCATION"] = "EDUCATION";
    LoanPurpose["MEDICAL_TREATMENT"] = "MEDICAL_TREATMENT";
})(LoanPurpose || (LoanPurpose = {}));
var LoanMaturity;
(function (LoanMaturity) {
    LoanMaturity["MONTH_3"] = "MONTH_3";
    LoanMaturity["MONTH_6"] = "MONTH_6";
    LoanMaturity["MONTH_9"] = "MONTH_9";
    LoanMaturity["MONTH_12"] = "MONTH_12";
    LoanMaturity["MONTH_18"] = "MONTH_18";
})(LoanMaturity || (LoanMaturity = {}));
var NetSalary;
(function (NetSalary) {
    NetSalary[NetSalary["WITHIN_1"] = 0] = "WITHIN_1";
    NetSalary[NetSalary["BETWEEN_1_2"] = 1] = "BETWEEN_1_2";
    NetSalary[NetSalary["BETWEEN_2_3"] = 2] = "BETWEEN_2_3";
    NetSalary[NetSalary["BETWEEN_3_4"] = 3] = "BETWEEN_3_4";
    NetSalary[NetSalary["BETWEEN_4_5"] = 4] = "BETWEEN_4_5";
    NetSalary[NetSalary["ABOVE_5"] = 5] = "ABOVE_5";
})(NetSalary || (NetSalary = {}));
var AccountType;
(function (AccountType) {
    AccountType["PUBLIC"] = "PUBLIC";
    AccountType["PRIVATE"] = "PRIVATE";
})(AccountType || (AccountType = {}));
var EducationLevel;
(function (EducationLevel) {
    EducationLevel["PRIMARY_SCHOOL"] = "PRIMARY_SCHOOL";
    EducationLevel["MIDDLE_SCHOOL"] = "MIDDLE_SCHOOL";
    EducationLevel["HIGH_SCHOOL"] = "HIGH_SCHOOL";
    EducationLevel["COLLEGE"] = "COLLEGE";
    EducationLevel["BACHELOR"] = "BACHELOR";
    EducationLevel["MASTER"] = "MASTER";
    EducationLevel["DOCTOR"] = "DOCTOR";
    EducationLevel["OTHER"] = "OTHER";
})(EducationLevel || (EducationLevel = {}));
var DepositoryStatus;
(function (DepositoryStatus) {
    DepositoryStatus["SUBMIT_CARD"] = "SUBMIT_CARD";
    DepositoryStatus["WAIT_CONFIRM"] = "WAIT_CONFIRM";
    DepositoryStatus["OPEN_ACCOUNT_PROCESSING"] = "OPEN_ACCOUNT_PROCESSING";
    DepositoryStatus["OPEN_ACCOUNT_SUCCESS"] = "OPEN_ACCOUNT_SUCCESS";
    DepositoryStatus["OPEN_ACCOUNT_FAIL"] = "OPEN_ACCOUNT_FAIL";
    DepositoryStatus["SIGNED"] = "SIGNED";
})(DepositoryStatus || (DepositoryStatus = {}));
var ApplyStatus;
(function (ApplyStatus) {
    ApplyStatus["APPLY_CREATED"] = "APPLY_CREATED";
    ApplyStatus["ROUTE_PROCESSED"] = "ROUTE_PROCESSED";
    ApplyStatus["ACCOUNT_SUCCESS"] = "ACCOUNT_SUCCESS";
    ApplyStatus["SUBMITTED"] = "SUBMITTED";
    ApplyStatus["APPROVED"] = "APPROVED";
    ApplyStatus["SIGNED"] = "SIGNED";
    ApplyStatus["LOAN_CREATED"] = "LOAN_CREATED";
    ApplyStatus["LOAN_AUDITING"] = "LOAN_AUDITING";
    ApplyStatus["REMITTING"] = "REMITTING";
    ApplyStatus["REPAYING"] = "REPAYING";
    ApplyStatus["LOAN_AUDIT_FAILED"] = "LOAN_AUDIT_FAILED";
    ApplyStatus["FAILED"] = "FAILED";
    ApplyStatus["CANCELLED"] = "CANCELLED";
    ApplyStatus["COMPLETED"] = "COMPLETED";
    ApplyStatus["APPROVE_FAIL"] = "APPROVE_FAIL";
    ApplyStatus["MANUAL_APPROVED"] = "MANUAL_APPROVED";
    ApplyStatus["MANUAL_AUDITING"] = "MANUAL_AUDITING";
    ApplyStatus["MANUAL_APPROVE_FAIL"] = "MANUAL_APPROVE_FAIL";
    ApplyStatus["LOAN_REMIT_FAILED"] = "LOAN_REMIT_FAILED";
    ApplyStatus["LOAN_REMIT_REJECT"] = "LOAN_REMIT_REJECT";
})(ApplyStatus || (ApplyStatus = {}));
var RecordStatus;
(function (RecordStatus) {
    RecordStatus["CREATED"] = "CREATED";
    RecordStatus["SUBMITTED"] = "SUBMITTED";
    RecordStatus["APPROVED"] = "APPROVED";
    RecordStatus["SIGNED"] = "SIGNED";
    RecordStatus["COMPLETED"] = "COMPLETED";
    RecordStatus["CANCELLED"] = "CANCELLED";
    RecordStatus["APPROVE_FAIL"] = "APPROVE_FAIL";
    RecordStatus["EXPIRED"] = "EXPIRED";
})(RecordStatus || (RecordStatus = {}));
var Result;
(function (Result) {
    Result["lending"] = "lending";
    Result["audit"] = "audit";
    Result["lendingFail"] = "lendingFail";
    Result["processing"] = "processing";
    Result["cancel"] = "cancel";
    Result["openAccountFail"] = "openAccountFail";
    Result["lendingAuditFail"] = "lendingAuditFail";
    Result["needRealName"] = "needRealName";
    Result["employeeOnly"] = "employeeOnly";
})(Result || (Result = {}));
var RepaymentMethod;
(function (RepaymentMethod) {
    RepaymentMethod["AVERAGE_CAPITAL_PLUS_INTEREST"] = "AVERAGE_CAPITAL_PLUS_INTEREST";
    RepaymentMethod["AVERAGE_CAPITAL"] = "AVERAGE_CAPITAL";
    RepaymentMethod["BEFORE_INTEREST_AFTER_PRINCIPAL"] = "BEFORE_INTEREST_AFTER_PRINCIPAL";
    RepaymentMethod["ONE_OFF_REPAYMENT"] = "ONE_OFF_REPAYMENT";
    RepaymentMethod["EQUAL_PRINCIPAL_EQUAL_INTEREST"] = "EQUAL_PRINCIPAL_EQUAL_INTEREST";
})(RepaymentMethod || (RepaymentMethod = {}));
var ApplyService = (function () {
    function ApplyService(http, config, snackbar) {
        this.http = http;
        this.config = config;
        this.snackbar = snackbar;
        this.tokenHeaderName = 'X-BK-UUSSSO-Token';
        this.token = sessionStorage.getItem(this.tokenHeaderName) || '';
        this.productId = this.config.productId;
        this.applyStatusSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
    }
    ApplyService.prototype.ensureReady = function () {
        var _this = this;
        return this.getLastLoan().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["tap"])(function (res) {
            if (res.status !== 'success') {
                _this.handleError(res.message);
            }
            else {
                _this.LastLoan = res.data;
                _this.applyId = _this.LastLoan.withdrawApplyId;
                _this.applyStatus = res.data.loanProgressStatus;
            }
        }));
    };
    ApplyService.prototype.isBoneng = function () {
        return this.LastLoan && this.LastLoan.fundSide === 'bnxd' ? true : false;
    };
    ApplyService.prototype.getCreditLimit = function () {
        return this.http.get('el-api://credit-limit?productId=' + this.productId);
    };
    ApplyService.prototype.getMaturity = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/maturity');
    };
    ApplyService.prototype.getPurpose = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/purpose');
    };
    ApplyService.prototype.doSignature = function () {
        return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/signature', null);
    };
    ApplyService.prototype.getTrial = function (req) {
        return this.http.post('el-api-loan://loan/withdraw-apply/' + this.productId + '/trial', req, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'X-BK-UUSSSO-Token': this.token
            })
        });
    };
    ApplyService.prototype.doCreateOrUpdate = function (req) {
        return this.http.post('el-api-loan://withdraw-apply/' + this.productId + '/create-or-update', req, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'X-BK-UUSSSO-Token': this.token
            })
        });
    };
    ApplyService.prototype.getFileList = function (applyId) {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/file-list?applyId=' + applyId || false);
    };
    ApplyService.prototype.doUploadFile = function (req) {
        var fd = new FormData();
        fd.append('file', req.file);
        return this.http.post('el-api-loan://withdraw-apply/' + req.fileId + '/upload-file?applyId=' + req.applyId + '&fileType=LOAN_PURPOSE_CERTIFICATION', fd);
    };
    ApplyService.prototype.doDeleteFile = function (fileId) {
        return this.http.delete('el-api-loan://withdraw-apply/' + fileId + '/delete-file');
    };
    ApplyService.prototype.doPersonalInfo = function (req) {
        return this.http.post('el-api-user://personal-info?applyId=' + this.applyId + '&productId=' + this.productId, req);
    };
    ApplyService.prototype.doFundExamine = function () {
        return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/standard-fund-examine', null);
    };
    ApplyService.prototype.getPersonalInfo = function () {
        return this.http.get('el-api-user://personal-info?productId=' + this.productId);
    };
    ApplyService.prototype.getIdCard = function () {
        return this.http.get('el-api-user://id-card');
    };
    ApplyService.prototype.getDepositoryAccount = function () {
        return this.http.get('el-api-loan://depository-account');
    };
    ApplyService.prototype.getDepositoryUserInfo = function () {
        return this.http.get('el-api-loan://depository-account/user-info?applyId=' + this.applyId);
    };
    ApplyService.prototype.doCardInfo = function (req) {
        return this.http.post('el-api-loan://depository-account/card-info?applyId=' + this.applyId, req);
    };
    ApplyService.prototype.doDepositoryChange = function (action) {
        return this.http.post('el-api-loan://depository-account/card-info/change?action=' + action, null);
    };
    ApplyService.prototype.doDepositoryAccount = function (req) {
        return this.http.post('el-api-loan://depository-account?applyId=' + req.applyId, req);
    };
    ApplyService.prototype.doDepositorySignSms = function () {
        return this.http.post('el-api-loan://depository-account/sign-sms', null);
    };
    ApplyService.prototype.doDepositorySign = function (req) {
        return this.http.post('el-api-loan://depository-account/sign?verifyCode=' + req.verifyCode, req);
    };
    ApplyService.prototype.doConfirmSign = function (code) {
        if (code) {
            return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/submit?code=' + code, null, {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                    'X-BK-UUSSSO-Token': this.token
                })
            });
        }
        else {
            return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/submit', null, {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                    'X-BK-UUSSSO-Token': this.token
                })
            });
        }
    };
    ApplyService.prototype.getLastLoan = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/latest-loan');
    };
    ApplyService.prototype.getLastRecord = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/latest-record');
    };
    ApplyService.prototype.getLoanRecord = function (loanId, applyId) {
        if (loanId) {
            return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/loan-record?loanId=' + loanId);
        }
        if (applyId) {
            return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/loan-record?applyId=' + applyId);
        }
    };
    ApplyService.prototype.handleError = function (err) {
        var _this = this;
        this.snackbar.open(err);
        setTimeout(function () {
            _this.snackbar.dismiss();
        }, 3000);
    };
    ApplyService.prototype.validateCard = function (cardNo) {
        return /^[0-9]{13,19}\d*$/g.test(cardNo + '');
    };
    ApplyService.prototype.validatePhoneNumber = function (phone) {
        var reg = /^[1][0-9]{10}$/;
        return reg.test(phone);
    };
    ApplyService.prototype.validateName = function (name) {
        if (name.length < 2) {
            return false;
        }
        var reg = /^[\u4E00-\u9FA5\uF900-\uFA2D\·]+$/g;
        return reg.test(name);
    };
    ApplyService.prototype.getGuid = function () {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4() + '';
    };
    ApplyService.prototype.mappingMaturity = function (maturity) {
        var mapping = {
            MONTH_1: '1',
            MONTH_3: '3',
            MONTH_6: '6',
            MONTH_9: '9',
            MONTH_12: '12',
            MONTH_18: '18',
            MONTH_24: '24',
            MONTH_36: '36'
        };
        return mapping[maturity] || maturity;
    };
    ApplyService.prototype.mappingApplyStatus = function (apiStatus) {
        var mapping = {
            LOAN_CREATED: 'lending',
            SUBMITTED: 'lending',
            APPROVED: 'lending',
            LOAN_AUDITING: 'lending',
            REMITTING: 'audit',
            FAILED: 'lendingFail',
            processing: 'processing',
            APPROVE_FAIL: 'cancel',
            LOAN_REMIT_FAILED: 'cancel',
            OPEN_ACCOUNT_FAIL: 'openAccountFail',
            LOAN_AUDIT_FAILED: 'lendingAuditFail',
            needRealName: 'needRealName',
            employeeOnly: 'employeeOnly'
        };
        return mapping[apiStatus] || apiStatus;
    };
    ApplyService.prototype.mappingBclStatus = function (apiStatus) {
        var mapping = {
            SIGNED: 'manual',
            SUBMITTED: 'manual',
            APPROVED: 'audit',
            LOAN_AUDITING: 'audit',
            REMITTING: 'audit',
            FAILED: 'lendingFail',
            APPROVE_FAIL: 'riskFail',
            LOAN_AUDIT_FAILED: 'lendingFail',
            LOAN_REMIT_FAILED: 'lendingFail',
            LOAN_REMIT_REJECT: 'lendingFail',
            CANCELLED: 'CANCELLED',
            MANUAL_APPROVE_FAIL: 'lendingFail',
            MANUAL_AUDITING: 'manual',
            MANUAL_APPROVED: 'manual'
        };
        return mapping[apiStatus] || apiStatus;
    };
    ApplyService.prototype.getCurHost = function () {
        return window.location.protocol + '//' + window.location.host;
    };
    ApplyService.prototype.isFlowFail = function (status) {
        if (status === 'APPROVE_FAIL' || status === 'FAILED' || status === 'CANCELLED' || status === 'COMPLETED') {
            return true;
        }
        else {
            return false;
        }
    };
    ApplyService.prototype.maskPhone = function (phone) {
        if (phone === void 0) { phone = ''; }
        return phone.substr(0, 3) + '****' + phone.substr(7);
    };
    ApplyService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ factory: function ApplyService_Factory() { return new ApplyService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_el_core_config__WEBPACK_IMPORTED_MODULE_6__["EL_CONFIG"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"])); }, token: ApplyService, providedIn: "root" });
    return ApplyService;
}());



/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ngfactory.js":
/*!*******************************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ngfactory.js ***!
  \*******************************************************************************************************************************/
/*! exports provided: RenderType_CountDownComponent, View_CountDownComponent_0, View_CountDownComponent_Host_0, CountDownComponentNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RenderType_CountDownComponent", function() { return RenderType_CountDownComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_CountDownComponent_0", function() { return View_CountDownComponent_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_CountDownComponent_Host_0", function() { return View_CountDownComponent_Host_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountDownComponentNgFactory", function() { return CountDownComponentNgFactory; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _count_down_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./count-down.component */ "../../node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ts");



var styles_CountDownComponent = [];
var RenderType_CountDownComponent = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵcrt"]({ encapsulation: 2, styles: styles_CountDownComponent, data: {} });

function View_CountDownComponent_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵvid"](2, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵted"](0, null, [" ", " "])), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵpid"](131072, _angular_common__WEBPACK_IMPORTED_MODULE_1__["AsyncPipe"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]])], null, function (_ck, _v) { var _co = _v.component; var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵunv"](_v, 0, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵnov"](_v, 1).transform(_co._timer$)); _ck(_v, 0, 0, currVal_0); }); }
function View_CountDownComponent_Host_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵeld"](0, 0, null, null, 1, "el-count-down", [], [[8, "className", 0]], null, null, View_CountDownComponent_0, RenderType_CountDownComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵdid"](1, 49152, null, 0, _count_down_component__WEBPACK_IMPORTED_MODULE_2__["CountDownComponent"], [], null, null)], null, function (_ck, _v) { var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵnov"](_v, 1).className; _ck(_v, 0, 0, currVal_0); }); }
var CountDownComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵccf"]("el-count-down", _count_down_component__WEBPACK_IMPORTED_MODULE_2__["CountDownComponent"], View_CountDownComponent_Host_0, { target: "target", format: "format", emitProcessEvent: "emitProcessEvent" }, { process: "process", stop: "stop" }, []);



/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ts":
/*!*********************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/el-shared/count-down/count-down.component.ts ***!
  \*********************************************************************************************************************/
/*! exports provided: CountDownComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountDownComponent", function() { return CountDownComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");



var CountDownComponent = (function () {
    function CountDownComponent() {
        this.className = 'el-count-down';
        this.format = this.defaultFormat;
        this.emitProcessEvent = false;
        this.process = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.stop = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this._counting = false;
    }
    Object.defineProperty(CountDownComponent.prototype, "target", {
        get: function () {
            return this._target;
        },
        set: function (date) {
            var _this = this;
            if (!(date instanceof Date)) {
                return;
            }
            this._target = date;
            var seconds = Math.max(Math.floor((date.getTime() - Date.now()) / 1000), 0);
            var currentSeconds = seconds;
            this._timer$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["timer"])(0, 1000).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(seconds + 1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])(function (s) {
                if (s === 0) {
                    _this.toggleCountingStatus();
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (s) {
                currentSeconds = seconds - s;
                if (_this.emitProcessEvent) {
                    _this.process.emit(currentSeconds);
                }
                _this.curSecond = _this.format(currentSeconds);
                return _this.curSecond;
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(function () {
                _this.toggleCountingStatus();
                _this.stop.emit(currentSeconds);
            }));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CountDownComponent.prototype, "counting", {
        get: function () {
            return this._counting;
        },
        enumerable: true,
        configurable: true
    });
    CountDownComponent.prototype.toggleCountingStatus = function () {
        var _this = this;
        Promise.resolve().then(function () {
            _this._counting = !_this._counting;
        });
    };
    CountDownComponent.prototype.defaultFormat = function (seconds) {
        if (seconds) {
            var s = seconds < 10 ? "0" + seconds : "" + seconds;
            return s + "s\u540E\u91CD\u53D1";
        }
        else {
            return '';
        }
    };
    return CountDownComponent;
}());



/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/repay/index/repay.service.ts":
/*!*****************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/repay/index/repay.service.ts ***!
  \*****************************************************************************************************/
/*! exports provided: RepayService, RepayType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepayService", function() { return RepayService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepayType", function() { return RepayType; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _el_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../el-core */ "../../node_modules/@bk/employee-loan/app/el-core/index.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../types */ "../../node_modules/@bk/employee-loan/app/repay/types.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _el_core_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../el-core/user.service */ "../../node_modules/@bk/employee-loan/app/el-core/user.service.ts");
/* harmony import */ var _el_core_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../el-core/config */ "../../node_modules/@bk/employee-loan/app/el-core/config.ts");







var RepayService = (function () {
    function RepayService(httpClient, userService, config) {
        this.httpClient = httpClient;
        this.userService = userService;
        this.config = config;
    }
    Object.defineProperty(RepayService.prototype, "latestRepaymentPlan", {
        get: function () {
            return this.latestRepaymentPlanCache;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RepayService.prototype, "loanId", {
        get: function () {
            if (this.latestRepaymentPlan) {
                return this.latestRepaymentPlan.loanId;
            }
        },
        enumerable: true,
        configurable: true
    });
    RepayService.prototype.cacheLatestRepaymentPlan = function (data) {
        this.latestRepaymentPlanCache = data;
    };
    RepayService.prototype.clearCache = function () {
        this.latestRepaymentPlanCache = null;
    };
    RepayService.prototype.isOverdue = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].OVERDUE;
    };
    RepayService.prototype.isRepaying = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].REPAYING;
    };
    RepayService.prototype.isSettle = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].SETTLE;
    };
    RepayService.prototype.isWaitRepayment = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].WAIT_REPAYMENT;
    };
    RepayService.prototype.isNoAccount = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].NOACCOUNT;
    };
    RepayService.prototype.isEntering = function (status) {
        return status === _types__WEBPACK_IMPORTED_MODULE_2__["RepaymentPlanListItemStatus"].ENTERING;
    };
    RepayService.prototype.canRepay = function (waitPay) {
        return waitPay;
    };
    RepayService.prototype.repay = function (repayRequest) {
        var _a;
        return this.httpClient.post('el-api-loan://loan/repay', repayRequest, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]((_a = {},
                _a[this.userService.tokenHeaderName] = this.userService.token,
                _a))
        });
    };
    RepayService.prototype.getLatestRepaymentPlan = function () {
        return this.httpClient.get("el-api-loan://loan/repayment-plan/latest/" + this.config.productId);
    };
    RepayService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ factory: function RepayService_Factory() { return new RepayService(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_el_core_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_el_core_config__WEBPACK_IMPORTED_MODULE_5__["EL_CONFIG"])); }, token: RepayService, providedIn: "root" });
    return RepayService;
}());

var RepayType;
(function (RepayType) {
    RepayType["EARLY"] = "EARLY";
    RepayType["NORMAL"] = "NORMAL";
})(RepayType || (RepayType = {}));
var RepaymentResultStatus;
(function (RepaymentResultStatus) {
    RepaymentResultStatus["WAIT_PAY"] = "WAIT_PAY";
    RepaymentResultStatus["PRCOSSING"] = "PRCOSSING";
    RepaymentResultStatus["CANCEL"] = "CANCEL";
    RepaymentResultStatus["SUCCESS"] = "SUCCESS";
})(RepaymentResultStatus || (RepaymentResultStatus = {}));


/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/repay/types.ts":
/*!***************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/repay/types.ts ***!
  \***************************************************************************************/
/*! exports provided: LoanStatus, RepaymentPlanListItemStatus, LoanTermUnit, RepaymentMethod */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanStatus", function() { return LoanStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepaymentPlanListItemStatus", function() { return RepaymentPlanListItemStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanTermUnit", function() { return LoanTermUnit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepaymentMethod", function() { return RepaymentMethod; });
var LoanStatus;
(function (LoanStatus) {
    LoanStatus["RISK_CONTROL_AUDIT_PASSED"] = "RISK_CONTROL_AUDIT_PASSED";
    LoanStatus["LOAN_AUDITING"] = "LOAN_AUDITING";
    LoanStatus["REMIT_CHECK_FAIL"] = "REMIT_CHECK_FAIL";
    LoanStatus["LENDING"] = "LENDING";
    LoanStatus["REMIT_SUCCESS"] = "REMIT_SUCCESS";
    LoanStatus["REPAYMENT_PERIOD"] = "REPAYMENT_PERIOD";
    LoanStatus["OVERDUE"] = "OVERDUE";
    LoanStatus["BAD_DEBT"] = "BAD_DEBT";
    LoanStatus["EARLY_SETTLE"] = "EARLY_SETTLE";
    LoanStatus["NORMAL_SETTLE"] = "NORMAL_SETTLE";
    LoanStatus["REMIT_FAIL"] = "REMIT_FAIL";
})(LoanStatus || (LoanStatus = {}));
var RepaymentPlanListItemStatus;
(function (RepaymentPlanListItemStatus) {
    RepaymentPlanListItemStatus["WAIT_REPAYMENT"] = "WAIT_REPAYMENT";
    RepaymentPlanListItemStatus["REPAYING"] = "REPAYING";
    RepaymentPlanListItemStatus["OVERDUE"] = "OVERDUE";
    RepaymentPlanListItemStatus["SETTLE"] = "SETTLE";
    RepaymentPlanListItemStatus["NOACCOUNT"] = "NO_ACCOUNT";
    RepaymentPlanListItemStatus["ENTERING"] = "ENTERING";
})(RepaymentPlanListItemStatus || (RepaymentPlanListItemStatus = {}));
var LoanTermUnit;
(function (LoanTermUnit) {
    LoanTermUnit["DAY"] = "DAY";
    LoanTermUnit["MONTH"] = "MONTH";
    LoanTermUnit["YEAR"] = "YEAR";
})(LoanTermUnit || (LoanTermUnit = {}));
var RepaymentMethod;
(function (RepaymentMethod) {
    RepaymentMethod["AVERAGE_CAPITAL_PLUS_INTEREST"] = "AVERAGE_CAPITAL_PLUS_INTEREST";
    RepaymentMethod["AVERAGE_CAPITAL"] = "AVERAGE_CAPITAL";
    RepaymentMethod["BEFORE_INTEREST_AFTER_PRINCIPAL"] = "BEFORE_INTEREST_AFTER_PRINCIPAL";
    RepaymentMethod["ONE_OFF_REPAYMENT"] = "ONE_OFF_REPAYMENT";
    RepaymentMethod["EQUAL_PRINCIPAL_EQUAL_INTEREST"] = "EQUAL_PRINCIPAL_EQUAL_INTEREST";
})(RepaymentMethod || (RepaymentMethod = {}));


/***/ })

}]);
//# sourceMappingURL=loading-loading-module-ngfactory.js.map