(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bk-module-agreement-ngfactory"],{

/***/ "../../../dr-comp-package/src/internal/webpack2-builder/dist/loaders/dr-file-loader.js!../../node_modules/@bk/module-agreement/assets/pdf.worker.js":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** /Users/liujing/bk/dr-comp-package/src/internal/webpack2-builder/dist/loaders/dr-file-loader.js!/Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/assets/pdf.worker.js ***!
  \*******************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "agreement/assets/pdf.worker.e0638c0c.js";

/***/ }),

/***/ "../../node_modules/@bk/animation/common-anim.directive.ts":
/*!*****************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/animation/common-anim.directive.ts ***!
  \*****************************************************************************************/
/*! exports provided: CommonAnimBase, CommonAnimDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonAnimBase", function() { return CommonAnimBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonAnimDirective", function() { return CommonAnimDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");


var CommonAnimBase = (function () {
    function CommonAnimBase(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        this._stagState = 'hide';
        this._listStagState = 'hide';
        renderer.addClass(element.nativeElement, 'bk-common-anim');
    }
    CommonAnimBase.prototype.playStag = function (stagTime, animDuration, limit) {
        if (stagTime === void 0) { stagTime = 80; }
        if (animDuration === void 0) { animDuration = 300; }
        if (limit === void 0) { limit = 20; }
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var dom, children, l, i;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        dom = this.element.nativeElement;
                        children = dom.querySelectorAll('.stag-item');
                        l = children.length;
                        i = 0;
                        if (l < limit) {
                            limit = l;
                        }
                        return [4, new Promise(function (resolve) {
                                var _loop_1 = function () {
                                    var item = children.item(i);
                                    _this.renderer.removeClass(item, 'stag-done');
                                    _this.renderer.addClass(item, 'stag');
                                    var idx = i;
                                    setTimeout(function () {
                                        var child = item;
                                        _this.renderer.addClass(child, 'stag-active');
                                        setTimeout(function () {
                                            _this.renderer.removeClass(item, 'stag');
                                            _this.renderer.removeClass(child, 'stag-active');
                                            _this.renderer.addClass(child, 'stag-done');
                                            if (idx + 1 === limit) {
                                                resolve();
                                            }
                                        }, animDuration);
                                    }, stagTime * i);
                                };
                                for (i = 0; i < limit; i++) {
                                    _loop_1();
                                }
                            })];
                    case 1:
                        _a.sent();
                        for (; i < l; i++) {
                            this.renderer.addClass(children.item(i), 'stag-done');
                        }
                        return [2];
                }
            });
        });
    };
    CommonAnimBase.prototype.playSlide = function () {
        setTimeout(function () {
        }, 0);
    };
    return CommonAnimBase;
}());

var CommonAnimDirective = (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](CommonAnimDirective, _super);
    function CommonAnimDirective(el, cd, renderer) {
        return _super.call(this, el, renderer) || this;
    }
    return CommonAnimDirective;
}(CommonAnimBase));



/***/ }),

/***/ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts":
/*!***********************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/employee-loan/app/apply/apply.service.ts ***!
  \***********************************************************************************************/
/*! exports provided: LoanPurpose, LoanMaturity, NetSalary, AccountType, EducationLevel, DepositoryStatus, ApplyStatus, RecordStatus, Result, RepaymentMethod, ApplyService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanPurpose", function() { return LoanPurpose; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanMaturity", function() { return LoanMaturity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NetSalary", function() { return NetSalary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountType", function() { return AccountType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EducationLevel", function() { return EducationLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepositoryStatus", function() { return DepositoryStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplyStatus", function() { return ApplyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecordStatus", function() { return RecordStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Result", function() { return Result; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepaymentMethod", function() { return RepaymentMethod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplyService", function() { return ApplyService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/snack-bar */ "../../node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _el_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../el-core */ "../../node_modules/@bk/employee-loan/app/el-core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _el_core_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../el-core/config */ "../../node_modules/@bk/employee-loan/app/el-core/config.ts");









var LoanPurpose;
(function (LoanPurpose) {
    LoanPurpose["PERSONAL"] = "PERSONAL";
    LoanPurpose["DAILY_CONSUMPTION"] = "DAILY_CONSUMPTION";
    LoanPurpose["SIGHTSEEING"] = "SIGHTSEEING";
    LoanPurpose["RENOVATION"] = "RENOVATION";
    LoanPurpose["EDUCATION"] = "EDUCATION";
    LoanPurpose["MEDICAL_TREATMENT"] = "MEDICAL_TREATMENT";
})(LoanPurpose || (LoanPurpose = {}));
var LoanMaturity;
(function (LoanMaturity) {
    LoanMaturity["MONTH_3"] = "MONTH_3";
    LoanMaturity["MONTH_6"] = "MONTH_6";
    LoanMaturity["MONTH_9"] = "MONTH_9";
    LoanMaturity["MONTH_12"] = "MONTH_12";
    LoanMaturity["MONTH_18"] = "MONTH_18";
})(LoanMaturity || (LoanMaturity = {}));
var NetSalary;
(function (NetSalary) {
    NetSalary[NetSalary["WITHIN_1"] = 0] = "WITHIN_1";
    NetSalary[NetSalary["BETWEEN_1_2"] = 1] = "BETWEEN_1_2";
    NetSalary[NetSalary["BETWEEN_2_3"] = 2] = "BETWEEN_2_3";
    NetSalary[NetSalary["BETWEEN_3_4"] = 3] = "BETWEEN_3_4";
    NetSalary[NetSalary["BETWEEN_4_5"] = 4] = "BETWEEN_4_5";
    NetSalary[NetSalary["ABOVE_5"] = 5] = "ABOVE_5";
})(NetSalary || (NetSalary = {}));
var AccountType;
(function (AccountType) {
    AccountType["PUBLIC"] = "PUBLIC";
    AccountType["PRIVATE"] = "PRIVATE";
})(AccountType || (AccountType = {}));
var EducationLevel;
(function (EducationLevel) {
    EducationLevel["PRIMARY_SCHOOL"] = "PRIMARY_SCHOOL";
    EducationLevel["MIDDLE_SCHOOL"] = "MIDDLE_SCHOOL";
    EducationLevel["HIGH_SCHOOL"] = "HIGH_SCHOOL";
    EducationLevel["COLLEGE"] = "COLLEGE";
    EducationLevel["BACHELOR"] = "BACHELOR";
    EducationLevel["MASTER"] = "MASTER";
    EducationLevel["DOCTOR"] = "DOCTOR";
    EducationLevel["OTHER"] = "OTHER";
})(EducationLevel || (EducationLevel = {}));
var DepositoryStatus;
(function (DepositoryStatus) {
    DepositoryStatus["SUBMIT_CARD"] = "SUBMIT_CARD";
    DepositoryStatus["WAIT_CONFIRM"] = "WAIT_CONFIRM";
    DepositoryStatus["OPEN_ACCOUNT_PROCESSING"] = "OPEN_ACCOUNT_PROCESSING";
    DepositoryStatus["OPEN_ACCOUNT_SUCCESS"] = "OPEN_ACCOUNT_SUCCESS";
    DepositoryStatus["OPEN_ACCOUNT_FAIL"] = "OPEN_ACCOUNT_FAIL";
    DepositoryStatus["SIGNED"] = "SIGNED";
})(DepositoryStatus || (DepositoryStatus = {}));
var ApplyStatus;
(function (ApplyStatus) {
    ApplyStatus["APPLY_CREATED"] = "APPLY_CREATED";
    ApplyStatus["ROUTE_PROCESSED"] = "ROUTE_PROCESSED";
    ApplyStatus["ACCOUNT_SUCCESS"] = "ACCOUNT_SUCCESS";
    ApplyStatus["SUBMITTED"] = "SUBMITTED";
    ApplyStatus["APPROVED"] = "APPROVED";
    ApplyStatus["SIGNED"] = "SIGNED";
    ApplyStatus["LOAN_CREATED"] = "LOAN_CREATED";
    ApplyStatus["LOAN_AUDITING"] = "LOAN_AUDITING";
    ApplyStatus["REMITTING"] = "REMITTING";
    ApplyStatus["REPAYING"] = "REPAYING";
    ApplyStatus["LOAN_AUDIT_FAILED"] = "LOAN_AUDIT_FAILED";
    ApplyStatus["FAILED"] = "FAILED";
    ApplyStatus["CANCELLED"] = "CANCELLED";
    ApplyStatus["COMPLETED"] = "COMPLETED";
    ApplyStatus["APPROVE_FAIL"] = "APPROVE_FAIL";
    ApplyStatus["MANUAL_APPROVED"] = "MANUAL_APPROVED";
    ApplyStatus["MANUAL_AUDITING"] = "MANUAL_AUDITING";
    ApplyStatus["MANUAL_APPROVE_FAIL"] = "MANUAL_APPROVE_FAIL";
    ApplyStatus["LOAN_REMIT_FAILED"] = "LOAN_REMIT_FAILED";
    ApplyStatus["LOAN_REMIT_REJECT"] = "LOAN_REMIT_REJECT";
})(ApplyStatus || (ApplyStatus = {}));
var RecordStatus;
(function (RecordStatus) {
    RecordStatus["CREATED"] = "CREATED";
    RecordStatus["SUBMITTED"] = "SUBMITTED";
    RecordStatus["APPROVED"] = "APPROVED";
    RecordStatus["SIGNED"] = "SIGNED";
    RecordStatus["COMPLETED"] = "COMPLETED";
    RecordStatus["CANCELLED"] = "CANCELLED";
    RecordStatus["APPROVE_FAIL"] = "APPROVE_FAIL";
    RecordStatus["EXPIRED"] = "EXPIRED";
})(RecordStatus || (RecordStatus = {}));
var Result;
(function (Result) {
    Result["lending"] = "lending";
    Result["audit"] = "audit";
    Result["lendingFail"] = "lendingFail";
    Result["processing"] = "processing";
    Result["cancel"] = "cancel";
    Result["openAccountFail"] = "openAccountFail";
    Result["lendingAuditFail"] = "lendingAuditFail";
    Result["needRealName"] = "needRealName";
    Result["employeeOnly"] = "employeeOnly";
})(Result || (Result = {}));
var RepaymentMethod;
(function (RepaymentMethod) {
    RepaymentMethod["AVERAGE_CAPITAL_PLUS_INTEREST"] = "AVERAGE_CAPITAL_PLUS_INTEREST";
    RepaymentMethod["AVERAGE_CAPITAL"] = "AVERAGE_CAPITAL";
    RepaymentMethod["BEFORE_INTEREST_AFTER_PRINCIPAL"] = "BEFORE_INTEREST_AFTER_PRINCIPAL";
    RepaymentMethod["ONE_OFF_REPAYMENT"] = "ONE_OFF_REPAYMENT";
    RepaymentMethod["EQUAL_PRINCIPAL_EQUAL_INTEREST"] = "EQUAL_PRINCIPAL_EQUAL_INTEREST";
})(RepaymentMethod || (RepaymentMethod = {}));
var ApplyService = (function () {
    function ApplyService(http, config, snackbar) {
        this.http = http;
        this.config = config;
        this.snackbar = snackbar;
        this.tokenHeaderName = 'X-BK-UUSSSO-Token';
        this.token = sessionStorage.getItem(this.tokenHeaderName) || '';
        this.productId = this.config.productId;
        this.applyStatusSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
    }
    ApplyService.prototype.ensureReady = function () {
        var _this = this;
        return this.getLastLoan().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["tap"])(function (res) {
            if (res.status !== 'success') {
                _this.handleError(res.message);
            }
            else {
                _this.LastLoan = res.data;
                _this.applyId = _this.LastLoan.withdrawApplyId;
                _this.applyStatus = res.data.loanProgressStatus;
            }
        }));
    };
    ApplyService.prototype.isBoneng = function () {
        return this.LastLoan && this.LastLoan.fundSide === 'bnxd' ? true : false;
    };
    ApplyService.prototype.getCreditLimit = function () {
        return this.http.get('el-api://credit-limit?productId=' + this.productId);
    };
    ApplyService.prototype.getMaturity = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/maturity');
    };
    ApplyService.prototype.getPurpose = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/purpose');
    };
    ApplyService.prototype.doSignature = function () {
        return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/signature', null);
    };
    ApplyService.prototype.getTrial = function (req) {
        return this.http.post('el-api-loan://loan/withdraw-apply/' + this.productId + '/trial', req, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'X-BK-UUSSSO-Token': this.token
            })
        });
    };
    ApplyService.prototype.doCreateOrUpdate = function (req) {
        return this.http.post('el-api-loan://withdraw-apply/' + this.productId + '/create-or-update', req, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'X-BK-UUSSSO-Token': this.token
            })
        });
    };
    ApplyService.prototype.getFileList = function (applyId) {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/file-list?applyId=' + applyId || false);
    };
    ApplyService.prototype.doUploadFile = function (req) {
        var fd = new FormData();
        fd.append('file', req.file);
        return this.http.post('el-api-loan://withdraw-apply/' + req.fileId + '/upload-file?applyId=' + req.applyId + '&fileType=LOAN_PURPOSE_CERTIFICATION', fd);
    };
    ApplyService.prototype.doDeleteFile = function (fileId) {
        return this.http.delete('el-api-loan://withdraw-apply/' + fileId + '/delete-file');
    };
    ApplyService.prototype.doPersonalInfo = function (req) {
        return this.http.post('el-api-user://personal-info?applyId=' + this.applyId + '&productId=' + this.productId, req);
    };
    ApplyService.prototype.doFundExamine = function () {
        return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/standard-fund-examine', null);
    };
    ApplyService.prototype.getPersonalInfo = function () {
        return this.http.get('el-api-user://personal-info?productId=' + this.productId);
    };
    ApplyService.prototype.getIdCard = function () {
        return this.http.get('el-api-user://id-card');
    };
    ApplyService.prototype.getDepositoryAccount = function () {
        return this.http.get('el-api-loan://depository-account');
    };
    ApplyService.prototype.getDepositoryUserInfo = function () {
        return this.http.get('el-api-loan://depository-account/user-info?applyId=' + this.applyId);
    };
    ApplyService.prototype.doCardInfo = function (req) {
        return this.http.post('el-api-loan://depository-account/card-info?applyId=' + this.applyId, req);
    };
    ApplyService.prototype.doDepositoryChange = function (action) {
        return this.http.post('el-api-loan://depository-account/card-info/change?action=' + action, null);
    };
    ApplyService.prototype.doDepositoryAccount = function (req) {
        return this.http.post('el-api-loan://depository-account?applyId=' + req.applyId, req);
    };
    ApplyService.prototype.doDepositorySignSms = function () {
        return this.http.post('el-api-loan://depository-account/sign-sms', null);
    };
    ApplyService.prototype.doDepositorySign = function (req) {
        return this.http.post('el-api-loan://depository-account/sign?verifyCode=' + req.verifyCode, req);
    };
    ApplyService.prototype.doConfirmSign = function (code) {
        if (code) {
            return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/submit?code=' + code, null, {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                    'X-BK-UUSSSO-Token': this.token
                })
            });
        }
        else {
            return this.http.post('el-api-loan://withdraw-apply/' + this.applyId + '/submit', null, {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                    'X-BK-UUSSSO-Token': this.token
                })
            });
        }
    };
    ApplyService.prototype.getLastLoan = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/latest-loan');
    };
    ApplyService.prototype.getLastRecord = function () {
        return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/latest-record');
    };
    ApplyService.prototype.getLoanRecord = function (loanId, applyId) {
        if (loanId) {
            return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/loan-record?loanId=' + loanId);
        }
        if (applyId) {
            return this.http.get('el-api-loan://withdraw-apply/' + this.productId + '/loan-record?applyId=' + applyId);
        }
    };
    ApplyService.prototype.handleError = function (err) {
        var _this = this;
        this.snackbar.open(err);
        setTimeout(function () {
            _this.snackbar.dismiss();
        }, 3000);
    };
    ApplyService.prototype.validateCard = function (cardNo) {
        return /^[0-9]{13,19}\d*$/g.test(cardNo + '');
    };
    ApplyService.prototype.validatePhoneNumber = function (phone) {
        var reg = /^[1][0-9]{10}$/;
        return reg.test(phone);
    };
    ApplyService.prototype.validateName = function (name) {
        if (name.length < 2) {
            return false;
        }
        var reg = /^[\u4E00-\u9FA5\uF900-\uFA2D\·]+$/g;
        return reg.test(name);
    };
    ApplyService.prototype.getGuid = function () {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4() + '';
    };
    ApplyService.prototype.mappingMaturity = function (maturity) {
        var mapping = {
            MONTH_1: '1',
            MONTH_3: '3',
            MONTH_6: '6',
            MONTH_9: '9',
            MONTH_12: '12',
            MONTH_18: '18',
            MONTH_24: '24',
            MONTH_36: '36'
        };
        return mapping[maturity] || maturity;
    };
    ApplyService.prototype.mappingApplyStatus = function (apiStatus) {
        var mapping = {
            LOAN_CREATED: 'lending',
            SUBMITTED: 'lending',
            APPROVED: 'lending',
            LOAN_AUDITING: 'lending',
            REMITTING: 'audit',
            FAILED: 'lendingFail',
            processing: 'processing',
            APPROVE_FAIL: 'cancel',
            LOAN_REMIT_FAILED: 'cancel',
            OPEN_ACCOUNT_FAIL: 'openAccountFail',
            LOAN_AUDIT_FAILED: 'lendingAuditFail',
            needRealName: 'needRealName',
            employeeOnly: 'employeeOnly'
        };
        return mapping[apiStatus] || apiStatus;
    };
    ApplyService.prototype.mappingBclStatus = function (apiStatus) {
        var mapping = {
            SIGNED: 'manual',
            SUBMITTED: 'manual',
            APPROVED: 'audit',
            LOAN_AUDITING: 'audit',
            REMITTING: 'audit',
            FAILED: 'lendingFail',
            APPROVE_FAIL: 'riskFail',
            LOAN_AUDIT_FAILED: 'lendingFail',
            LOAN_REMIT_FAILED: 'lendingFail',
            LOAN_REMIT_REJECT: 'lendingFail',
            CANCELLED: 'CANCELLED',
            MANUAL_APPROVE_FAIL: 'lendingFail',
            MANUAL_AUDITING: 'manual',
            MANUAL_APPROVED: 'manual'
        };
        return mapping[apiStatus] || apiStatus;
    };
    ApplyService.prototype.getCurHost = function () {
        return window.location.protocol + '//' + window.location.host;
    };
    ApplyService.prototype.isFlowFail = function (status) {
        if (status === 'APPROVE_FAIL' || status === 'FAILED' || status === 'CANCELLED' || status === 'COMPLETED') {
            return true;
        }
        else {
            return false;
        }
    };
    ApplyService.prototype.maskPhone = function (phone) {
        if (phone === void 0) { phone = ''; }
        return phone.substr(0, 3) + '****' + phone.substr(7);
    };
    ApplyService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ factory: function ApplyService_Factory() { return new ApplyService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_el_core_config__WEBPACK_IMPORTED_MODULE_6__["EL_CONFIG"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"])); }, token: ApplyService, providedIn: "root" });
    return ApplyService;
}());



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.component.ngfactory.js":
/*!********************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.component.ngfactory.js ***!
  \********************************************************************************************************/
/*! exports provided: RenderType_AgreementComponent, View_AgreementComponent_0, View_AgreementComponent_Host_0, AgreementComponentNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RenderType_AgreementComponent", function() { return RenderType_AgreementComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AgreementComponent_0", function() { return View_AgreementComponent_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AgreementComponent_Host_0", function() { return View_AgreementComponent_Host_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementComponentNgFactory", function() { return AgreementComponentNgFactory; });
/* harmony import */ var _agreement_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agreement.component.scss.shim.ngstyle */ "../../node_modules/@bk/module-agreement/agreement.component.scss.shim.ngstyle.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng2_pdf_viewer_ng2_pdf_viewer_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../ng2-pdf-viewer/ng2-pdf-viewer.ngfactory */ "../../node_modules/ng2-pdf-viewer/ng2-pdf-viewer.ngfactory.js");
/* harmony import */ var ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng2-pdf-viewer */ "../../node_modules/ng2-pdf-viewer/fesm5/ng2-pdf-viewer.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_material_button_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@angular/material/button/typings/index.ngfactory */ "../../node_modules/@angular/material/button/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "../../node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/a11y */ "../../node_modules/@angular/cdk/esm5/a11y.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser/animations */ "../../node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../@angular/material/icon/typings/index.ngfactory */ "../../node_modules/@angular/material/icon/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/icon */ "../../node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/cdk/portal */ "../../node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var _agreement_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./agreement.component */ "../../node_modules/@bk/module-agreement/agreement.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/snack-bar */ "../../node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _bk_module_snowplow_snowplow_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @bk/module-snowplow/snowplow.service */ "../../node_modules/@bk/module-snowplow/snowplow.service.ts");
/* harmony import */ var _agreement_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./agreement.service */ "../../node_modules/@bk/module-agreement/agreement.service.ts");
/* harmony import */ var _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @bk/module-core/layout/layout.service */ "../../node_modules/@bk/module-core/layout/layout.service.ts");




















var styles_AgreementComponent = [_agreement_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];
var RenderType_AgreementComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({ encapsulation: 0, styles: styles_AgreementComponent, data: { "animation": [{ type: 7, name: "routeAnimation2", definitions: [{ type: 0, name: "hide", styles: { type: 6, styles: { visibility: "hidden" }, offset: null }, options: undefined }, { type: 0, name: "show", styles: { type: 6, styles: { opacity: 1, visibility: "visible" }, offset: null }, options: undefined }, { type: 1, expr: "hide => show", animation: [{ type: 6, styles: { opacity: 0, visibility: "visible", transform: "translateY(10%)" }, offset: null }, { type: 3, steps: [{ type: 4, styles: { type: 6, styles: { transform: "translateY(0)" }, offset: null }, timings: "0.2s ease-out" }, { type: 4, styles: { type: 6, styles: { opacity: 1 }, offset: null }, timings: "0.2s linear" }], options: null }], options: null }, { type: 1, expr: "show => hide", animation: [{ type: 6, styles: { position: "absolute", top: "0", width: "*" }, offset: null }, { type: 4, styles: { type: 6, styles: { opacity: 0 }, offset: null }, timings: "0.2s linear" }], options: null }], options: {} }] } });

function View_AgreementComponent_1(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "section", [], [[8, "innerHTML", 1]], null, null, null, null))], null, function (_ck, _v) { var _co = _v.component; var currVal_0 = _co.agreementHtml; _ck(_v, 0, 0, currVal_0); }); }
function View_AgreementComponent_2(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "out-iframe"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, [[2, 0], ["iframe", 1]], null, 0, "iframe", [["class", "iframe"], ["frameborder", "0"]], [[1, "src", 5]], null, null, null, null))], null, function (_ck, _v) { var _co = _v.component; var currVal_0 = _co.url; _ck(_v, 1, 0, currVal_0); }); }
function View_AgreementComponent_4(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "h2", [["class", "pdf-not-ready"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["\u6682\u65E0\u534F\u8BAE"]))], null, null); }
function View_AgreementComponent_3(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "out-pdf"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "pdf-viewer", [["style", "display: block;"]], null, [["window", "resize"]], function (_v, en, $event) { var ad = true; if (("window:resize" === en)) {
        var pd_0 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).onPageResize() !== false);
        ad = (pd_0 && ad);
    } return ad; }, _ng2_pdf_viewer_ng2_pdf_viewer_ngfactory__WEBPACK_IMPORTED_MODULE_2__["View_PdfViewerComponent_0"], _ng2_pdf_viewer_ng2_pdf_viewer_ngfactory__WEBPACK_IMPORTED_MODULE_2__["RenderType_PdfViewerComponent"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 9158656, null, 0, ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_3__["PdfViewerComponent"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], { src: [0, "src"], renderText: [1, "renderText"], originalSize: [2, "originalSize"], fitToPage: [3, "fitToPage"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AgreementComponent_4)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null)], function (_ck, _v) { var _co = _v.component; var currVal_0 = _co.url; var currVal_1 = true; var currVal_2 = true; var currVal_3 = 0.85; _ck(_v, 2, 0, currVal_0, currVal_1, currVal_2, currVal_3); var currVal_4 = !_co.pdfReady; _ck(_v, 4, 0, currVal_4); }, null); }
function View_AgreementComponent_5(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 8, "div", [["class", "close tst-close"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](512, null, _angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassImpl"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassR2Impl"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgClass"], [_angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassImpl"]], { klass: [0, "klass"], ngClass: [1, "ngClass"] }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](3, { "not-show": 0 }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 4, "button", [["aria-label", "Close"], ["mat-icon-button", ""]], [[1, "disabled", 0], [2, "_mat-animation-noopable", null]], [[null, "click"]], function (_v, en, $event) { var ad = true; var _co = _v.component; if (("click" === en)) {
        var pd_0 = (_co.close() !== false);
        ad = (pd_0 && ad);
    } return ad; }, _angular_material_button_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_5__["View_MatButton_0"], _angular_material_button_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_5__["RenderType_MatButton"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 180224, null, 0, _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_7__["FocusMonitor"], [2, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__["ANIMATION_MODULE_TYPE"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, 0, 2, "mat-icon", [["class", "mat-icon notranslate"], ["role", "img"]], [[2, "mat-icon-inline", null], [2, "mat-icon-no-color", null]], null, null, _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__["View_MatIcon_0"], _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__["RenderType_MatIcon"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 9158656, null, 0, _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__["MatIcon"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__["MatIconRegistry"], [8, null], [2, _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__["MAT_ICON_LOCATION"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, 0, ["close"]))], function (_ck, _v) { var _co = _v.component; var currVal_0 = "close tst-close"; var currVal_1 = _ck(_v, 3, 0, ((_co.type === "byjLoan") || (_co.type === "bclLoan"))); _ck(_v, 2, 0, currVal_0, currVal_1); _ck(_v, 7, 0); }, function (_ck, _v) { var currVal_2 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).disabled || null); var currVal_3 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5)._animationMode === "NoopAnimations"); _ck(_v, 4, 0, currVal_2, currVal_3); var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).inline; var currVal_5 = (((_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).color !== "primary") && (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).color !== "accent")) && (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).color !== "warn")); _ck(_v, 6, 0, currVal_4, currVal_5); }); }
function View_AgreementComponent_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 1, { closeArea: 0 }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 2, { iframe: 0 }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 3, { pdfViewer: 0 }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 11, "div", [["class", "agreement"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](512, null, _angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassImpl"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassR2Impl"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgClass"], [_angular_common__WEBPACK_IMPORTED_MODULE_4__["ɵNgClassImpl"]], { klass: [0, "klass"], ngClass: [1, "ngClass"] }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](6, { "iframe": 0, "pdf": 1 }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AgreementComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](8, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AgreementComponent_2)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AgreementComponent_3)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](12, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], { ngIf: [0, "ngIf"] }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AgreementComponent_5)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](14, 16384, [[1, 4]], 0, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_11__["CdkPortal"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]], null, null)], function (_ck, _v) { var _co = _v.component; var currVal_0 = "agreement"; var currVal_1 = _ck(_v, 6, 0, (_co.renderWay === "iframe"), (_co.renderWay === "pdf")); _ck(_v, 5, 0, currVal_0, currVal_1); var currVal_2 = (_co.renderWay === "default"); _ck(_v, 8, 0, currVal_2); var currVal_3 = (_co.renderWay === "iframe"); _ck(_v, 10, 0, currVal_3); var currVal_4 = (_co.renderWay === "pdf"); _ck(_v, 12, 0, currVal_4); }, null); }
function View_AgreementComponent_Host_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "app-agreement", [], [[4, "display", null]], null, null, View_AgreementComponent_0, RenderType_AgreementComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 4440064, null, 0, _agreement_component__WEBPACK_IMPORTED_MODULE_12__["AgreementComponent"], [_angular_router__WEBPACK_IMPORTED_MODULE_13__["ActivatedRoute"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClient"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_15__["MatSnackBar"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ApplicationRef"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DOCUMENT"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__["TransferState"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"], _bk_module_snowplow_snowplow_service__WEBPACK_IMPORTED_MODULE_17__["SnowplowService"], _agreement_service__WEBPACK_IMPORTED_MODULE_18__["AgreementService"], _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_19__["LayoutService"]], null, null)], function (_ck, _v) { _ck(_v, 1, 0); }, function (_ck, _v) { var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 1).display; _ck(_v, 0, 0, currVal_0); }); }
var AgreementComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("app-agreement", _agreement_component__WEBPACK_IMPORTED_MODULE_12__["AgreementComponent"], View_AgreementComponent_Host_0, {}, {}, []);



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.component.scss.shim.ngstyle.js":
/*!****************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.component.scss.shim.ngstyle.js ***!
  \****************************************************************************************************************/
/*! exports provided: styles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
var styles = [".agreement[_ngcontent-%COMP%] {\n  margin: 1rem;\n  padding: 0 1.5rem;\n}\n\n.agreement.iframe[_ngcontent-%COMP%] {\n  padding: 0;\n}\n\n.agreement.pdf[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  overflow: scroll;\n}\n\n.not-show[_ngcontent-%COMP%] {\n  display: none !important;\n}\n\n.close[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 5.5rem;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  position: fixed;\n  left: 0;\n  bottom: 0;\n  background-image: linear-gradient(-180deg, rgba(255, 255, 255, 0) 0%, #fff 30%);\n  z-index: 100;\n}\n\n[_nghost-%COMP%]     h3 {\n  text-align: center;\n}\n\n.out-iframe[_ngcontent-%COMP%] {\n  -webkit-overflow-scrolling: touch;\n  overflow: auto;\n  position: relative;\n  z-index: 0;\n  height: 88vh;\n}\n\n.out-iframe[_ngcontent-%COMP%]   .iframe[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100vh;\n  -webkit-overflow-scrolling: touch;\n  overflow: scroll;\n  position: relative;\n  z-index: 100;\n  margin-bottom: 80px;\n}\n\n.out-pdf[_ngcontent-%COMP%] {\n  -webkit-overflow-scrolling: touch;\n  overflow: scroll;\n  position: relative;\n  z-index: 0;\n  height: 100vh;\n}\n\n.pdf-not-ready[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: 45%;\n  position: absolute;\n  left: 50%;\n  transform: translate(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9saXVqaW5nL2JrL2NyZWRpdC1hcHBsL25vZGVfbW9kdWxlcy9AYmsvbW9kdWxlLWFncmVlbWVudC9hZ3JlZW1lbnQuY29tcG9uZW50LnNjc3MiLCJub2RlX21vZHVsZXMvQGJrL21vZHVsZS1hZ3JlZW1lbnQvYWdyZWVtZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FEQUU7RUFDRSxVQUFBO0FDR0o7O0FEREU7RUFDRSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FDSUo7O0FEREE7RUFDRSx3QkFBQTtBQ0lGOztBREZBO0VBQ0UsV0FBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtFQUNBLCtFQUFBO0VBQ0EsWUFBQTtBQ0tGOztBRENBO0VBQ0Usa0JBQUE7QUNFRjs7QURDQTtFQUNFLGlDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUNFRjs7QURERTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FDSUo7O0FERUE7RUFDRSxpQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7QUNDRiIsImZpbGUiOiJub2RlX21vZHVsZXMvQGJrL21vZHVsZS1hZ3JlZW1lbnQvYWdyZWVtZW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFncmVlbWVudCB7XG4gIG1hcmdpbjogMXJlbTtcbiAgcGFkZGluZzogMCAxLjVyZW07XG4gICYuaWZyYW1lIHtcbiAgICBwYWRkaW5nOiAwO1xuICB9XG4gICYucGRmIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICB9XG59XG4ubm90LXNob3cge1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG59XG4uY2xvc2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1LjVyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGxlZnQ6IDA7XG4gIGJvdHRvbTogMDtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KC0xODBkZWcsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMCkgMCUsICNmZmYgMzAlKTtcbiAgei1pbmRleDogMTAwO1xufVxuXG4vLyA6Om5nLWRlZXAgYXBwLXJvb3Qge1xuLy8gICBvdmVyZmxvdzogaGlkZGVuO1xuLy8gfVxuOmhvc3QgOjpuZy1kZWVwIGgzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ub3V0LWlmcmFtZSB7XG4gIC13ZWJraXQtb3ZlcmZsb3ctc2Nyb2xsaW5nOiB0b3VjaDtcbiAgb3ZlcmZsb3c6IGF1dG87XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbiAgaGVpZ2h0OiA4OHZoO1xuICAuaWZyYW1lIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMHZoO1xuICAgIC13ZWJraXQtb3ZlcmZsb3ctc2Nyb2xsaW5nOiB0b3VjaDtcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB6LWluZGV4OiAxMDA7XG4gICAgbWFyZ2luLWJvdHRvbTogODBweDtcbiAgICAvLyB0cmFuc2Zvcm06IHNjYWxlKDAuMjUpO1xuICAgIC8vIHRyYW5zZm9ybS1vcmlnaW46IDAgMDtcbiAgfVxufVxuXG4ub3V0LXBkZiB7XG4gIC13ZWJraXQtb3ZlcmZsb3ctc2Nyb2xsaW5nOiB0b3VjaDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAwO1xuICBoZWlnaHQ6IDEwMHZoO1xufVxuXG4ucGRmLW5vdC1yZWFkeSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogNDUlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG59XG4iLCIuYWdyZWVtZW50IHtcbiAgbWFyZ2luOiAxcmVtO1xuICBwYWRkaW5nOiAwIDEuNXJlbTtcbn1cblxuLmFncmVlbWVudC5pZnJhbWUge1xuICBwYWRkaW5nOiAwO1xufVxuXG4uYWdyZWVtZW50LnBkZiB7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cblxuLm5vdC1zaG93IHtcbiAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4uY2xvc2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1LjVyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGxlZnQ6IDA7XG4gIGJvdHRvbTogMDtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KC0xODBkZWcsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMCkgMCUsICNmZmYgMzAlKTtcbiAgei1pbmRleDogMTAwO1xufVxuXG46aG9zdCA6Om5nLWRlZXAgaDMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5vdXQtaWZyYW1lIHtcbiAgLXdlYmtpdC1vdmVyZmxvdy1zY3JvbGxpbmc6IHRvdWNoO1xuICBvdmVyZmxvdzogYXV0bztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAwO1xuICBoZWlnaHQ6IDg4dmg7XG59XG5cbi5vdXQtaWZyYW1lIC5pZnJhbWUge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDB2aDtcbiAgLXdlYmtpdC1vdmVyZmxvdy1zY3JvbGxpbmc6IHRvdWNoO1xuICBvdmVyZmxvdzogc2Nyb2xsO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDEwMDtcbiAgbWFyZ2luLWJvdHRvbTogODBweDtcbn1cblxuLm91dC1wZGYge1xuICAtd2Via2l0LW92ZXJmbG93LXNjcm9sbGluZzogdG91Y2g7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbiAgaGVpZ2h0OiAxMDB2aDtcbn1cblxuLnBkZi1ub3QtcmVhZHkge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDQ1JTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUpO1xufVxuXG4iXX0= */"];



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.component.ts":
/*!**********************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: agreenmentIframeTitleMap, agreenmentEmployLoanTitleMap, byjLoanTitleMap, bclLoanTitleMap, AgreementComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agreenmentIframeTitleMap", function() { return agreenmentIframeTitleMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agreenmentEmployLoanTitleMap", function() { return agreenmentEmployLoanTitleMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "byjLoanTitleMap", function() { return byjLoanTitleMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bclLoanTitleMap", function() { return bclLoanTitleMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementComponent", function() { return AgreementComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/portal */ "../../node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var url__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! url */ "../../node_modules/url/url.js");
/* harmony import */ var url__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(url__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/snack-bar */ "../../node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash/get */ "../../node_modules/lodash/get.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var lodash_template__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash/template */ "../../node_modules/lodash/template.js");
/* harmony import */ var lodash_template__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash_template__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bk/module-core/base-route-component/base-route.component */ "../../node_modules/@bk/module-core/base-route-component/base-route.component.ts");
/* harmony import */ var _bk_module_snowplow__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @bk/module-snowplow */ "../../node_modules/@bk/module-snowplow/index.ts");
/* harmony import */ var _agreement_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./agreement.service */ "../../node_modules/@bk/module-agreement/agreement.service.ts");
/* harmony import */ var _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @bk/module-core/layout/layout.service */ "../../node_modules/@bk/module-core/layout/layout.service.ts");
var _a;


















var agreenmentTitleMap = {
    '01': '《信息查询授权协议》',
    '02': '金山金水《信息查询授权协议》'
};
var agreenmentIframeTitleMap = {
    '01': '贷款服务协议',
    '02': '个人借款合同',
    '03': '信用信息查询、使用授权协议'
};
var agreenmentIframeTypeMap = {
    '02': 'LOAN_CONTRACT',
    '03': 'CREDIT_AGREEMENT'
};
var agreenmentEmployLoanTitleMap = {
    '01': '链链金融平台服务协议',
    '02': '链链金融隐私政策',
    '03': '资金存管三方协议',
    '04': '授权业务三方协议',
    '05': '电子签章授权协议',
    '06': '信息查询授权书',
    '07': '借款协议及担保协议',
    '08': '授权委托书'
};
var byjLoanTitleMap = {
    '01': '贝壳金服用户服务协议',
    '02': '信息查询授权书',
    '03': '借款协议',
    '04': '借款协议',
    '05': '借款协议',
    '06': '个人借款咨询服务协议',
    '07': '委托扣款授权协议',
    '08': '借款协议'
};
var bclLoanTitleMap = {
    '01': '注册及服务协议',
    '02': '用户隐私政策',
    '03': '结清凭证',
    '04': '委托保证及服务协议',
    '05': '信息查询授权书',
    '06': '借款合同'
};
var agreenmentEmployLoanTypeMap = {
    '01': 'CHAIN_FINANCIAL_PLATFORM_SERVICE_PROTOCOL',
    '02': 'CHAIN_FINANCIAL_PRIVACY_POLICY',
    '03': 'DEPOSITORY_FUNDS_TRIPARTITE_AGREEMENT',
    '04': 'AUTHORIZED_BUSINESS_TRIPARTITE_AGREEMENT',
    '05': 'DIGITAL_CERTIFICATION_USE_SECURITY_TIPS',
    '06': 'INFORMATION_QUERY_AUTHORIZATION',
    '07': 'LOAN_AND_GUARANTEE_AGREEMENT',
    '08': 'POWER_OF_ATTORNEY'
};
var byjLoanTypeMap = {
    '01': 'KE_FINANCE_USER_SERVICE_AGREEMENT',
    '02': 'PERSONAL_INFORMATION_QUERY_AUTHORIZATION',
    '03': 'LOAN_CONTRCT_OF_EMPLOYEE',
    '04': 'LOAN_CONTRCT_OF_AGENT',
    '05': 'LOAN_CONTRACT_OF_BEIKE',
    '06': 'PERSONAL_LOAN_CONSULTANCY_SERVICE_AGREEMENT',
    '07': 'ENTRUSTED_DEDUCTION_AUTHORIZATION_AGREEMENT',
    '08': 'LOAN_CONTRACT_OF_SH_AGENT'
};
var bclLoanTypeMap = {
    '01': 'BEIKE_APP_REGISTRATION_SERVICE_AGREEMENT',
    '02': 'BEIKE_FINANCE_PRIVACY_POLICY',
    '03': 'KE_FINANCE_USER_SERVICE_AGREEMENT',
    '04': 'ENTRUSTMENT_GUARANTEE_AND_SERVICE_AGREEMENT',
    '05': 'BCL_PERSONAL_INFORMATION_QUERY_AUTHORIZATION',
    '06': 'BCL_LOAN_CONTRACT'
};
var renderTypes = (_a = {},
    _a["agreement/cashloan/01"] = 'iframe',
    _a["agreement/cashloan/02"] = 'iframe',
    _a["agreement/cashloan/03"] = 'iframe',
    _a["agreement/01"] = 'default',
    _a["agreement/02"] = 'default',
    _a['employee-agreement/01'] = 'iframe',
    _a['employee-agreement/02'] = 'iframe',
    _a['employee-agreement/03'] = 'iframe',
    _a['employee-agreement/04'] = 'iframe',
    _a['employee-agreement/05'] = 'iframe',
    _a['employee-agreement/06'] = 'iframe',
    _a['employee-agreement/07'] = 'iframe',
    _a['employee-agreement/08'] = 'iframe',
    _a['byj-agreement/01'] = 'iframe',
    _a['byj-agreement/02'] = 'iframe',
    _a['byj-agreement/03'] = 'iframe',
    _a['byj-agreement/04'] = 'iframe',
    _a['byj-agreement/05'] = 'iframe',
    _a['byj-agreement/06'] = 'iframe',
    _a['byj-agreement/07'] = 'iframe',
    _a['byj-agreement/08'] = 'iframe',
    _a['bcl-agreement/01'] = 'iframe',
    _a['bcl-agreement/02'] = 'iframe',
    _a['bcl-agreement/03'] = 'iframe',
    _a['bcl-agreement/04'] = 'iframe',
    _a['bcl-agreement/05'] = 'iframe',
    _a['bcl-agreement/06'] = 'iframe',
    _a);
var agreementStateKey = Object(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__["makeStateKey"])("@bk/module-agreement" + '-AgreementComponent');
var AgreementComponent = (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](AgreementComponent, _super);
    function AgreementComponent(route, http, snackBar, location, componentFactoryResolver, injector, appRef, document, serverState, platformId, snowplow, agreementService, layoutService) {
        var _this = _super.call(this) || this;
        _this.route = route;
        _this.http = http;
        _this.snackBar = snackBar;
        _this.location = location;
        _this.componentFactoryResolver = componentFactoryResolver;
        _this.injector = injector;
        _this.appRef = appRef;
        _this.document = document;
        _this.serverState = serverState;
        _this.platformId = platformId;
        _this.snowplow = snowplow;
        _this.agreementService = agreementService;
        _this.layoutService = layoutService;
        _this.display = 'block';
        _this.agreementHtml = '';
        _this._onDestroy = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        _this.pdfReady = true;
        _this.pdfjsUrl = "/byj/agreement/pdfjs";
        var path = _this.route.snapshot.url.join().replace(/,/g, '/');
        _this.renderWay = renderTypes[path];
        return _this;
    }
    AgreementComponent.prototype.ngOnInit = function () {
        _super.prototype.ngOnInit.call(this);
        var agreementRendered = this.serverState.get(agreementStateKey, null);
        if (agreementRendered) {
            this.agreementHtml = agreementRendered;
            return;
        }
        this.type = this.route.snapshot.data.type;
        if (this.type === 'cashLoan' || this.type === 'appl') {
            this.renderHtml();
        }
        else if (this.type === 'employeeLoan') {
            this.renderEmployeeHtml();
        }
        else if (this.type === 'byjLoan') {
            this.rendeByjHtml();
        }
        else if (this.type === 'bclLoan') {
            this.rendeBClHtml();
        }
    };
    AgreementComponent.prototype.renderHtml = function () {
        var _this = this;
        var ob;
        if (this.renderWay === 'default') {
            ob = this.route.paramMap.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_12__["switchMap"])(function (params) {
                var id = params.get('id');
                if (id == null) {
                    throw new Error('Missing URL parameter "id"');
                }
                var layoutCfg = _this.layoutService.getConfigure(_this);
                layoutCfg.title = agreenmentTitleMap[id];
                layoutCfg.navBarIcon = 'back';
                _this.layoutService.renderConfigure(layoutCfg);
                var url = "/byj/agreement/content-" + id + '.html';
                if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformServer"])(_this.platformId)) {
                    url = 'http://localhost:' + 14333 + Object(url__WEBPACK_IMPORTED_MODULE_7__["parse"])(url).path;
                    console.log('request url', url);
                }
                return _this.http.get(url, {
                    responseType: 'text'
                });
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_12__["take"])(1));
            ob.subscribe(function (data) {
                _this.agreementHtml = data;
                if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformServer"])(_this.platformId)) {
                    console.log('set agreenment transfer state \n', data);
                    _this.serverState.set(agreementStateKey, data);
                }
                else {
                    _this.playInitAnim();
                }
            }, function (err) {
                _this.snackBar.open(lodash_get__WEBPACK_IMPORTED_MODULE_10___default()(err, 'message', '网络错误'));
            });
        }
        else if (this.renderWay === 'iframe') {
            var id = this.route.snapshot.params.id;
            var layoutCfg = this.layoutService.getConfigure(this);
            layoutCfg.title = agreenmentIframeTitleMap[id];
            layoutCfg.navBarIcon = 'back';
            this.layoutService.renderConfigure(layoutCfg);
            var url_1 = "/byj/agreement/iframe-" + id + '.html';
            var contractType = agreenmentIframeTypeMap[id];
            var iframFillData_1 = {};
            this.agreementService.applyId = this.route.snapshot.params.applyId;
            this.agreementService
                .contractPreview(contractType)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_12__["concatMap"])(function (data) {
                iframFillData_1 = lodash_get__WEBPACK_IMPORTED_MODULE_10___default()(data, 'data.data');
                return _this.http.get(url_1, {
                    responseType: 'text'
                });
            }))
                .subscribe(function (data) {
                var iframe = lodash_template__WEBPACK_IMPORTED_MODULE_11___default()(data)(iframFillData_1);
                _this.iframe.nativeElement.contentDocument.write(iframe);
            });
        }
    };
    AgreementComponent.prototype.renderEmployeeHtml = function () {
        var _this = this;
        this.renderCommon('employee-', agreenmentEmployLoanTitleMap, agreenmentEmployLoanTypeMap, function () {
            var id = _this.route.snapshot.params.id;
            return id === '08';
        });
    };
    AgreementComponent.prototype.rendeByjHtml = function () {
        var _this = this;
        this.renderCommon('byj-', byjLoanTitleMap, byjLoanTypeMap, function () {
            var id = _this.route.snapshot.params.id;
            return id !== '01' && id !== '07';
        });
    };
    AgreementComponent.prototype.rendeBClHtml = function () {
        var _this = this;
        this.renderCommon('bcl-', bclLoanTitleMap, bclLoanTypeMap, function () {
            var id = _this.route.snapshot.params.id;
            return id === '04' || id === '06';
        });
    };
    AgreementComponent.prototype.renderCommon = function (prefix, titleMap, typeMap, whenFillPerch) {
        var _this = this;
        if (prefix === void 0) { prefix = ''; }
        window.pdfWorkerSrc = __webpack_require__(/*! @dr-core/webpack2-builder/dist/loaders/dr-file-loader!./assets/pdf.worker.js */ "../../../dr-comp-package/src/internal/webpack2-builder/dist/loaders/dr-file-loader.js!../../node_modules/@bk/module-agreement/assets/pdf.worker.js");
        this.renderWay = 'iframe';
        var id = this.route.snapshot.params.id;
        var isPreview = this.route.snapshot.queryParamMap.get('isPreview');
        var layoutCfg = this.layoutService.getConfigure(this);
        layoutCfg.title = titleMap[id];
        layoutCfg.navBarIcon = 'back';
        this.layoutService.renderConfigure(layoutCfg);
        console.info("/byj/agreement/**");
        var url = window.location.origin +
            /^\/[^/]*/g.exec(window.location.pathname) +
            '/agreement/' +
            prefix +
            id +
            '.html?v=' +
            Math.random();
        var contractType = typeMap[id];
        this.agreementService.applyId = this.route.snapshot.queryParams.applyId;
        if (isPreview === 'false') {
            this.renderWay = 'pdf';
            this.agreementService.getContractPreview(contractType, false).subscribe(function (res) {
                if (res.data.contractUrl) {
                    var path = res.data.contractUrl.replace('http://', 'https://');
                    _this.url = path;
                }
                else {
                    _this.pdfReady = false;
                }
            });
        }
        else {
            if (whenFillPerch() && this.agreementService.applyId) {
                Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["forkJoin"])([
                    this.http.get(url, {
                        responseType: 'text',
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                            'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                            Pragma: 'no-cache',
                            Expires: '0'
                        })
                    }),
                    this.agreementService.getContractPreview(contractType)
                ]).subscribe(function (result) {
                    var html = result[0];
                    var iframe = lodash_template__WEBPACK_IMPORTED_MODULE_11___default()(html)(result[1].data.contractData);
                    _this.iframe.nativeElement.contentDocument.write(iframe);
                }, function (error) {
                    console.info(error);
                });
            }
            else {
                this.http
                    .get(url, {
                    responseType: 'text',
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                        'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                        Pragma: 'no-cache',
                        Expires: '0'
                    })
                })
                    .subscribe(function (data) {
                    data = data.replace(/[<][%][=]\s\S*\s[%][>]/g, '');
                    _this.iframe.nativeElement.contentDocument.write(data);
                });
            }
        }
    };
    AgreementComponent.prototype.employeeError = function (data) {
        this.iframe.nativeElement.contentDocument.write(data);
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])('api fail');
    };
    AgreementComponent.prototype.ngAfterViewInit = function () {
        this.portalHost = new _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_6__["DomPortalHost"](this.document.body, this.componentFactoryResolver, this.appRef, this.injector);
        this.portalHost.attach(this.closeArea);
    };
    AgreementComponent.prototype.ngOnDestroy = function () {
        this.portalHost.detach();
        this._onDestroy.next();
        this._onDestroy.complete();
    };
    AgreementComponent.prototype.close = function () {
        this.snowplow.trackClick('agreement-close');
        this.location.back();
    };
    return AgreementComponent;
}(_bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_13__["BaseRouteComponent"]));

_bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_13__["BaseRouteComponent"].extendLifecycleHooks(AgreementComponent);


/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.list.component.ngfactory.js":
/*!*************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.list.component.ngfactory.js ***!
  \*************************************************************************************************************/
/*! exports provided: RenderType_AgreementListComponent, View_AgreementListComponent_0, View_AgreementListComponent_Host_0, AgreementListComponentNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RenderType_AgreementListComponent", function() { return RenderType_AgreementListComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AgreementListComponent_0", function() { return View_AgreementListComponent_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AgreementListComponent_Host_0", function() { return View_AgreementListComponent_Host_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementListComponentNgFactory", function() { return AgreementListComponentNgFactory; });
/* harmony import */ var _agreement_list_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agreement.list.component.scss.shim.ngstyle */ "../../node_modules/@bk/module-agreement/agreement.list.component.scss.shim.ngstyle.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_list_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../@angular/material/list/typings/index.ngfactory */ "../../node_modules/@angular/material/list/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/list */ "../../node_modules/@angular/material/esm5/list.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/core */ "../../node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/platform */ "../../node_modules/@angular/cdk/esm5/platform.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "../../node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../@angular/material/icon/typings/index.ngfactory */ "../../node_modules/@angular/material/icon/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ "../../node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _angular_material_divider_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../@angular/material/divider/typings/index.ngfactory */ "../../node_modules/@angular/material/divider/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/divider */ "../../node_modules/@angular/material/esm5/divider.es5.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _agreement_list_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./agreement.list.component */ "../../node_modules/@bk/module-agreement/agreement.list.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @bk/module-core/layout/layout.service */ "../../node_modules/@bk/module-core/layout/layout.service.ts");
/* harmony import */ var _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @bk/employee-loan/app/apply/apply.service */ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts");
















var styles_AgreementListComponent = [_agreement_list_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];
var RenderType_AgreementListComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({ encapsulation: 0, styles: styles_AgreementListComponent, data: { "animation": [{ type: 7, name: "routeAnimation2", definitions: [{ type: 0, name: "hide", styles: { type: 6, styles: { visibility: "hidden" }, offset: null }, options: undefined }, { type: 0, name: "show", styles: { type: 6, styles: { opacity: 1, visibility: "visible" }, offset: null }, options: undefined }, { type: 1, expr: "hide => show", animation: [{ type: 6, styles: { opacity: 0, visibility: "visible", transform: "translateY(10%)" }, offset: null }, { type: 3, steps: [{ type: 4, styles: { type: 6, styles: { transform: "translateY(0)" }, offset: null }, timings: "0.2s ease-out" }, { type: 4, styles: { type: 6, styles: { opacity: 1 }, offset: null }, timings: "0.2s linear" }], options: null }], options: null }, { type: 1, expr: "show => hide", animation: [{ type: 6, styles: { position: "absolute", top: "0", width: "*" }, offset: null }, { type: 4, styles: { type: 6, styles: { opacity: 0 }, offset: null }, timings: "0.2s linear" }], options: null }], options: {} }] } });

function View_AgreementListComponent_1(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 13, "div", [["class", "item"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 10, "mat-list-item", [["class", "slide-up stag-item mat-list-item mat-ripple"], ["matRipple", ""], ["role", "listitem"]], [[2, "mat-list-item-avatar", null], [2, "mat-list-item-with-avatar", null], [2, "mat-ripple-unbounded", null]], [[null, "click"]], function (_v, en, $event) { var ad = true; var _co = _v.component; if (("click" === en)) {
        var pd_0 = (_co.toAgreement(_v.context.$implicit.id) !== false);
        ad = (pd_0 && ad);
    } return ad; }, _angular_material_list_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["View_MatListItem_0"], _angular_material_list_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["RenderType_MatListItem"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 1228800, null, 3, _angular_material_list__WEBPACK_IMPORTED_MODULE_3__["MatListItem"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], [2, _angular_material_list__WEBPACK_IMPORTED_MODULE_3__["MatNavList"]], [2, _angular_material_list__WEBPACK_IMPORTED_MODULE_3__["MatList"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 1, { _lines: 1 }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 2, { _avatar: 0 }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 3, { _icon: 0 }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 212992, null, 0, _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MatRipple"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_5__["Platform"], [2, _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MAT_RIPPLE_GLOBAL_OPTIONS"]], [2, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["ANIMATION_MODULE_TYPE"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, 2, 1, "span", [["class", "left"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](8, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, 2, 2, "mat-icon", [["class", "mat-icon notranslate"], ["role", "img"]], [[2, "mat-icon-inline", null], [2, "mat-icon-no-color", null]], null, null, _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_7__["View_MatIcon_0"], _angular_material_icon_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_7__["RenderType_MatIcon"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 9158656, null, 0, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIconRegistry"], [8, null], [2, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MAT_ICON_LOCATION"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, 0, ["chevron_right"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 1, "mat-divider", [["class", "slide-up stag-item mat-divider"], ["role", "separator"]], [[1, "aria-orientation", 0], [2, "mat-divider-vertical", null], [2, "mat-divider-horizontal", null], [2, "mat-divider-inset", null]], null, null, _angular_material_divider_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__["View_MatDivider_0"], _angular_material_divider_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_9__["RenderType_MatDivider"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](13, 49152, null, 0, _angular_material_divider__WEBPACK_IMPORTED_MODULE_10__["MatDivider"], [], null, null)], function (_ck, _v) { _ck(_v, 6, 0); _ck(_v, 10, 0); }, function (_ck, _v) { var currVal_0 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2)._avatar || _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2)._icon); var currVal_1 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2)._avatar || _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2)._icon); var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 6).unbounded; _ck(_v, 1, 0, currVal_0, currVal_1, currVal_2); var currVal_3 = _v.context.$implicit.name; _ck(_v, 8, 0, currVal_3); var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 10).inline; var currVal_5 = (((_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 10).color !== "primary") && (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 10).color !== "accent")) && (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 10).color !== "warn")); _ck(_v, 9, 0, currVal_4, currVal_5); var currVal_6 = (_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13).vertical ? "vertical" : "horizontal"); var currVal_7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13).vertical; var currVal_8 = !_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13).vertical; var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13).inset; _ck(_v, 12, 0, currVal_6, currVal_7, currVal_8, currVal_9); }); }
function View_AgreementListComponent_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "section", [["class", "section"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "mat-list", [["class", "list mat-list mat-list-base"], ["role", "list"]], null, null, null, _angular_material_list_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["View_MatList_0"], _angular_material_list_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["RenderType_MatList"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 704512, null, 0, _angular_material_list__WEBPACK_IMPORTED_MODULE_3__["MatList"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_AgreementListComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_11__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], { ngForOf: [0, "ngForOf"] }, null)], function (_ck, _v) { var _co = _v.component; var currVal_0 = _co.agreementList; _ck(_v, 4, 0, currVal_0); }, null); }
function View_AgreementListComponent_Host_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "cl-agreement-list", [], null, null, null, View_AgreementListComponent_0, RenderType_AgreementListComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 4440064, null, 0, _agreement_list_component__WEBPACK_IMPORTED_MODULE_12__["AgreementListComponent"], [_angular_router__WEBPACK_IMPORTED_MODULE_13__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_13__["ActivatedRoute"], _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_14__["LayoutService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_15__["ApplyService"]], null, null)], function (_ck, _v) { _ck(_v, 1, 0); }, null); }
var AgreementListComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("cl-agreement-list", _agreement_list_component__WEBPACK_IMPORTED_MODULE_12__["AgreementListComponent"], View_AgreementListComponent_Host_0, {}, {}, []);



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.list.component.scss.shim.ngstyle.js":
/*!*********************************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.list.component.scss.shim.ngstyle.js ***!
  \*********************************************************************************************************************/
/*! exports provided: styles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
var styles = ["[_nghost-%COMP%] {\n  background: #fff;\n}\n\n[_nghost-%COMP%]     .mat-list-base .mat-list-item .mat-list-item-content {\n  padding: 0;\n}\n\n[_nghost-%COMP%]     .mat-list-base {\n  padding-top: 0px;\n}\n\n.section[_ngcontent-%COMP%] {\n  padding: 18px 24px;\n}\n\n.item[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 500;\n  color: #18191a;\n  line-height: 50px;\n  cursor: pointer;\n}\n\nmat-icon[_ngcontent-%COMP%] {\n  right: 0;\n  position: absolute;\n  color: #cccccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9saXVqaW5nL2JrL2NyZWRpdC1hcHBsL25vZGVfbW9kdWxlcy9AYmsvbW9kdWxlLWFncmVlbWVudC9hZ3JlZW1lbnQubGlzdC5jb21wb25lbnQuc2NzcyIsIm5vZGVfbW9kdWxlcy9AYmsvbW9kdWxlLWFncmVlbWVudC9hZ3JlZW1lbnQubGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FDQ0Y7O0FEQ0k7RUFDRSxVQUFBO0FDRU47O0FEQUk7RUFDRSxnQkFBQTtBQ0dOOztBREVBO0VBQ0Usa0JBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNDRjs7QURFQTtFQUNFLFFBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUNDRiIsImZpbGUiOiJub2RlX21vZHVsZXMvQGJrL21vZHVsZS1hZ3JlZW1lbnQvYWdyZWVtZW50Lmxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIDo6bmctZGVlcCB7XG4gICAgLm1hdC1saXN0LWJhc2UgLm1hdC1saXN0LWl0ZW0gLm1hdC1saXN0LWl0ZW0tY29udGVudCB7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgIH1cbiAgICAubWF0LWxpc3QtYmFzZSB7XG4gICAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIH1cbiAgfVxufVxuXG4uc2VjdGlvbiB7XG4gIHBhZGRpbmc6IDE4cHggMjRweDtcbn1cblxuLml0ZW0ge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiAjMTgxOTFhO1xuICBsaW5lLWhlaWdodDogNTBweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG5tYXQtaWNvbiB7XG4gIHJpZ2h0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGNvbG9yOiAjY2NjY2NjO1xufVxuIiwiOmhvc3Qge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLm1hdC1saXN0LWJhc2UgLm1hdC1saXN0LWl0ZW0gLm1hdC1saXN0LWl0ZW0tY29udGVudCB7XG4gIHBhZGRpbmc6IDA7XG59XG5cbjpob3N0IDo6bmctZGVlcCAubWF0LWxpc3QtYmFzZSB7XG4gIHBhZGRpbmctdG9wOiAwcHg7XG59XG5cbi5zZWN0aW9uIHtcbiAgcGFkZGluZzogMThweCAyNHB4O1xufVxuXG4uaXRlbSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgY29sb3I6ICMxODE5MWE7XG4gIGxpbmUtaGVpZ2h0OiA1MHB4O1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbm1hdC1pY29uIHtcbiAgcmlnaHQ6IDA7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6ICNjY2NjY2M7XG59XG5cbiJdfQ== */"];



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.list.component.ts":
/*!***************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.list.component.ts ***!
  \***************************************************************************************************/
/*! exports provided: AgreementListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementListComponent", function() { return AgreementListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "../../node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bk/module-core/base-route-component/base-route.component */ "../../node_modules/@bk/module-core/base-route-component/base-route.component.ts");
/* harmony import */ var _bk_animation_common_anim_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bk/animation/common-anim.directive */ "../../node_modules/@bk/animation/common-anim.directive.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _agreement_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./agreement.component */ "../../node_modules/@bk/module-agreement/agreement.component.ts");
/* harmony import */ var _bk_module_core_layout_layout_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bk/module-core/layout/layout.service */ "../../node_modules/@bk/module-core/layout/layout.service.ts");
/* harmony import */ var _bk_employee_loan_app_apply_apply_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bk/employee-loan/app/apply/apply.service */ "../../node_modules/@bk/employee-loan/app/apply/apply.service.ts");










var AgreementListComponent = (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](AgreementListComponent, _super);
    function AgreementListComponent(route, activatedRoute, layoutService, el, renderer, epApplyService) {
        var _this = _super.call(this) || this;
        _this.route = route;
        _this.activatedRoute = activatedRoute;
        _this.layoutService = layoutService;
        _this.epApplyService = epApplyService;
        _this._onDestroy = new rxjs__WEBPACK_IMPORTED_MODULE_1__["ReplaySubject"](1);
        _this.commonAnim = new _bk_animation_common_anim_directive__WEBPACK_IMPORTED_MODULE_5__["CommonAnimBase"](el, renderer);
        return _this;
    }
    AgreementListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.changeTitle('协议列表');
        var layoutCfg = this.layoutService.getConfigure(this);
        layoutCfg.navBarIcon = 'back';
        layoutCfg.title = '协议列表';
        this.layoutService.renderConfigure(layoutCfg);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["forkJoin"])([this.epApplyService.getLastRecord(), this.epApplyService.getLastLoan()])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this._onDestroy), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1))
            .subscribe(function (res) {
            var type = _this.activatedRoute.snapshot.data.type;
            if (type === 'cashLoan') {
                _this.agreementList = [{ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentIframeTitleMap"]['02'], id: '02' }, { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentIframeTitleMap"]['03'], id: '03' }];
            }
            else if (type === 'employeeLoanFull') {
                _this.agreementList = [
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['01'], id: '01' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['02'], id: '02' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['03'], id: '03' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['04'], id: '04' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['05'], id: '05' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['06'], id: '06' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['07'], id: '07' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['08'], id: '08' }
                ];
            }
            else if (type === 'employeeLoanApply') {
                _this.agreementList = [
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['01'], id: '01' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['02'], id: '02' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['03'], id: '03' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['04'], id: '04' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['05'], id: '05' },
                    { name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["agreenmentEmployLoanTitleMap"]['06'], id: '06' }
                ];
            }
            else if (type === 'byjLoanApply') {
                _this.changeTitle('贝用金相关协议');
                _this.agreementList = [{ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['02'], id: '02' }];
            }
            else if (type === 'byjLoanFull') {
                _this.changeTitle('贝用金相关协议');
                _this.agreementList = [{ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['02'], id: '02' }];
                var role = res[0].data.accessRole;
                var fundSide = res[1].data.fundSide;
                if (role === 'BYJ_SALARY' && fundSide === 'bkxd') {
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['03'], id: '03' });
                }
                if (role === 'BYJ_AGENT' && fundSide === 'bkxd') {
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['04'], id: '04' });
                }
                if ((role === 'BYJ_AGENT' || role === 'BYJ_DEYOU') && fundSide === 'bnxd') {
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['08'], id: '08' });
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['07'], id: '07' });
                }
                if (role === 'BYJ_BEIKE' && fundSide === 'bnxd') {
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['05'], id: '05' });
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['06'], id: '06' });
                    _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["byjLoanTitleMap"]['07'], id: '07' });
                }
            }
            else if (type === 'bclLoanList') {
                _this.agreementList = [];
                _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["bclLoanTitleMap"]['04'], id: '04' });
                _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["bclLoanTitleMap"]['05'], id: '05' });
                _this.agreementList.push({ name: _agreement_component__WEBPACK_IMPORTED_MODULE_7__["bclLoanTitleMap"]['06'], id: '06' });
            }
            setTimeout(function () {
                _this.commonAnim.playStag();
            }, 400);
        });
    };
    AgreementListComponent.prototype.toAgreement = function (id) {
        var _this = this;
        var applyId = this.activatedRoute.snapshot.queryParams.applyId;
        this.activatedRoute.data.subscribe(function (value) {
            if (value.type === 'cashLoan') {
                _this.route.navigate(["agreement/cashloan" + '/' + id + '/' + applyId]);
            }
            else if (value.type === 'employeeLoanFull' || value.type === 'employeeLoanApply') {
                var navigationExtras = {
                    queryParams: { applyId: applyId, isPreview: value.type === 'employeeLoanApply' }
                };
                _this.route.navigate(["employee-loan/agreement/employee-agreement" + '/' + id], navigationExtras);
            }
            else if (value.type === 'byjLoanApply' || value.type === 'byjLoanFull') {
                var navigationExtras = {
                    queryParams: { applyId: applyId, isPreview: value.type === 'byjLoanApply' }
                };
                _this.route.navigate(["byj-loan/agreement/byj-agreement" + '/' + id], navigationExtras);
            }
            else if (value.type === 'bclLoanList') {
                var navigationExtras = {
                    queryParams: { applyId: applyId, isPreview: false }
                };
                _this.route.navigate(['bcl/bcl-agreement' + '/' + id], navigationExtras);
            }
        });
    };
    AgreementListComponent.prototype.ngAfterViewInit = function () {
        _super.prototype.ngAfterViewInit.call(this);
    };
    AgreementListComponent.prototype.ngOnDestroy = function () {
        this._onDestroy.next();
        this._onDestroy.complete();
    };
    return AgreementListComponent;
}(_bk_module_core_base_route_component_base_route_component__WEBPACK_IMPORTED_MODULE_4__["BaseRouteComponent"]));



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.module.ngfactory.js":
/*!*****************************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.module.ngfactory.js ***!
  \*****************************************************************************************************/
/*! exports provided: AgreementModuleNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementModuleNgFactory", function() { return AgreementModuleNgFactory; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _agreement_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agreement.module */ "../../node_modules/@bk/module-agreement/agreement.module.ts");
/* harmony import */ var _angular_material_snack_bar_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../@angular/material/snack-bar/typings/index.ngfactory */ "../../node_modules/@angular/material/snack-bar/typings/index.ngfactory.js");
/* harmony import */ var _angular_material_bottom_sheet_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../@angular/material/bottom-sheet/typings/index.ngfactory */ "../../node_modules/@angular/material/bottom-sheet/typings/index.ngfactory.js");
/* harmony import */ var _angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../@angular/router/router.ngfactory */ "../../node_modules/@angular/router/router.ngfactory.js");
/* harmony import */ var _agreement_list_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./agreement.list.component.ngfactory */ "../../node_modules/@bk/module-agreement/agreement.list.component.ngfactory.js");
/* harmony import */ var _agreement_component_ngfactory__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./agreement.component.ngfactory */ "../../node_modules/@bk/module-agreement/agreement.component.ngfactory.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "../../node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/observers */ "../../node_modules/@angular/cdk/esm5/observers.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/core */ "../../node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/cdk/overlay */ "../../node_modules/@angular/cdk/esm5/overlay.es5.js");
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/bidi */ "../../node_modules/@angular/cdk/esm5/bidi.es5.js");
/* harmony import */ var ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng2-pdf-viewer */ "../../node_modules/ng2-pdf-viewer/fesm5/ng2-pdf-viewer.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/cdk/platform */ "../../node_modules/@angular/cdk/esm5/platform.es5.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/checkbox */ "../../node_modules/@angular/material/esm5/checkbox.es5.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/button */ "../../node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/form-field */ "../../node_modules/@angular/material/esm5/form-field.es5.js");
/* harmony import */ var _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/cdk/text-field */ "../../node_modules/@angular/cdk/esm5/text-field.es5.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/input */ "../../node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/cdk/portal */ "../../node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/cdk/scrolling */ "../../node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/snack-bar */ "../../node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "../../node_modules/@angular/material/esm5/bottom-sheet.es5.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/icon */ "../../node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _bk_module_shared_shared_module__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @bk/module-shared/shared.module */ "../../node_modules/@bk/module-shared/shared.module.ts");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/divider */ "../../node_modules/@angular/material/esm5/divider.es5.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/list */ "../../node_modules/@angular/material/esm5/list.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./agreement.list.component */ "../../node_modules/@bk/module-agreement/agreement.list.component.ts");
/* harmony import */ var _agreement_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./agreement.component */ "../../node_modules/@bk/module-agreement/agreement.component.ts");
































var AgreementModuleNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵcmf"](_agreement_module__WEBPACK_IMPORTED_MODULE_1__["AgreementModule"], [], function (_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmod"]([_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵCodegenComponentFactoryResolver"], [[8, [_angular_material_snack_bar_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["MatSnackBarContainerNgFactory"], _angular_material_snack_bar_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_2__["SimpleSnackBarNgFactory"], _angular_material_bottom_sheet_typings_index_ngfactory__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetContainerNgFactory"], _angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_router_router_lNgFactory"], _agreement_list_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__["AgreementListComponentNgFactory"], _agreement_component_ngfactory__WEBPACK_IMPORTED_MODULE_6__["AgreementComponentNgFactory"]]], [3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"]], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleRef"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgLocalization"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgLocaleLocalization"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_7__["ɵangular_packages_common_common_a"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵangular_packages_forms_forms_o"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵangular_packages_forms_forms_o"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["MutationObserverFactory"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["MutationObserverFactory"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["ErrorStateMatcher"], _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["ErrorStateMatcher"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["Overlay"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["Overlay"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["ScrollStrategyOptions"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["OverlayContainer"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["OverlayPositionBuilder"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["OverlayKeyboardDispatcher"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["DOCUMENT"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_12__["Directionality"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_7__["Location"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["ɵc"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["ɵd"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_common__WEBPACK_IMPORTED_MODULE_7__["CommonModule"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["CommonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_13__["PdfViewerModule"], ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_13__["PdfViewerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵangular_packages_forms_forms_d"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵangular_packages_forms_forms_d"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_12__["BidiModule"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_12__["BidiModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatCommonModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatCommonModule"], [[2, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MATERIAL_SANITY_CHECKS"]], [2, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_14__["HAMMER_LOADER"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_15__["PlatformModule"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_15__["PlatformModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatRippleModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatRippleModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["ObserversModule"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["ObserversModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_16__["_MatCheckboxRequiredValidatorModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_16__["_MatCheckboxRequiredValidatorModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_16__["MatCheckboxModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_16__["MatCheckboxModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_button__WEBPACK_IMPORTED_MODULE_17__["MatButtonModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_17__["MatButtonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_18__["MatFormFieldModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_18__["MatFormFieldModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_19__["TextFieldModule"], _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_19__["TextFieldModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_input__WEBPACK_IMPORTED_MODULE_20__["MatInputModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_20__["MatInputModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_21__["PortalModule"], _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_21__["PortalModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_22__["ScrollingModule"], _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_22__["ScrollingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["OverlayModule"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__["OverlayModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_23__["MatSnackBarModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_23__["MatSnackBarModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_24__["MatBottomSheetModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_24__["MatBottomSheetModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_icon__WEBPACK_IMPORTED_MODULE_25__["MatIconModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_25__["MatIconModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _bk_module_shared_shared_module__WEBPACK_IMPORTED_MODULE_26__["SharedModule"], _bk_module_shared_shared_module__WEBPACK_IMPORTED_MODULE_26__["SharedModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatLineModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatLineModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatPseudoCheckboxModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_10__["MatPseudoCheckboxModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_divider__WEBPACK_IMPORTED_MODULE_27__["MatDividerModule"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_27__["MatDividerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_list__WEBPACK_IMPORTED_MODULE_28__["MatListModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_28__["MatListModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_router__WEBPACK_IMPORTED_MODULE_29__["RouterModule"], _angular_router__WEBPACK_IMPORTED_MODULE_29__["RouterModule"], [[2, _angular_router__WEBPACK_IMPORTED_MODULE_29__["ɵangular_packages_router_router_a"]], [2, _angular_router__WEBPACK_IMPORTED_MODULE_29__["Router"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _agreement_module__WEBPACK_IMPORTED_MODULE_1__["AgreementModule"], _agreement_module__WEBPACK_IMPORTED_MODULE_1__["AgreementModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_router__WEBPACK_IMPORTED_MODULE_29__["ROUTES"], function () { return [[{ path: "agreement/cashloan/list", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ0"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "employee-agreement/list-full", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ1"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "employee-agreement/list-apply", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ2"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "byj-agreement/list-full", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ3"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "byj-agreement/list-apply", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ4"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "bcl-agreement/list", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ5"], component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_30__["AgreementListComponent"] }, { path: "agreement/cashloan/:id/:applyId", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ6"], component: _agreement_component__WEBPACK_IMPORTED_MODULE_31__["AgreementComponent"] }, { path: "employee-agreement/:id", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ7"], component: _agreement_component__WEBPACK_IMPORTED_MODULE_31__["AgreementComponent"] }, { path: "byj-agreement/:id", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ8"], component: _agreement_component__WEBPACK_IMPORTED_MODULE_31__["AgreementComponent"] }, { path: "bcl-agreement/:id", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ9"], component: _agreement_component__WEBPACK_IMPORTED_MODULE_31__["AgreementComponent"] }, { path: "agreement/:id", data: _agreement_module__WEBPACK_IMPORTED_MODULE_1__["ɵ10"], component: _agreement_component__WEBPACK_IMPORTED_MODULE_31__["AgreementComponent"] }]]; }, [])]); });



/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.module.ts":
/*!*******************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.module.ts ***!
  \*******************************************************************************************/
/*! exports provided: AgreementModule, ɵ0, ɵ1, ɵ2, ɵ3, ɵ4, ɵ5, ɵ6, ɵ7, ɵ8, ɵ9, ɵ10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementModule", function() { return AgreementModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ0", function() { return ɵ0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ1", function() { return ɵ1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ2", function() { return ɵ2; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ3", function() { return ɵ3; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ4", function() { return ɵ4; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ5", function() { return ɵ5; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ6", function() { return ɵ6; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ7", function() { return ɵ7; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ8", function() { return ɵ8; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ9", function() { return ɵ9; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵ10", function() { return ɵ10; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "../../node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _agreement_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agreement.component */ "../../node_modules/@bk/module-agreement/agreement.component.ts");
/* harmony import */ var _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./agreement.list.component */ "../../node_modules/@bk/module-agreement/agreement.list.component.ts");



var ɵ0 = {
    type: 'cashLoan'
}, ɵ1 = {
    type: 'employeeLoanFull'
}, ɵ2 = {
    type: 'employeeLoanApply'
}, ɵ3 = {
    type: 'byjLoanFull'
}, ɵ4 = {
    type: 'byjLoanApply'
}, ɵ5 = {
    type: 'bclLoanList'
}, ɵ6 = {
    type: 'cashLoan'
}, ɵ7 = {
    type: 'employeeLoan'
}, ɵ8 = {
    type: 'byjLoan'
}, ɵ9 = {
    type: 'bclLoan'
}, ɵ10 = {
    type: 'appl'
};
var agreementRoutes = [
    {
        path: "agreement/cashloan/list",
        data: ɵ0,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: 'employee-agreement/list-full',
        data: ɵ1,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: 'employee-agreement/list-apply',
        data: ɵ2,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: 'byj-agreement/list-full',
        data: ɵ3,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: 'byj-agreement/list-apply',
        data: ɵ4,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: 'bcl-agreement/list',
        data: ɵ5,
        component: _agreement_list_component__WEBPACK_IMPORTED_MODULE_2__["AgreementListComponent"]
    },
    {
        path: "agreement/cashloan/:id/:applyId",
        data: ɵ6,
        component: _agreement_component__WEBPACK_IMPORTED_MODULE_1__["AgreementComponent"]
    },
    {
        path: 'employee-agreement/:id',
        data: ɵ7,
        component: _agreement_component__WEBPACK_IMPORTED_MODULE_1__["AgreementComponent"]
    },
    {
        path: 'byj-agreement/:id',
        data: ɵ8,
        component: _agreement_component__WEBPACK_IMPORTED_MODULE_1__["AgreementComponent"]
    },
    {
        path: 'bcl-agreement/:id',
        data: ɵ9,
        component: _agreement_component__WEBPACK_IMPORTED_MODULE_1__["AgreementComponent"]
    },
    {
        path: "agreement/:id",
        data: ɵ10,
        component: _agreement_component__WEBPACK_IMPORTED_MODULE_1__["AgreementComponent"]
    }
];
var AgreementModule = (function () {
    function AgreementModule() {
    }
    return AgreementModule;
}());




/***/ }),

/***/ "../../node_modules/@bk/module-agreement/agreement.service.ts":
/*!********************************************************************************************!*\
  !*** /Users/liujing/bk/credit-appl/node_modules/@bk/module-agreement/agreement.service.ts ***!
  \********************************************************************************************/
/*! exports provided: AgreementService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgreementService", function() { return AgreementService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "../../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "../../node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/fesm5/core.js");




var AgreementService = (function () {
    function AgreementService(http) {
        this.http = http;
        this.tokenHeaderName = 'X-BK-UUSSSO-Token';
        this.token = sessionStorage.getItem(this.tokenHeaderName);
        this.applyId = '';
    }
    AgreementService.prototype.handleError = function (err) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
    };
    AgreementService.prototype.contractPreview = function (contractType) {
        try {
            if (this.applyId && contractType === 'LOAN_CONTRACT') {
                return this.http.get('cl-api://withdraw-apply/' + this.applyId + '/contract-preview?contractType=' + contractType);
            }
            else if (contractType === 'CREDIT_AGREEMENT') {
                return this.http.get('cl-api://quota/credit-agreement-preview');
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({});
            }
        }
        catch (e) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["throwError"])(e);
        }
    };
    AgreementService.prototype.getContractPreview = function (contractType, isPreview) {
        if (isPreview === void 0) { isPreview = true; }
        return this.http.get('el-api-loan://withdraw-apply/' + this.applyId + '/contract-view?isPreview=' + isPreview + '&contractType=' + contractType, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
                'X-BK-UUSSSO-Token': this.token
            })
        });
    };
    AgreementService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ factory: function AgreementService_Factory() { return new AgreementService(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"])); }, token: AgreementService, providedIn: "root" });
    return AgreementService;
}());



/***/ }),

/***/ 4:
/*!**********************!*\
  !*** zlib (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 5:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 6:
/*!**********************!*\
  !*** http (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 7:
/*!***********************!*\
  !*** https (ignored) ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=bk-module-agreement-ngfactory.js.map